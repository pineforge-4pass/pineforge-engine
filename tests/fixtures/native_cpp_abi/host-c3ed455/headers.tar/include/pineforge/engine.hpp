#pragma once
#include <atomic>
#include <vector>
#include <string>
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <ctime>
#include <limits>
#include <memory>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <stdexcept>
#include <optional>
#include <pineforge/execution_consumer.hpp>
#include "na.hpp"
#include "bar.hpp"
#include "broker_events.hpp"
#include "quantity_intent.hpp"
#include "execution.hpp"
#include "execution_close_scope.hpp"
#include "execution_close_selection.hpp"
#include "execution_projection.hpp"
#include "execution_reverse_to.hpp"
#include "market_admission.hpp"
#include "reservation_expansion.hpp"
#include "order_cancellation.hpp"
#include "compat/pine/frozen_market_instruction.hpp"
#include "leg_activation.hpp"
#include "exit_leg_lifecycle.hpp"
#include "compat/pine/exit_activation.hpp"
#include "order_birth.hpp"
#include "compat/pine/order_birth.hpp"
#include "compat/pine/intraday_cap.hpp"
#include "compat/pine/order_priority.hpp"
#include "series.hpp"
#include "timeframe.hpp"
#include "magnifier.hpp"
#include "session_time.hpp"
// Suppress per-strategy function declarations (strategy_create, run_backtest,
// etc.) whose pf_*_t parameter types conflict with the internal C++ types
// used in codegen-emitted extern "C" blocks that include this header.
// NOTE: this macro leaks into every TU that includes engine.hpp; include
// pineforge.h FIRST in any TU that needs the per-strategy declarations
// (see src/c_abi.cpp).
#define PINEFORGE_NO_STRATEGY_DECLS
// Angle-bracket form is the installed public path (deliberate).
#include <pineforge/pineforge.h>

// The public C mirror needs the engine's admission journal to derive
// source-bound placement facts. The context-free form refuses a bound priced
// entry whose original history is needed; other orders have no predecessor.
namespace pineforge {
void fill_pending_order_mirror(const PendingOrder&,
                               const MarketAdmissionJournal*,
                               pf_pending_order_v1_t*);
void fill_pending_order_mirror(const PendingOrder&, pf_pending_order_v1_t*);
}

// Generated modules using the full script lifecycle reset must be rebuilt
// against a runtime providing this hook. This is an internal C++ capability;
// it does not change any public C POD or exported C function signature.
#define PINEFORGE_HAS_SCRIPT_RUN_PREPARE_V1 1
#define PINEFORGE_HAS_NATIVE_LIVE_V1 1
// Generated constructors can explicitly select Pine cap compatibility before
// any host metadata setter. Older engines keep their legacy default behavior.
#define PINEFORGE_HAS_EXPLICIT_PINE_CAP_V1 1
// Explicitly selects cap and retained-parent priority compatibility only.
#define PINEFORGE_HAS_EXPLICIT_PINE_EXECUTION_ADAPTER_V1 1

namespace pineforge {

enum class PositionSide { FLAT, LONG, SHORT };

// One physical emulator lot entry/exit, in actual execution order. A reversal
// may produce several exits followed by an entry. No range-end report rows.
struct StreamOrderAction {
    uint64_t sequence = 0;
    int64_t timestamp_ms = 0;
    int32_t bar_index = 0;
    bool is_entry = false;
    bool is_long = false;
    double quantity = 0.0;
    double price = 0.0;
    std::string order_id;
    std::string comment;
    uint64_t entry_incarnation = 0;
    size_t closed_trade_index = static_cast<size_t>(-1); // engine-private provenance
};

// round 8 family R (OANDA:EURUSD@15, 45 strong probes; campaign notes
// log-20260905t164404z-85800609 (diagnosis), log-20260905t180248z-0dce5ab0
// (entry-leg admission), log-20260905t180249z-10358e84 (margin-call
// trigger)): TradingView's broker carries MONEY at TEN SIGNIFICANT DIGITS,
// half-up — 3 decimals at >= 1e6, 4 decimals below. Five consequences are
// pinned and implemented, with the per-rule scopes described below:
//   1. SIZING — a default percent_of_equity order is floored from the
//      ROUNDED equity (calc_qty): the lot count flips one lot early/late
//      when the exact equity is within half a money unit of a lot boundary
//      (~200 lab tv capital sweeps on OANDA:EURUSD 15 2025-04-01, scratch
//      famr-adm-*: revc 998763.3420484 -> 922832.66, 998763.3420503 ->
//      922832.67; S2 1001759.6342676 -> one lot BELOW the exact floor).
//      The divisor is the price AS TRADINGVIEW HOLDS IT — the tick count
//      times the mintick double (round_to_mintick; fl(1e-5) sits 8.2e-17
//      relative above 1e-5, so tick(1.085) is one ulp above double(1.085))
//      — and the lot floor is the RAW double floor, no 1e-6 nudge
//      (tv_money_floor_lot): famr-rev-everybar 2025-04-02 20:00Z, close
//      1.085, E 996097.5955029: Pine prints floor(E/close*100)/100 =
//      918062.30 while the broker filled 918062.29 = floor(sig10(E) /
//      tick(1.085) / 0.01), the quotient being 918062.29999999992 (round 9
//      family R follow-up, campaign note log-20260905t210117z-ab914192).
//   2. ADMISSION — a default 100 %-of-equity, margin-100 MARKET entry is
//      DROPPED iff the exact sizing equity is below the ROUNDED cost,
//      E_s < tv_money_round(Q x tick(close_S)); for a reversal only the
//      entry leg is dropped and the closing leg still fills (the fill-time
//      gate in engine_fills.cpp, ahead of the exact fill-price check).
//      Bare account: L06..L17 / FL00..02 (C = 1000000.0015396 ..
//      1000000.0019980) rejected, L18 (1000000.0020196) admitted against
//      round(1000000.0018862) = 1000000.002, flat p0000 (C == cost) admitted;
//      with a history: 24/24 close-leg-only rejections of the taro probe and
//      the every-bar sensors have E_s < round(cost), 0/3086 admissions do.
//   3. MARGIN CALL — a margin-100 LONG is liquidated (one contract, the
//      broker's minimum) at the first bar path point where the exact equity
//      is below the position value ROUNDED to 10 significant digits
//      (process_margin_call): revL L18..L25 16/16, taro 6/6 one-unit trims.
// Where equity ~ 1e6 and a lot is worth ~0.011 (EURUSD: qty step 0.01 at
// price ~1.1) the 0.0005 rounding crosses a lot boundary on ~9 % of all-in
// placements; on F / AAPL / indices (a lot is 10..250k) it crosses one only
// at an exact-decimal tie — and there it does (round 10 family AE, NASDAQ:
// AAPL 2025-09-05 16:15Z: E_s 1094521.68 = 4584 x 238.77 exactly; TradingView
// floors the ten-digit equity's raw double quotient 4583.999999999999 to
// 4583, the float-accumulated ledger's 4584.000000000001 or a 1e-6-nudged
// floor gives 4584, one share the account cannot pay at the 238.78 fill), so
// rule 1 sizes every lot-stepped instrument (tv_money_lot_sizing). Rule 2
// additionally covers ordinary, fee-free high-value fractional lots (R24),
// as does the price-scale check in rule 5 (R39). Other admission keeps its existing
// checks (1094521.681 -> Q 4584 dropped on AAPL). Rule 3
// additionally covers ordinary MARKET-opened, fee/slippage-free single-position
// fractional unit-pointvalue/same-currency books with lot value >=1 (R21 pins).
//   5. WHOLE-ORDER DROP (round 9 family R follow-up, campaign notes
//      log-20260905t205824z-af397c83 and log-20260905t210117z-ab914192;
//      the residual of log-20260905t180249z-4bd857ad): once the rounded-cost
//      admission (2) has passed, TradingView's broker runs its fill-time
//      margin check on the PRICE scale — the price at which the rounded
//      equity exactly buys Q, P = sig10( sig10(E_s) / Q ), must reach the
//      sizing price as the broker holds it, tick(close_S) = ticks x
//      fl(mintick). If P < tick(close_S) the WHOLE default market order is
//      dropped: the flat open does not fill and a reversal keeps its
//      position (the close leg is dropped too). P is rounded to ten
//      significant digits (1e-9 at ~1.08), so the comparison is a decimal
//      tie whenever sig10(E_s) - Q x close_S is within 0.5e-9 x Q (~0.00046
//      USD on EURUSD) — the sweeps' "band" — and a tie is decided by the
//      ulp of the tick-built price: dropped iff double(close_S) sits more
//      than 2.2e-17 below the decimal close (the half-ulp minus the 8.9e-17
//      the fl(1e-5) product carries). Rules 2 and 5 judge a TRUE-FLAT
//      placement and a bare strategy.entry REVERSAL, both on the frozen
//      signal-close equity E_s (4782/4782 taro + every-bar decisions; the
//      fill-marked equity fails 813). An opposite entry placed AFTER a
//      same-bar strategy.close and filling from flat takes rule 2 only
//      (round 12 AG-C1, six famag-C-cf-d tapes: four rounded-cost drops,
//      two admits). Rule 5 is excluded for that ordering; a deficit that
//      appears only at the fill is margin-called (demete1226 2025-04-04
//      02:30Z, 9.14 USD short after a one-pip gap down: 6008.48 'Margin call';
//      2025-04-07 08:00Z, E_s in rule 5's tie band, a six-pip gap up:
//      1 unit + 13681.2 'Margin call'). Pinned on 507 famr3 sweep
//      decisions
//      (famr3-F6: 153 bare-capital longs at C = sig10(cost) + 0.0002, 83
//      filled / 70 dropped, a pure function of the close; F7 7-digit ties
//      54/27 — the 10 closes where F7 fills and F6 drops all have sig10(B)
//      - B >= 0.000462, P rounding UP to close + 1e-9; F6h at + 0.0006
//      153/153 filled; T/A/B/R1/R2 reversals the same law), the taro probe
//      + every-bar sensors 3086/3086 admits, 1631/1631 whole drops, 64/64
//      close-only, and every one of the 52 famr-adm band tapes (revb b06..
//      b28, revd00..03, revL L24..L33, S100..S103, S307..S317). NOT
//      generalized: closing-transaction surplus outside the narrow round14
//      default100 rule-2 close-only shape. Its revL L23 / taro Sep15 residue
//      now requires a same-signal close-point MC receipt on the same lot;
//      Q-new minus live-position alone is explicitly refuted by TV controls.
// Round 10 family AB (BINANCE:ETHUSDT.P@15 hard lane, the corpus probe
// anomaly-equity-mirror-strategy-equity-01, campaign note
// log-20260905t213120z-d5f9e282) met rule 3 on an EXPLICIT-qty 1x long on a
// USDT book and landed it on main first (5239a36) under these helper names;
// round10/famR-main carries rules 1, 2, 4 and 5 on top of that one
// definition (tests/test_tv_money_long_margin_call_eth.cpp beside
// test_tv_money_precision.cpp and test_tv_money_band.cpp).
// tv_money_round is the NEAREST DOUBLE of the decimal rounding (the
// division by an exact power of ten is correctly rounded): rule 5 compares
// its result with a tick-built price at the ulp, so a floor(x/u+0.5)*u
// construction (n x fl(1e-9), 6.7e-17 above the decimal) would decide the
// ties wrongly — 100/507 on the famr3 sweeps.
inline double tv_money_round(double value) {
    if (!std::isfinite(value) || value == 0.0) return value;
    const double magnitude = std::floor(std::log10(std::abs(value)));
    const double scale = std::pow(10.0, 9.0 - magnitude);
    const double rounded = std::floor(std::abs(value) * scale + 0.5) / scale;
    return value < 0.0 ? -rounded : rounded;
}
// The broker's lot floor on ten-digit money (rule 1): the RAW double floor
// of the scaled quantity, no representation nudge — a nudge would promote
// the 918062.29999999992 quotient above to918062.30, one lot more than TV.
// R22 cent-lot pins: division by binary64(0.01) can lose a grid point that
// is exactly representable by qty. Try the *100 candidate only when its
// reconstructed grid quantity does not exceed the input. The 1.169 pin
// keeps8595.81; the older 1.085 pin still floors918062.29999999993 to918062.29
// because the next grid point is above that input. Other scales stay unchanged.
inline double tv_money_floor_lot(double qty, double step) {
    if (!(step > 0.0) || !std::isfinite(qty) || qty <= 0.0) return qty;
    double floored = std::floor(qty / step) * step;
    if (step == 0.01) {
        const double cent_candidate = std::floor(qty * 100.0) * step;
        if (cent_candidate > floored && cent_candidate <= qty)
            floored = cent_candidate;
    }
    return floored < qty ? floored : qty;
}

// Forward declaration of an internal enum used by some BacktestEngine
// method signatures. The full definition lives in src/engine_internal.hpp
// (private to libruntime); only the underlying-type pin is needed here.
namespace internal {
enum class DualEntryStopPathWinner : int;
}

struct PyramidEntry {
    double price;
    int64_t time;
    double qty;
    std::string entry_id;
    int entry_bar_index = -1;
    std::string entry_comment;
    double max_runup = 0.0;
    double max_drawdown = 0.0;
    // Intrabar-fill excursion masks: when a priced (stop/limit) entry fills
    // mid-bar, the portion of the bar's range traversed BEFORE the fill is
    // not part of the trade's excursion (TV convention). On the assumed
    // OHLC path (bar_path_uses_high_first), an extreme that occurs before
    // the fill position is excluded from update_per_trade_extremes sampling
    // for the fill bar only. Both default false (market/open fills sample
    // the full bar).
    bool skip_entry_bar_high = false;
    bool skip_entry_bar_low = false;
    // KI-62: this slice opened as a same-direction MARKET pyramid add (not the
    // base open, not a priced entry). When a from_entry priced bracket exit
    // fills on this add's OWN entry bar and after it in TV's open-tick fill
    // sequence, the exit covers (scratches) the add dur-0. Gated by
    // entry_bar_index == bar_index_ so prior-bar slices are never covered.
    bool market_pyramid_add = false;
    // Synthetic OHLC-path coordinate where a pure stop/limit strategy.entry
    // fired.
    // A single flat-born, non-trailing from_entry bracket may inspect only the
    // path suffix at/after this cursor on the entry bar. NaN marks every
    // unrouted parent class (market, stop-limit, raw order).
    double entry_path_position = std::numeric_limits<double>::quiet_NaN();
    // Entry-leg commission in account currency at this slice's actual fill
    // boundary. Percentage commission depends on quote->account FX, so an
    // effective-time provider must not retroactively reprice this already-paid
    // fee when a later rate becomes active. Partial realization allocates this
    // paid cost proportionally and leaves only the unconsumed cost on the lot,
    // independently of the current fee schedule. NaN is reserved for legacy/
    // synthetic injection; every production entry path captures a real quote.
    double entry_commission_account =
        std::numeric_limits<double>::quiet_NaN();
    // Monotonic per-run identity of the PendingOrder object whose broker fill
    // created this physical lot. Unlike Pine's user-visible entry_id, an
    // incarnation is never reused by same-id replacements or later calls.
    // Every partial-close fragment copied from this lot therefore retains the
    // same physical-entry provenance. Zero is reserved for legacy/test-only
    // synthetic lots that were not created by a PendingOrder.
    uint64_t entry_incarnation = 0;
    // A foreign/global or ambiguous same-ID bracket consumed part of this
    // physical lot by FIFO. Its logical slot cannot later be released merely
    // because an owner-bound bracket closes the last physical remainder.
    bool bracket_slot_shadowed = false;
    // Exact ordinary MARKET fill at the next bar open. Priced/RAW entries
    // cannot infer this provenance from an equal numeric entry price.
    bool ordinary_market_open = false;
    // Actual flat-born MARKET fill at the ordinary POOC terminal close.
    // Priced/RAW entries and orders born in fill callbacks do not acquire it.
    bool pooc_terminal_market_entry = false;
    // A flat-born pure STOP strategy.entry actually filled at the bar open.
    // Keep this separate from MARKET provenance: equal fill prices do not
    // make the two order classes interchangeable for affordability rules.
    bool ordinary_stop_open = false;
};

struct Trade {
    int64_t entry_time;
    int64_t exit_time;
    double entry_price;
    double exit_price;
    double qty;
    double pnl;
    double pnl_pct;
    bool is_long;
    int entry_bar_index = -1;
    int exit_bar_index = -1;
    std::string entry_id;
    std::string entry_comment;
    std::string exit_comment;
    std::string exit_id;
    // True when this trade's exit fill came from a REAL strategy.exit
    // bracket leg (stop/limit/trail/profit/loss), as opposed to a
    // strategy.close/close_all market close, a reversal-driven close, a
    // margin-call slice, or an intraday-cap close. Set at two sites:
    //   1. The shared exit-fill site (apply_filled_order_to_state,
    //      engine_fills.cpp) from the filling order: OrderType::EXIT AND
    //      its id does NOT carry the internal kClosePrefix ("__close__")
    //      marker (engine_internal.hpp) -- queue_deferred_close_order
    //      (engine_strategy_commands.cpp) also materializes a deferred
    //      strategy.close as an OrderType::EXIT PendingOrder (it reuses the
    //      same exit-fill qty/level machinery), tagged with that prefix
    //      precisely so this flag can tell the two apart.
    //   2. revive_position_brackets_after_margin_call_partial
    //      (engine_fills.cpp) -- a whole-position strategy.exit leg that
    //      fires at the margin-call event price bypasses the shared site
    //      (it calls execute_market_exit directly) but is still a genuine
    //      bracket fill (its own candidate loop already requires
    //      OrderType::EXIT and excludes kClosePrefix ids), so it sets this
    //      unconditionally true.
    // ABI v4 task 9: closed_trade_close_cause() reads this to distinguish
    // BRACKET (2) from SCRIPT (1); it is never set on a margin-call /
    // intraday-cap row (those stay false and are classified from exit_id /
    // exit_comment instead).
    bool exit_from_bracket = false;
    double max_runup = 0.0;
    double max_drawdown = 0.0;
    double commission = 0.0;
    // Physical-entry provenance copied from PyramidEntry. This is deliberately
    // separate from entry_id: Pine permits user-visible IDs to be reused.
    uint64_t entry_incarnation = 0;
    // True for the range-end close of a position still open after the final
    // bar (record_range_end_close_trades); false for every script-driven
    // or bracket exit. Mirrors pf_trade_t::open_at_end.
    bool open_at_end = false;
};

struct TradeC {
    int64_t entry_time;
    int64_t exit_time;
    double entry_price;
    double exit_price;
    double pnl;
    double pnl_pct;
    int is_long;
    // Max Adverse/Favorable Excursion expressed as $ move per unit qty.
    // max_runup is peak favorable move (price travel in direction of trade).
    // max_drawdown is peak adverse move (price travel against trade).
    double max_runup;
    double max_drawdown;
    double qty;
    double commission;           // mirrors pf_trade_t tail; semantics documented in pineforge.h
    int32_t entry_bar_index;
    int32_t exit_bar_index;
    int32_t open_at_end;         // ABI v3: 1 on the range-end close row (pineforge.h)
};

struct SecurityDiagC {
    int sec_id;
    int64_t feed_count;
    int64_t eval_complete_count;
    int64_t eval_partial_count;
};

// Per-bar runtime trace entry. The transpiler's ``trace`` pragma emits
// ``trace(name, value)`` calls inside the generated ``on_bar`` so the
// validator can replay engine-internal series alongside TradingView's own
// per-bar plot data and pinpoint the bar/filter where divergence appears.
//
// ``name_id`` indexes into ``ReportC::trace_names`` — names are interned
// once per unique label so the per-call cost is push_back of a 24-byte POD
// rather than a string copy.
struct TraceEntryC {
    int64_t timestamp;
    int32_t bar_index;
    int32_t name_id;
    double value;
};

struct ReportC {
    int total_trades;
    TradeC* trades;
    int trades_len;
    double net_profit;
    int64_t input_bars_processed;
    int64_t script_bars_processed;
    int64_t security_feeds_total;
    int64_t security_eval_complete_total;
    int64_t security_eval_partial_total;
    int64_t magnifier_sub_bars_total;
    int64_t magnifier_sample_ticks_total;
    int input_tf_seconds;
    int script_tf_seconds;
    int script_tf_ratio;
    int needs_aggregation;
    int bar_magnifier_enabled;
    SecurityDiagC* security_diag;
    int security_diag_len;
    // Per-bar trace records emitted by ``BacktestEngine::trace`` calls. Both
    // arrays are heap-allocated by ``fill_report`` and freed by
    // ``free_report``; both are nullptr / 0-length when tracing was disabled
    // or no calls were made. ``trace_names`` is a flat name table — each
    // ``TraceEntryC.name_id`` indexes into it. Pointers in ``trace_names``
    // are stable C-strings owned by the live ``BacktestEngine`` instance
    // (its ``trace_names_`` vector); they remain valid until ``strategy_free``.
    TraceEntryC* trace;
    int trace_len;
    const char** trace_names;
    int trace_names_len;
    pf_metrics_t metrics;
    pf_equity_point_t* equity_curve;
    int64_t equity_curve_len;
    // ABI v4: per-script-bar broker-state hash (empty unless recording enabled).
    uint64_t* broker_state_hash;
    int64_t   broker_state_hash_len;
};

enum class OrderType { MARKET, ENTRY, EXIT, RAW_ORDER };

// Order-local provenance for the one empirically pinned default-FIFO
// SHORT-seed collision. The broker book remains in its ordinary fill order;
// these roles only change the two transaction kernels after the complete
// prior-bar three-object shape has been proven.
enum class ShortSeedCollisionRole : uint8_t {
    NONE = 0,
    LONG_ENTRY,
    MATERIALIZE_LONG,
    FINAL_SHORT,
};

// PendingOrder crosses out-of-line helper boundaries independently of the
// engine class, so its changed layout must carry the same internal epoch.
using ExitLegLifecycle = exit_legs::Lifecycle;
inline namespace engine_script_run_v13 {
struct PendingOrder {
    std::string id;
    std::string from_entry;    // for exit orders
    OrderType type;
    bool is_long;
    ExitLegLifecycle legs; // canonical trigger definition and exit lifecycle
    double qty;                // NaN = use default sizing, else explicit qty
    int qty_type;              // -1 = qty is fixed contracts, else QtyType override
    double qty_percent;        // 100 = full position
    std::string oca_name;      // OCA group name
    int oca_type;              // 0=none, 1=cancel, 2=reduce
    int created_bar;           // bar_index when order was created
    int64_t created_seq = 0;
    // Fresh identity for this exact pending-order object. Unlike created_seq,
    // which intentionally survives same-id replacement to keep broker ordering
    // stable, incarnation is never copied or reused by a replacement.
    uint64_t incarnation = 0;
    // Exact live object whose priority slot this newly accepted order replaces.
    // Fresh and cancel-then-recreate orders carry zero. This is causal identity,
    // not a Boolean source-shape label: every entry, RAW and primary exit path
    // records its immediate predecessor before that object is erased. Reissued
    // extra exit legs are fresh objects and do not share the primary receipt.
    uint64_t replaced_order_incarnation = 0;
    // Exact default MARKET replaced on this source bar. A priced order or
    // a prior-bar carry with the same id does not prove this call topology.
    uint64_t replaced_default_market_incarnation = 0;
    // Broker cancellation receipt. Pine compatibility selects the causal
    // cancellation at its adapter boundary; the core retains one generic
    // source-bound result for every affected order and owns the once-only
    // close-claim release transition.
    OrderCancellationReceipt cancellation;
    // Incarnation of the live priced ENTRY removed by strategy.cancel(id)
    // earlier in the same source evaluation, copied only onto the first fresh
    // same-id strategy.entry call and then consumed. Zero means there is no
    // exact named-cancel -> fresh-recreate provenance.
    uint64_t recreated_after_named_cancelled_entry_incarnation = 0;
    // Incarnation of the unique attached EXIT child that was still live when
    // the parent above was named-cancelled. Copied with the parent cancel
    // token and consumed by the same fresh recreate call.
    uint64_t named_cancel_surviving_exit_incarnation = 0;
    // Entry stop-limit activation is durable broker state. Once the stop leg
    // fires, later bars—and later COOF scheduler segments on the same bar—
    // evaluate only the live limit leg until the order fills or is replaced.
    bool stop_limit_activated = false;
    // Concrete activation bounds belong to the currently bound exposure cycle.
    // Pine placement evidence is retained separately for explicit rebinding.
    ExitLegActivation leg_activation;
    PineExitActivationPolicy pine_exit_activation;
    // Immutable evaluation/fill origin, captured once for this incarnation.
    // Historical extreme-only/trailing permissions live in compat::pine.
    OrderBirth birth;
    // Disclosed Pine historical fill permission. Trigger fields can be
    // neutralized before deferred compaction; those mutations must not
    // rewrite a birth-time permission or masquerade as a different origin.
    PineHistoricalBirthReach pine_birth_reach = PineHistoricalBirthReach::Standard;
    // KI-67 exit cascade (Model S). Set at birth for a Pine historical-cascade
    // strategy.exit order: the historical-path LEG index (0 = O->W1, 1 = W1->W2,
    // 2 = W2->C) the triggering intrabar fill (coof_cursor_price_ "ap") landed
    // on — the "in-flight" leg. -1 when the order is not a mid-bar cascade exit,
    // or ap is off-path (roll). The gate holds the order on that leg's remainder,
    // lets it EXACT-level fill on every SUBSEQUENT leg, and (when
    // coof_cascade_inflight_fires) gap-fills it at the in-flight leg-end waypoint.
    int8_t coof_cascade_seg_i = -1;
    // KI-67 exit cascade: true when the exit may gap-fill at the in-flight
    // leg-end waypoint. Normally its level lies inside the in-flight remainder
    // in the trigger direction (Model S clause 1). The one scoped extension is
    // a marketable LIMIT born after a later same-O fill: it is held through leg
    // 0 and gets its gap attempt at W1. Marketable STOP never uses that extension.
    // Otherwise subsequent legs exact-fill, while a terminal/off-path order rolls.
    bool coof_cascade_inflight_fires = false;
    // Placement exposure used by this order. ENTRY/RAW capture the physical
    // side; Pine EXIT captures the exposure after earlier same-evaluation
    // close claims. This is not a universal physical-position snapshot.
    PositionSide created_position_side = PositionSide::FLAT;
    // Monotonic identity of the live position instance at placement. Side
    // alone is insufficient: a resting order can survive LONG -> SHORT ->
    // LONG and must not be mistaken for an order born in the later LONG
    // cycle. Zero means the order was created while broker-flat.
    int64_t created_position_cycle_seq = 0;
    // Call-bar provenance for the one deferred close_all whose post-fill
    // cleanup may preserve this order. Set only on a PRIOR-bar, pure-STOP
    // strategy.entry that was under the pyramiding cap and reused the id of a
    // physically-live same-side pyramid lot when close_all was called. The
    // cleanup requires both this value AND the paired incarnation below to
    // equal the ACTUAL order that flattened, so a same-call-bar earlier RAW or
    // close(id) fill cannot impersonate close_all. -1/0 means no provenance.
    int same_id_stop_deferred_close_all_bar = -1;
    uint64_t same_id_stop_deferred_close_all_incarnation = 0;
    // KI-65 priced-entry precedence uses the derived
    // placement_has_opposite_market_predecessor journal query. An accepted
    // flat-born priced ENTRY retains full reversal when its original book
    // contained an earlier opposite MARKET on the same source bar. Removed
    // same-id predecessors and placement-rejected calls do not contribute.
    // No independently writable predecessor result is stored on the order.
    // KI-65 MARKET/MARKET follow-up candidate. Every own-affordable explicit
    // MARKET call in the pinned broker scope carries this snapshot until the
    // next broker-processing boundary, where the complete source-bar set is
    // known. Only a set of exactly two distinct-id opposite calls is finalized
    // as a pair; larger sets remain ordinary source-ordered entries.

    MarketAdmissionDraft market_admission;
    double paired_flat_market_own_qty =
        std::numeric_limits<double>::quiet_NaN();
    double paired_flat_market_signal_close =
        std::numeric_limits<double>::quiet_NaN();
    double paired_flat_market_signal_equity =
        std::numeric_limits<double>::quiet_NaN();
    double paired_flat_market_signal_margin_pct =
        std::numeric_limits<double>::quiet_NaN();
    double paired_flat_market_signal_pointvalue =
        std::numeric_limits<double>::quiet_NaN();
    double paired_flat_market_signal_fx =
        std::numeric_limits<double>::quiet_NaN();
    // Finalized exact peer relation. Each side stores the other order's
    // created_seq; zero means unpaired. The mutual relation lets fill sorting
    // swap only this exact pair into TV's
    // buy-before-sell broker priority without reordering unrelated MARKET calls.
    int64_t paired_flat_market_peer_seq = 0;
    // Finalization-frozen broker transaction quantity for the paired order. The
    // earlier call carries its own qty; the later call carries
    // own + earlier-pending-own. This is deliberately separate from ``qty``:
    // ``qty`` remains the Pine call's own/target quantity and continues to drive
    // explicit-qty provenance, exit reservations, and every unpaired path.
    // NaN means ordinary strategy.entry reversal semantics.
    double paired_flat_market_transaction_qty =
        std::numeric_limits<double>::quiet_NaN();
    // Candidate provenance for the narrow omitted-qty, PoE=100, true-flat
    // MARKET/MARKET admission rule. Finalization waits for the complete source-
    // bar book and considers exactly two fresh, consecutive, distinct-id,
    // opposite entries. Without an over-equity gross transaction this remains
    // metadata only and does not change dispatch.

    // Snapshot of the position's quantity at the moment this order was
    // PLACED (0 if placed from flat). Used by execute_market_entry's
    // flat branch to apply TradingView's deferred-flip growth rule:
    // when a priced entry was placed against a position that was later
    // closed (by strategy.close, close_all, or any other path) and the
    // entry now fires from flat in the opposite direction, TV opens the
    // new position at ``qty + tv_carry_qty`` rather than ``qty``.
    // Verified empirically with probe 92's 20 deferred flips that fire
    // after the daily ``strategy.close_all`` cleanup, hours after the
    // closing bar — so this MUST persist across bars rather than being
    // a per-bar transient state.
    //
    // ``strategy.entry`` with the same id REPLACES the pending order
    // entirely — including a fresh ``tv_carry_qty = position_qty_``
    // snapshot. This is critical for probes 52 / 63 / 95 / 96 where
    // SE/LE is re-placed every bar a cross condition holds: once
    // ``strategy.close`` flushes the position to 0, subsequent
    // re-placements capture carry=0, so when the priced entry finally
    // fires the chain resets to qty=1 (matching TV's behaviour at
    // probe 52 trade 113). Preserving the largest observed carry
    // across re-placements would over-extend chains.
    //
    // The same placement snapshot also pins the equality-only M2 rule for a
    // priced explicit-FIXED same-cycle reversal: frozen broker transaction =
    // this held qty + the order's own quantized qty. If later same-direction
    // adds grow the live opposite position to exactly that transaction, the
    // fill closes to flat and opens no new leg. Other size relations retain
    // legacy reversal semantics; see apply_entry_order_fill.
    double tv_carry_qty = 0.0;
    // Quantity frozen at PLACEMENT (signal) time for a DEFAULT-sized (qty=na)
    // market order whose default sizing is price-dependent (percent_of_equity
    // / cash) — see frozen_default_market_qty. NaN = not frozen.
    //
    // Deliberately NOT stored in ``qty``: that field doubles as the "an
    // explicit qty was provided" flag, and several sites branch on
    // ``std::isnan(o.qty)`` to recover "was this order default-sized?" —
    // reduce_oca_group's default-sized cancel (engine_orders.cpp), the
    // pending-reversal-entry binding (engine_strategy_commands.cpp), the OCA
    // fully-filled heuristic and the partial-vs-full exit classification
    // (engine_fills.cpp). Writing a frozen quantity into ``qty`` silently
    // flips every one of them. Keep ``qty`` NaN; read this field only where a
    // quantity is actually computed.
    double frozen_default_qty = std::numeric_limits<double>::quiet_NaN();
    // Placement snapshot of a DEFAULT percent_of_equity <= 100 pure STOP
    // entry (round 7, family K default-percent stop-entry sizing; ledger note
    // log-20260905t084529z-c7b22df1, lab tv tapes scratchpad/r7/pins/
    // f15-stopsize-{pct100,pct50,short-only,short-m50}, NYSE:F 15
    // 2025-08-11..23). TradingView sizes the order when strategy.entry is
    // called, at the TICK-SNAPPED STOP LEVEL (buy stop ceil, sell stop floor):
    //
    //   qty = floor_step(equity(B) * pct/100 / (tick(level) + slippage))
    //
    // (pct100: 858 = floor(10,000 / 11.65) on the 08-19 13:30Z touch, 854 =
    // floor(10,000 / 11.70) on 08-22; 873 / 869 at the 11.45 / 11.50 closes
    // would be wrong; pct50: 450 / 444 / 441 = floor(0.5 eq / L) on the short
    // touches; margin 50: 901 / 886 / 880 = floor(eq / L)), then runs the
    // family-E placement check on that quantity at the tick-rounded CLOSE of
    // the call bar (qty * tick(close) * pv * fx * margin%/100 <= equity), so
    // an all-in sell stop BELOW the close is never placed (floor(eq/L) * C >
    // eq: 0 short fills over 3 touches in pct100, 0 fills in short-only —
    // not an opposite-order effect) while a buy stop above the close always
    // is. A stop whose level is already at or beyond the close is TV's
    // market-at-next-open order and is sized like one, at tick(close) +
    // slippage (frozen_sizing_price; ahtisham F@15 2025-04-04: the 13:30Z
    // close 9.335 -> 9.34 sizes 1,043 = 88 + 955 filled 13:45Z @9.34).
    // The quantity is fixed here — a resting order is never re-sized, only
    // the script's next call re-issues it — and is consumed by the fill-time
    // admission (stop_entry_margin_admission_declines: qty * tick(fill) <=
    // realized equity, the level on a touch, the rounded open on a
    // gap-through) and by dispatch. Explicit-qty / FIXED / CASH / >100%
    // stops carry no snapshot (family E). NaN means no snapshot: ordinary
    // fill-time sizing. Kept separate from frozen_default_qty so generic
    // MARKET consumers never see it.
    double default_stop_placement_qty =
        std::numeric_limits<double>::quiet_NaN();
    // strategy.equity as the script read it on the call bar (the placement
    // check's right-hand side), the tick-rounded call-bar close (its price
    // basis) and the sizing basis the quantity was divided at — tick(level)
    // (+/- slippage) or, for a beyond-level stop, tick(close) (+/- slippage).
    double default_stop_placement_equity =
        std::numeric_limits<double>::quiet_NaN();
    double default_stop_placement_signal_close =
        std::numeric_limits<double>::quiet_NaN();
    double default_stop_sizing_price =
        std::numeric_limits<double>::quiet_NaN();
    // TV margin-admission snapshot for a FROZEN default-sized market order
    // (KI-54). Captured at the same placement point as frozen_default_qty:
    //   sizing_equity = current_equity() + open_profit(tick(close(S)))
    //                   - paid commission on surviving open lots [account ccy]
    //   sizing_price  = tick(close(S)) + slippage*mintick*(+1 buy/-1 sell)
    // where tick(x) = round_to_mintick(x): the broker's sizing basis is the
    // mintick-ROUNDED signal close, never the raw feed print — see
    // frozen_sizing_price for the tape census behind that. sizing_mark is
    // the same tick(close(S)).
    // At fill time the broker re-checks (see the gate in
    // apply_filled_order_to_state for the full evidence trail)
    //   |qty| * admit_price * pointvalue * fx * margin_pct/100
    //     <= free_funds = sizing_equity - (same-direction held margin)
    // where admit_price is the SIZING price for flat opens and adds but the
    // FILL price for a true reversal (opposite position still open when the
    // order processes), and silently drops the order when it fails (no
    // trade row). The floor in apply_qty_step guarantees
    // qty*sizing_price*pv*fx <= sizing_equity ONLY for percent-of-equity
    // sizing with pct <= 100, margin <= 100, and sizing_equity > 0 — under
    // that invariant THIS KI-54 gate never declines a flat open no matter how
    // the bar gaps. (The percent==100 true-flat gap whose cost exceeds equity
    // — commission excluded from the test — that TV DOES decline on the FILL
    // notional is handled by a separate gap-reject carve-out that runs before
    // this admit; see the gate.)
    // It fails for CASH default sizing (no equity term), for pct > 100, for
    // margin > 100 (required scales past equity), and on a bankrupt account
    // (apply_qty_step returns qty UNFLOORED for qty <= 0, so |qty|*price ==
    // |sizing_equity| while free_funds < 0 — every order, flat opens
    // included, would be declined forever). The re-check is restricted
    // accordingly; orders outside it carry the snapshot and are admitted
    // here — CASH and pct > 100 MARKET entries by the unified
    // design-market-entry-affordability gate instead (affordability_* below).
    // NaN = no snapshot, no re-check.
    double sizing_equity = std::numeric_limits<double>::quiet_NaN();
    double sizing_price = std::numeric_limits<double>::quiet_NaN();
    // Quote->account FX observed at the same placement boundary as the
    // frozen quantity/equity/price tuple. A daily provider can roll between
    // the signal bar and next-bar fill; fill admission must adjudicate the
    // frozen signal snapshot, then the post-fill affordability pass applies
    // the fill-time rate and emits any required broker margin trim.
    double sizing_fx = std::numeric_limits<double>::quiet_NaN();
    // The bar close sizing_equity was marked at. free_funds subtracts the
    // margin the OPEN position ties up, and that must be marked at the same
    // price the equity was, or the two sides of the comparison mix a
    // mark-to-market total against a cost-basis deduction and the admission
    // threshold drifts with unrealized PnL in the wrong direction.
    double sizing_mark = std::numeric_limits<double>::quiet_NaN();
    // Direction-neutral placement-time provenance for the two fill-time
    // consumers of a frozen 100%-of-equity true-flat MARKET entry. True only
    // for a high-level MARKET call (either side) with omitted qty, a frozen
    // 100%-of-equity snapshot, direction-appropriate margin == 100, true-flat
    // placement, and no earlier paired close in this on_bar. Consumers:
    //   1. KI-61 entry-bar affordability EXEMPTION (engine_fills.cpp): the
    //      fill-time code independently re-checks the direction-appropriate
    //      margin (long_full_margin_after_fill / the default short shapes)
    //      and must additionally prove true-flat fill, sizing-price
    //      admission, success, and zero actual opening commission before
    //      treating either side as exempt (round 7 family M queues the
    //      default-sized short event with or without a commission).
    //   2. gap-reject (design-cntvxiao-gap-reject, engine_fills.cpp):
    //      direction-symmetric — silently drops the entry at fill when the
    //      frozen-qty notional at the slipped fill price exceeds sizing_equity
    //      at all (float guard only), commission EXCLUDED from the test
    //      (round-7 market-entry-admission pin); a fee-only shortfall still
    //      fills and takes the KI-61 trim.

    // design-explicit-qty-fill-admission: fill-time TV admission re-check for an
    // EXPLICIT-qty (the caller passed a finite qty) true-flat MARKET entry — the
    // explicit-qty sibling of the frozen gap-reject above, which the shipped
    // frozen fix deliberately left alone. Set at PLACEMENT in strategy_entry's
    // explicit-qty MARKET branch (the branch that does NOT freeze default
    // sizing). True only for a high-level MARKET strategy.entry with a finite
    // explicit qty, created TRUE-FLAT (created_position_side==FLAT &&
    // !created_after_position_close_in_bar), direction-appropriate margin_pct>0,
    // and finite snapshots. Fill-time consumer: the disjoint explicit-qty
    // decline branch in apply_filled_order_to_state silently drops the entry (no
    // trade row) when, at a still-FLAT fill, its notional at the SLIPPED FILL
    // price overshoots the placement equity snapshot with zero structural slack.
    // Commission is EXCLUDED from that predicate. Priced (limit/stop) entries
    // carry no snapshot (type==ENTRY, not MARKET); RAW strategy.order never sets
    // the flag. Evidence: probe-68 (data/probes/pf-probe-allin-floor-comm0,
    // 4,740 from-flat attempts, decline iff fill notional > equity, zero slack,
    // 99.94%); mdfe3757 306/306.

    // Placement-time equity snapshot (account ccy) for the explicit-qty gate:
    //   percent_commission_live_equity(close(S)) == realized equity when flat
    // Captured at the explicit-qty MARKET placement point. NaN = no snapshot.
    double explicit_placement_equity = std::numeric_limits<double>::quiet_NaN();
    // Slipped signal close at placement (frozen_sizing_price convention:
    // round_to_mintick(close(S)) + slippage*mintick*(+1 buy / -1 sell) — the
    // tick basis, so a POOC fill at the rounded close is an exact no-op on a
    // sub-tick feed too). Its |qty|-scaled notional
    // floors the fill-time decline threshold, so a fill AT/BELOW the slipped
    // signal close — POOC (fill == close(S)+slip both sides), a no-gap open, or a
    // favorable gap — is a structural no-op even with slippage != 0; only an
    // ADVERSE gap beyond the slip can decline. NaN = no snapshot.
    double explicit_slipped_signal_close =
        std::numeric_limits<double>::quiet_NaN();
    // design-market-entry-affordability: TradingView's broker admission for a
    // MARKET entry, pinned 2026-09-03 with `lab tv` on CME_MINI:NQ1! 15
    // (default fixed qty 1, margin 100: 10,212 flat-entry + reversal
    // decisions, 0 mismatches — pin-afford-{flat,reverse,gapup,gapdown,
    // gapup-ctl}) and on OANDA:XAUUSD 15 / NYSE:F 15 (explicit
    // qty = strategy.equity / close, commission 0.05% — pin-admit-allin-{xau,f},
    // 1279/1279 and 352/352 exact):
    //
    //   admit iff lot_floored(resulting_position_qty)
    //               * max(tick(close(S)), tick(fill)) * pv * fx * margin/100
    //             <= placement_equity + max(1e-9, |placement_equity| * 1e-12)
    //
    // evaluated TWICE: at placement on tick(close(S)) against MARK-TO-MARKET
    // equity (initial + net_profit + open_profit at close(S) — the NQ short
    // reversal at 2025-05-06 14:15Z filled with realized 396,625 < cost 397,995
    // but MTM 398,455 >= cost), and again at fill on tick(fill) against the
    // SAME placement snapshot (capital 380,000: signal close 18,820.50 =
    // 376,410 admitted, fill 19,225 = 384,500 -> NOT filled; capital 345,000:
    // signal close 17,483.25 = 349,665 -> rejected at placement although the
    // 17,100 fill would have cost 342,000; control capital 1e6 fills). The
    // "resulting position" is the new side's quantity on a reversal (the
    // closing leg's notional is not counted) and held + add on a
    // same-direction add (masayanfx NQ1 2025-07-30 20:15Z: 2 * 23,667.75 * 20
    // = 946,710 > MTM 945,225 -> TV dropped the add), with "held" frozen AT
    // PLACEMENT: a same-source-bar sibling that fills first does not enter
    // the later order's fill check (thula INR non-POOC short pair, TV rows
    // pinned in test_margin_call: both 2-lot shorts fill from flat and the
    // over-notional 4-lot position is then margin-called 2.6088, not
    // declined). Commission is NOT in
    // the notional and there is no max(equity, signal_notional) admission
    // floor: the rounded signal close is only a second decline trigger
    // (NYSE:F half-cent close 10.225 -> fill 10.23: floor(E/10.225) * 10.23 > E
    // declines; XAUUSD 2025-04-08 13:30Z: 662.968 -> 662.96 lots * 3013.75 <=
    // 1,998,000.02 admits where the raw 662.968 * 3013.745 would not).
    // A rejected reversal drops the ENTRY leg only — its closing leg still
    // executes (rampatel BTC 2025-05-12 07:15Z: TV closed the short by "Buy"
    // @105,600 and opened no long, equity 103,572 < 105,600; the engine used
    // to open it and cascade 4x-shortfall margin calls, 23,605 trades vs 1,486).
    //
    // Scope: high-level MARKET strategy.entry with an explicit qty OR default
    // FIXED / CASH sizing OR default percent_of_equity sizing ABOVE 100%
    // (round 6, pin-pct-afford 2026-09-04: NYSE:F 15, percent_of_equity 200
    // on 10,000 at margin 100 -> TV filled 0 entries, the same tape shape as
    // strategy.cash 20,000 — pin-cash-afford-m100 0 entries, -m50 filled).
    // Default percent_of_equity entries at or below 100% keep their own
    // pinned KI-54 / gap-reject / gross-admission family (not provably the
    // same rule: their reversal decline is atomic and holds the position);
    // the >100% regime had no admission at all (KI-54 requires pct <= 100).
    // NaN = no snapshot (out of scope, margin_pct == 0, non-finite close).
    //
    // Round 7 (design-stop-entry-placement-admission, ledger note
    // log-20260905t053924z-15615295): a pure STOP strategy.entry on the same
    // sizing partition takes the PLACEMENT half of this rule in
    // strategy_entry — lot_floored(qty) * tick(close(B)) * pv * fx * margin%
    // <= strategy.equity(B) (post-exit realized equity on a flattening bar,
    // new side only on a reversal); a rejected stop is dropped, never rests
    // or re-evaluates, and a rejected same-id re-issue cancels the resting
    // order of an earlier accepted issue. No snapshot is stored on a stop
    // (these three fields stay NaN/0): its fill-time half is
    // stop_entry_margin_admission_declines — the same floored qty at the
    // tick-rounded FILL price (the level on a touch, the rounded open on a
    // gap-through) against realized equity; only affordability_close_only
    // carries over, for a reversal whose entry leg was rejected. A DEFAULT
    // percent_of_equity <= 100 stop is outside both halves: no placement
    // check, and its fill-time gate keeps KI-62's bar-OPEN basis (the
    // ahtisham regression, engine_fills.cpp).
    double affordability_placement_equity =
        std::numeric_limits<double>::quiet_NaN();
    // tick(close(S)): the on-tick signal close the placement check costed,
    // and the floor of the fill-time admission price (max with tick(fill)).
    // Slippage ticks are NOT in either basis — the pinned rule is stated on
    // the rounded bar prices (all pins at slippage 0; the KI-65 explicit pair
    // and the percent_of_equity family keep their own slipped conventions).
    double affordability_signal_price =
        std::numeric_limits<double>::quiet_NaN();
    // The same-direction quantity held when the order was placed (net of a
    // strategy.close issued earlier in the same on_bar); 0 for a flat open or
    // a reversal. The fill check costs held + own with THIS value.
    double affordability_held_qty = 0.0;
    // The entry leg was declined (at placement or at fill) while an OPPOSITE
    // position was live: the order survives only as the reversal's closing
    // leg — apply_market_order_fill (MARKET) / apply_entry_order_fill (pure
    // STOP, round 7) closes the opposite position and opens nothing. Inert
    // (consumed, no broker effect) when the account is flat or same-side at
    // the fill.
    bool affordability_close_only = false;
    // Round14: only rule-2's rounded signal-cost decline can consume the
    // pending reversal's closing carry after a same-signal close-point MC.
    // These are order-owned receipts, not a last-margin-call heuristic.
    bool rounded_signal_cost_close_only = false;
    int signal_close_mc_bar = -1;
    uint64_t signal_close_mc_entry_incarnation = 0;
    uint64_t signal_close_mc_fill_seq = 0;
    double signal_close_mc_remaining_qty =
        std::numeric_limits<double>::quiet_NaN();
    std::string comment;       // order comment for trade reporting
    // Original exit amount and its latest resolved reservation basis. qty and
    // qty_percent remain the executable/reserved values used by existing Pine
    // reservation rules; their later reduction cannot rewrite caller intent.
    QuantityRequest quantity_request;
    // EXIT-owned exposure capture and source-owned exact receiver receipt.
    // The public legacy flags are one-way projections of these causal facts.
    ReservationExpansion reservation_expansion;
    ReservationGrowthSource reservation_growth_source;
    // round 8 family S — TradingView's same-bar MARKET transaction (ledger
    // note log-20260905t143024z-76025577; 15 lab tv sensor tapes famS-dbl-*,
    // famS-rev-plus-close, famS-adm-{es,nq}-{1e6,500k} on CME_MINI:ES1!/NQ1!
    // 15m 2025-04-01..15, every 8-bar cycle identical x115). Scope:
    // same_bar_market_tx_scope_is_live() — non-POOC, no COOF/magnifier,
    // pyramiding 0 (one admitted entry), FIXED default sizing, no risk policy.
    // Rules:
    //   (1) a MARKET entry's size is frozen at PLACEMENT and never re-sized
    //       at fill: own qty + the opposite position's qty at placement, net
    //       of the lots an EARLIER same-bar strategy.close already released
    //       (dbl-short-closefirst: Long buys 1, not 2), + the OPEN leg (own
    //       qty) of every opposite same-bar MARKET entry still pending at the
    //       call (dbl-short-q1-entry2: Short qty 2 sells 3; the KI-65 rule
    //       extended from flat to in-position).
    //   (2) a same-direction entry OVER the pyramiding cap is dropped at the
    //       call when no opposite same-bar MARKET entry is pending (dbl-short-
    //       swapped, dbl-long-full) and KEPT, sized by (1), when one was
    //       placed earlier in the bar (dbl-short-full: Short after Long sells
    //       2; dbl-long-mirror-closefirst: Long after Short buys 2 -> long 3
    //       before the sells). It is never re-roled at fill into a reversal
    //       sized on the fill-time position.
    //   (3) fill order = every BUY market order, then every SELL market
    //       order, each phase in placement order.
    //   (4) strategy.close(id) is created only if id holds a lot at the call,
    //       sized to that lot; at fill it exits what remains of that side
    //       (min(frozen, live)); when the side is gone it fills as a NEW lot
    //       in its own direction (TV's "Close entry(s) order X" entry row)
    //       iff an entry with the same id is still pending on the bar, and
    //       is cancelled otherwise (rev-plus-close, dbl-short-swapped).
    //   (5) strategy.close(id) with no lot of id at the call places nothing.
    // Admission (famS-adm-*): the kept over-cap entry is costed at placement
    // as held + own + the opposite pending open leg (3 lots: ES 1e6 admits
    // 3 x 5,627 x 50, NQ 1e6 declines 3 x 19,339 x 20 and admits the three
    // 04-07 cycles at <= 16,679; 500k declines both) — a declined entry is
    // dropped, so its same-id close finds no pending entry and is cancelled
    // (LONG 1, no artifact row). The generalized form of the short-seed
    // collision kernel (finding 272), with which it agrees on that book.
    // One typed source instruction. Transaction quantities live here; a
    // targeted close consumes quantity_request's resolved original Units.
    // Cap and closing-side facts remain the existing immutable placement
    // snapshots, rather than separately writable coordination booleans.
    PineFrozenMarketInstruction pine_frozen_market_instruction;
    // The cancellation receipt owns the placement-frozen close claim and its
    // once-only release state. The old scalar projections remain in the
    // public mirror, derived from cancellation.close_claim_*().
    ShortSeedCollisionRole short_seed_collision_role =
        ShortSeedCollisionRole::NONE;
};

// These views derive historical placement facts from the original command.
// No current position, current configuration or mutable sizing participates.
// The close fact describes previously accepted close claims, not physical
// flatness; even an immediate close can leave that source-time fact positive.
// The capacity view uses the original direction/count/cap (including cap0),
// which remains meaningful after fills or a later configuration change.
// Missing observations retain the historical default false for manual orders.
// The comparison matches the broker's existing quantity tolerance exactly.
inline bool placement_has_prior_close(const PendingOrder& order) {
    const auto& observation = order.market_admission.observation();
    return observation && observation->prior_close_quantity > 1e-10;
}
inline bool placement_at_entry_capacity(const PendingOrder& order) {
    const auto& observation = order.market_admission.observation();
    if (!observation) return false;
    const auto requested_side = observation->buy ? PositionSide::LONG : PositionSide::SHORT;
    return observation->placement_side != static_cast<int>(PositionSide::FLAT)
        && observation->placement_side == static_cast<int>(requested_side)
        && observation->held_entries >= observation->configuration.pyramiding;
}

// Reconstruct the one source-order dependency that is not part of the
// PendingOrder object. The producer scanned the physical book immediately
// before accepting this priced entry. The journal's immutable before/removed
// records preserve that exact scan, including a peer that remains physically
// resident after a cancellation. Direction is a raw book fact, independent
// of the peer's source Draft.
inline bool placement_has_opposite_market_predecessor(
        const MarketAdmissionJournal& journal, const PendingOrder& current) {
    const auto& origin = current.market_admission.observation();
    if (!origin || origin->kind != admission::CommandKind::Entry
        || current.type != OrderType::ENTRY
        || origin->placement_side != static_cast<int>(PositionSide::FLAT)
        || (std::isnan(origin->prices.limit) && std::isnan(origin->prices.stop)))
        return false;

    const admission::CommandEvent* accepted = nullptr;
    for (const auto& event : journal.events()) {
        const auto* command = std::get_if<admission::CommandEvent>(&event);
        if (!command || !command->observation
            || command->observation->command != origin->command
            || command->admitted_incarnation != current.incarnation) continue;
        if (accepted) return false; // refuse duplicate source identity
        accepted = command;
    }
    if (!accepted) return false; // pruned or unaccepted source
    const auto removed = [&](uint64_t incarnation) {
        return std::find(accepted->removed.begin(), accepted->removed.end(), incarnation)
            != accepted->removed.end();
    };
    for (const auto& peer : accepted->before) {
        if (removed(peer.incarnation) || peer.type != static_cast<int>(OrderType::MARKET)
            || peer.bar != origin->bar || peer.priority >= current.created_seq)
            continue;
        if (peer.buy != origin->buy) return true;
    }
    return false;
}

 } // inline namespace engine_script_run_v13 (PendingOrder)

// default_qty_type constants (matches TradingView)
enum class QtyType { FIXED = 0, PERCENT_OF_EQUITY = 1, CASH = 2 };

// commission_type constants
enum class CommissionType { PERCENT = 0, CASH_PER_ORDER = 1, CASH_PER_CONTRACT = 2 };

// Pine user enum → str.tostring (field payloads). Transpiler enforces enum decl before
// input.enum; this clamps the index so bad values never read past the table.
inline const std::string& pine_enum_str_at(const std::string* table, std::size_t n,
                                           int idx) {
    static const std::string kEmpty;
    if (n == 0 || table == nullptr) return kEmpty;
    std::size_t u = static_cast<std::size_t>(idx);
    if (u >= n) u = n - 1;
    return table[u];
}

struct SymInfo {
    std::string ticker = "UNKNOWN";
    std::string tickerid = "UNKNOWN";
    std::string currency = "USD";
    std::string basecurrency = "";
    std::string type = "crypto";
    std::string timezone = "UTC";
    std::string session = "24x7";
    std::string volumetype = "base";
    std::string description = "";
    double mintick = 0.01;
    double pointvalue = 1.0;
    // Per-instrument quantity step (syminfo.* "qty_step" — the smallest
    // tradable lot increment, e.g. 0.0004 for BINANCE:ETHUSDT.P). 0 = disabled
    // (the engine default), so no quantity quantization is applied — corpus
    // instruments leave this 0 and are byte-identical. Only the forced-
    // liquidation (margin call) path floors its computed lot to this step to
    // mirror TradingView, which nibbles the position in exact lot multiples.
    double qty_step = 0.0;
};

struct StrategyOverrides {
    double initial_capital = std::numeric_limits<double>::quiet_NaN();
    double commission_value = std::numeric_limits<double>::quiet_NaN();
    double default_qty_value = std::numeric_limits<double>::quiet_NaN();
    int pyramiding = -1;
    int slippage = -1;
    int commission_type = -1;
    int default_qty_type = -1;
    int process_orders_on_close = -1;
    int calc_on_order_fills = -1;
    int close_entries_rule = -1;
};

// The C++ subclass contract is internal, unlike pineforge.h's stable C ABI.
// Changing its layout or vtable requires all generated/native C++ objects to be rebuilt.
// v6 adds explicit owner-bound exit-leg activation and Pine placement evidence.
// Version the mangled class name so older headers' member offsets/vtable cannot
// silently bind out-of-line members of this different object layout.
inline namespace engine_script_run_v13 {
class BacktestEngine {
protected:
    friend class LegacyCompatibilityConsumer;
    friend class NativeExecutionConsumer;
    friend class NativeStrategyHost;
    struct NativeConsumerBindTag { explicit NativeConsumerBindTag() = default; };
    explicit BacktestEngine(NativeConsumerBindTag,
                            compat::pine::CapAttachment cap_attachment =
                                compat::pine::CapAttachment::None);
    IExecutionConsumer& execution_consumer();
    const IExecutionConsumer& execution_consumer() const;
    // --- Position state ---
    // @broker-state begin
    PositionSide position_side_ = PositionSide::FLAT;
    double position_entry_price_ = 0.0;   // volume-weighted average (for strategy calculations)
    // Owned, consumable post-fill checkpoint. The shared successful-fill
    // dispatcher supplies its producer and position identities; economic
    // eligibility is decided there, independently of this lifecycle model.
    broker::OpeningObligations opening_obligations_;
    int64_t position_entry_time_ = 0;
    // Position is FLAT until the first entry fires; the canonical
    // accessor ``signed_position_size`` already reads as 0 when FLAT
    // regardless of this default, but several internal carry- and
    // risk-gating reads (strategy_entry's tv_carry_qty capture,
    // check_risk_allow_entry's max-position check) read position_qty_
    // directly. A non-zero default leaks into those reads on the very
    // first call of any session, producing phantom carry growth (probe
    // 62 trade #1 fired qty=2 from a default-leaked carry=1) and
    // spuriously blocked entries when ``risk_max_position_size_=1``.
    // Initialising to 0 keeps the canonical and direct reads aligned.
    double position_qty_ = 0.0;
    int position_entry_count_ = 0;  // number of entries in current direction (for pyramiding)
    int position_open_bar_ = -1;    // bar_index_ when position was opened (for exit delay)
    // Exact position-instance provenance for pending orders whose semantics
    // depend on the position cycle in which they were placed. A fresh open or
    // reversal gets a new nonzero id; same-direction pyramid adds retain it.
    int64_t position_cycle_seq_ = 0;
    int64_t next_position_cycle_seq_ = 1;
    std::vector<PyramidEntry> pyramid_entries_;  // individual entries for trade reporting
    // Entry ids that have filled at least once in the CURRENT position cycle.
    // TV keeps a from_entry bracket live for the life of the POSITION, not the
    // life of its own entry leg: once the leg's units are FIFO-consumed by a
    // sibling bracket, the leg still fires against the remaining position
    // (thulashimohanr 06-17/10-14/01-14: Short's T2 closes a ShortAdd unit).
    std::set<std::string> cycle_filled_entry_ids_;
    // Per-entry-id UNCLOSED quantity ledger, used ONLY by strategy.close(id)
    // under the default FIFO close-entries rule to decide how much to close.
    //
    // TradingView's strategy.close(id) closes the quantity of the entries
    // tagged `id` that have NOT already been targeted by a prior close(id) —
    // it does NOT re-sum the physical open lots. That distinction is
    // invisible when each id maps to one lot (the common case), but it is
    // load-bearing for strategies that re-use one entry id across sequential
    // buy/sell cycles (grid bots): there, the FIFO trade-record drain removes
    // the OLDEST physical lot — which may carry a different id — leaving the
    // id-tagged lot physically present. Summing physical lots would then
    // double-count it on the next close(id) and over-close. This ledger
    // tracks "entered qty for id minus already-closed-by-close(id) qty for
    // id", so close(id) closes exactly the right amount (the whole position
    // for a same-id DCA pyramid; one slot for a grid cycle). It is never read
    // under the ANY rule (which closes id-matched physical lots directly).
    std::unordered_map<std::string, double> id_unclosed_qty_;

    // ── Same-bar strategy.close batching ──
    // Within one syntactic strategy.close callsite, TradingView keeps one
    // pending broker instruction: later runtime evaluations replace its
    // payload in place. Existing generated consumers omit a compiler token and
    // therefore keep one global compatibility batch; regenerated consumers
    // give every source callsite a nonzero token and thus an independent batch.
    // For each batch, the accepted replacement/ledger contract is:
    //   - the FIRST replaced call's id-ledger is provisionally consumed
    //     silently (no fill, no trade rows);
    //   - when both the prior and current batches contain exactly two calls,
    //     the prior batch's first admitted target is restored to that ledger.
    //     This is provenance from the broker replacement chain, not a physical-
    //     lot recount or ledger-minus-reservation calculation;
    //   - 3+ call batches never restore or create two-call provenance;
    //   - intermediate replaced calls keep their ledgers intact;
    //   - the SURVIVING (last nonzero-target) call fills min(ledger, avail) at
    //     the bar close. Its reservation is capped to the post-fill physical
    //     capacity left after older reservations;
    //   - a nonzero logical ledger with zero unreserved physical capacity is
    //     consumed without a broker fill;
    //   - a sole close call consumes its ledger and releases its reservation.
    // Calls whose target resolves to zero cannot replace a live instruction.
    // Fills execute at the end-of-bar order-processing point; full-close order
    // cancels/purges retain their established CALL-time timing.
    bool sb_close_active_ = false;
    int sb_close_bar_ = -1;
    int sb_close_calls_ = 0;          // effective distinct nonzero-target calls
    std::string sb_close_first_id_;   // first call, provisionally consumed at call 2
    double sb_close_first_target_ = 0.0;
    bool sb_close_first_carry_valid_ = false;
    double sb_close_first_carry_qty_ = 0.0;
    std::string sb_close_id_;         // surviving order's id
    std::string sb_close_comment_;    // surviving order's comment
    std::unordered_map<std::string, double> close_reserved_qty_;
    // Live exact-two-call replacement provenance. A survivor id maps to the
    // prior batch's FIRST target and remains valid only while its reservation
    // is live.
    std::unordered_map<std::string, double> close_two_call_first_qty_;

    // Nonzero compiler-token path. Every syntactic strategy.close site owns an
    // independent copy of the accepted replacement batch. Distinct sites all
    // flush; repeated runtime evaluations of one site replace only that batch.
    int callsite_close_bar_ = -1;
    uint64_t callsite_close_queue_seq_ = 0;
    struct SameBarCloseCallsite {
        uint64_t token = 0;
        bool active = false;
        int calls = 0;
        std::string first_id;
        double first_target = 0.0;
        bool first_ledger_consumed = false;
        bool first_carry_valid = false;
        double first_carry_qty = 0.0;
        std::string id;
        std::string comment;
        // Quantity admitted at call time. Distinct callsites reserve physical
        // capacity in source order; a later zero-capacity evaluation cannot
        // replace this pending instruction.
        double target = 0.0;
        // Persistent-reservation-blocked calls retain token-0's stale-ledger
        // cleanup, but only as a site-local overlay during Pine evaluation.
        // Shared mutation is deferred until every site's broker flush.
        std::vector<std::string> deferred_cleanup_ids;
        uint64_t queue_seq = 0;
        // round-4b F1: whether a sole-call flush retires id's ledger WHOLE.
        // True when the admitted target was capped by the position or by a
        // PRIOR-BAR (persistent) reservation (unclosed > persistent_avail)
        // — the pinned xlm/nvdax rule. False when it was not capped by
        // those, i.e. either uncapped (the debit then empties the ledger
        // anyway) or short SOLELY because of this bar's other pending
        // callsites (pending_reserved): that case is unpinned against TV,
        // and its zero-target sibling (the fresh A/A->B oracle in
        // enqueue_same_bar_close) performs no cleanup, so a partial
        // same-bar cap keeps the pre-F1 debit-by-target rule.
        bool retire_ledger_whole = true;
    };
    // Per-source-bar only. Cross-bar reservation/provenance is stored in the
    // owner-aware maps below, so a one-callsite generated strategy remains
    // behavior-identical to token 0 while distinct sites coexist.
    std::unordered_map<uint64_t, SameBarCloseCallsite> callsite_close_callsites_;
    // Net physical capacity claimed by the currently surviving nonzero-site
    // instructions on this source bar. This is distinct from
    // pending_close_qty_in_bar_, which records cumulative accepted logical
    // evaluations for the established later-entry carry rule.
    double callsite_close_admitted_total_ = 0.0;
    // Cross-bar replacement reservations/provenance belong to the syntactic
    // source site that created them. Token 0 continues to use the historical
    // id-only maps above without any behavior change.
    std::unordered_map<
        uint64_t, std::unordered_map<std::string, double>>
        callsite_close_reserved_qty_;
    std::unordered_map<
        uint64_t, std::unordered_map<std::string, double>>
        callsite_close_two_call_first_qty_;

    // --- KI-64: POOC script-visible position freeze ---
    // Under process_orders_on_close, a strategy.close/close_all that fills
    // IN-LINE (execute_immediate_close) mutates the broker position mid-on_bar,
    // but TradingView keeps the SCRIPT position accessor
    // ``strategy.position_size`` (signed_position_size(), and the
    // opentrades/position_avg_price na-guards derived from it) reporting the
    // PRE-close position until the NEXT bar. While ``pos_view_freeze_bar_ ==
    // bar_index_`` the script-facing signed_position_size() returns this frozen
    // snapshot. Ordinary POOC strategy.close(qty_percent) also sizes against
    // the snapshot's per-id quantities (round 12 AG-D); other broker/order
    // sizing and internal position_qty_ / position_side_ reads are unaffected.
    // Armed in strategy_close on the ordinary POOC
    // immediate-close path (NOT immediately=true, which is defined to reflect
    // its fill at once); cleared at the top of flush_same_bar_close() — the
    // first thing after every POOC on_bar — so step-4 and post-run reads see
    // the real position. The bar_index_ scoping is a defensive backstop: the
    // snapshot auto-expires when the script advances a bar even if a clear site
    // is ever missed.
    int pos_view_freeze_bar_ = -1;
    PositionSide pos_view_frozen_side_ = PositionSide::FLAT;
    double pos_view_frozen_qty_ = 0.0;
    std::unordered_map<std::string, double> pos_view_frozen_entry_qty_;

    // --- Strategy parameters (set from strategy() declaration) ---
    double initial_capital_ = 1000000.0;
    bool process_orders_on_close_ = false;
    // Historical fill-triggered recalculation is strictly opt-in. The false
    // branch in dispatch_bar remains the legacy control path.
    bool calc_on_order_fills_ = false;
    // Detached on bare native construction. Only the explicit Pine frontend
    // attachment can select its source-shape priority interpretation.
    compat::pine::OrderPriority pine_order_priority_;
    QtyType default_qty_type_ = QtyType::FIXED;
    double default_qty_value_ = 1.0;
    int pyramiding_ = 1;            // max additional entries in same direction
    CommissionType commission_type_ = CommissionType::PERCENT;
    double commission_value_ = 0.0;
    int slippage_ = 0;              // slippage in ticks
    double syminfo_mintick_ = 0.01; // tick size for slippage calculation
    // Per-instrument lot-size step for forced-liquidation quantization.
    // 0 = disabled (default; corpus no-op). Fed via the syminfo_metadata
    // channel ("qty_step") or the SymInfo struct on the explicit run() path.
    // process_margin_call floors each liquidation lot DOWN to a multiple of
    // this, matching TradingView's per-instrument margin-call lot sizing.
    double qty_step_ = 0.0;
    // Opt-in oracle candidate for the ambiguous finite-price margin case where
    // the documented minimum restore quantity floors to zero.  The established
    // default makes progress by one quantity step; selected historical exports
    // instead close the whole residual.  Keep that alternative default-off so
    // it cannot rewrite otherwise matching trade tapes.
    bool margin_zero_cover_full_liquidation_ = false;
    // Temporary Pine source facade: this value IS the sole compatibility
    // owner, not a mirrored limit/proxy. Existing generated statement-time
    // assignments explicitly opt in; generated constructors attach before
    // host metadata. Bare native construction leaves this policy unselected.
    compat::pine::IntradayCap max_intraday_filled_orders_;
    bool close_entries_rule_any_ = false; // true = "ANY", false = "FIFO" (default)
    // Percentage of margin required to open a long/short position. Default
    // 100 = 1x leverage (no leverage). TradingView's strategy() takes these
    // as ``margin_long`` / ``margin_short``; when the implied position value
    // (qty * fill_price * margin_pct / 100) exceeds the strategy's available
    // equity, TV silently rejects the fill — the entry simply does not appear
    // in the trade list. The PineForge engine mirrors that rejection in
    // execute_market_entry's FLAT and pyramid-add branches; without it, a
    // dynamic-qty strategy like community/IES, community/VCP, or
    // ies-probe-08 over-leverages on low-ATR bars and produces ~5x more
    // trades than TV. Validated by the matched-trade qty ratio in probe 08
    // exactly equalling engine_equity / TV_equity.
    double margin_long_ = 100.0;
    double margin_short_ = 100.0;

    // Account-currency FX multiplier for every quote->account money path. When a
    // strategy declares ``currency=currency.XXX`` differing from the symbol's
    // quote currency (e.g. currency.INR on a USDT-quoted perp), TradingView
    // denominates equity in the account currency but the position notional in
    // the quote currency, converting the latter via the account-currency FX
    // rate before the ``required_margin <= equity`` check. The engine otherwise
    // assumes account == quote (FX 1.0). Injected via the syminfo metadata
    // channel (key "account_currency_fx"); defaults to 1.0 so every corpus
    // strategy (which never sets it) is byte-identical. A timestamped provider
    // may override it as bars advance; the configured scalar remains the
    // fallback before the provider's first effective point and across reruns.
    double account_currency_fx_ = 1.0;
    std::vector<int64_t> account_currency_fx_timestamps_;
    std::vector<double> account_currency_fx_rates_;
    // Per-run broker clock for timestamped FX.  The epoch is the number of
    // provider points effective at the current script-bar open (0 means the
    // scalar fallback).  Consuming an epoch even while flat prevents a later
    // entry from being mistaken for a carried position when the rate has not
    // changed again.
    bool account_currency_fx_broker_epoch_initialized_ = false;
    std::size_t account_currency_fx_broker_epoch_ = 0;
    double account_currency_fx_broker_rate_ = 1.0;

    // TradingView force-liquidation (margin call) toggle. TV runs the broker
    // margin-call emulator by default, so this defaults ON to match TV. It is
    // a no-op for the validation corpus (long-only positions at the default
    // 100% margin can never be liquidated — the formula denominator
    // ``margin/100 - direction`` is 0 — and no corpus short is sized at full
    // equity), and can be switched off via ``set_margin_call_enabled`` for
    // callers that want the legacy hold-to-infinity behaviour.
    bool margin_call_enabled_ = true;

    // finding-308 margin-call intrabar chronology state. TV places the
    // forced-liquidation event chronologically on the synthesized intrabar
    // path, so a priced exit that fills strictly AFTER the bar's adverse
    // extreme (on the engine's own OHLC path) must let a pre-fill deficit
    // slice first. ``last_margin_call_event_bar_`` records the last
    // bar_index_ on which ANY margin-call trade row was booked (FX broker-
    // open rollover, pre-script/end-of-bar cascade, or the pre-exit slice); the
    // pre-exit hook consults it so at most one forced-liquidation event
    // fires per bar. ``intrabar_exit_margin_call_bar_`` is set by a pre-exit
    // slice or the scoped pre-script checkpoint and tells the later call that this
    // bar's adverse-extreme event was already consumed chronologically (the
    // surviving remainder is re-checked from the next bar on, preserving
    // TV's one-nibble-per-bar cascade).
    int last_margin_call_event_bar_ = -1;
    int intrabar_exit_margin_call_bar_ = -1;
    // Round 7 family N mechanism 2: the bar_index_ on which the finding-430
    // OPEN slice booked a partial that left a survivor. A same-bar declined
    // reversal (finding-311 KILL) then nets to LIVE brackets — TradingView's
    // sequence is decline -> dormant -> slice -> REVIVE-B, while the engine's
    // open slice runs at the broker-open boundary BEFORE the order loop
    // declines the reversal, so the revive would otherwise precede the kill.
    int open_margin_slice_bar_ = -1;

    int64_t trade_start_time_ = std::numeric_limits<int64_t>::min();

    // Cumulative qty of ``strategy.close`` / ``strategy.close_all`` calls
    // issued during the CURRENT on_bar. Reset at the start of every bar
    // before strategy logic runs. Subtracted from ``position_qty_`` when
    // computing ``tv_carry_qty`` for a subsequent ``strategy.entry`` in
    // the same on_bar — TradingView evaluates calls in source order, so
    // a ``strategy.close`` call ahead of a ``strategy.entry`` in the
    // same block makes the entry capture the POST-CLOSE position size
    // for its carry. Verified by probe 93 cycle B: when the strategy
    // calls ``strategy.close("L2")`` before ``strategy.entry("S2",
    // stop=...)``, TV's S2 fires from flat at qty=1 (no growth);
    // cycle A reverses the order and the entry captures the still-open
    // position size, firing later with qty=2 (growth).
    double pending_close_qty_in_bar_ = 0.0;


    // --- SymInfo + Input injection ---
    SymInfo syminfo_;
    int64_t last_bar_time_ = 0;
    int last_bar_index_ = 0;
    // Live-runtime tail semantics (spec §3.1, ABI v4): when true, the LAST
    // bar of the fed array is a still-forming bar, not the chart's rightmost
    // historical bar. See set_realtime_tail() and apply_realtime_tail_horizon().
    bool realtime_tail_ = false;
    int realtime_tail_horizon_bars_ = 0;
    // Live probe tail suppression (spec §3.2, ABI v4): when true, the LAST
    // array bar (is_tail_bar_) runs only dispatch_bar()'s pre-on_bar broker
    // steps and returns — the run's last-bar fills are the settled book's
    // fills against the forming bar, and the post-run book is the in-force
    // book. See set_probe_suppress_tail_logic(). Independent of
    // realtime_tail_ (do not couple them).
    bool probe_suppress_tail_logic_ = false;
    // Forced intrabar path order (ABI v4 live-runtime surface, task 4): 0
    // AUTO, 1 HIGH_FIRST, 2 LOW_FIRST. Any other value is clamped to AUTO by
    // set_path_order() -- this member is always one of {0,1,2}. Persistent
    // configuration, like realtime_tail_ / probe_suppress_tail_logic_ above
    // -- reset_run_state() does not touch it. See set_path_order() and the
    // PathOrderScope guard in engine_run.cpp that installs it as
    // internal::set_path_order_override for exactly the duration of one
    // run(). Applies to run() only: streaming ticks dispatched after
    // strategy_stream_begin (engine_stream.cpp) never go through a
    // PathOrderScope and always see AUTO regardless of this setting.
    int path_order_mode_ = 0;
    // True while dispatching the last array bar (the three run loops set
    // this right after bar_index_ = i). Read by dispatch_bar() to decide
    // whether to apply probe_suppress_tail_logic_. In
    // run_aggregation_bar_loop this is keyed off the INPUT index i, not the
    // emitted script-bar count -- see set_probe_suppress_tail_logic() for
    // why that is only a placeholder today.
    bool is_tail_bar_ = false;
    // Chart's display timezone — separate from ``syminfo_.timezone`` (the
    // exchange TZ). Set by ``set_chart_timezone`` / the C ABI's
    // ``strategy_set_chart_timezone``. See the doc on ``set_chart_timezone``
    // for why these two TZ slots must NOT alias.
    std::string chart_timezone_;
    std::unordered_map<std::string, std::string> inputs_;

    // Injected symbol metadata (syminfo.shares_outstanding_*,
    // recommendations_*, target_price_*, pricescale, minmove, …). These
    // have no source in an OHLCV feed, so the engine returns na<double>()
    // unless a data feed pushes a value via ``set_syminfo_metadata``. Keyed
    // by the Pine member name (e.g. "shares_outstanding_total").
    std::unordered_map<std::string, double> syminfo_metadata_;

    // Input injection helpers for generated code
    double get_input_double(const std::string& key, double default_val) const;
    int get_input_int(const std::string& key, int default_val) const;
    int64_t get_input_int64(const std::string& key, int64_t default_val) const;
    bool get_input_bool(const std::string& key, bool default_val) const;
    std::string get_input_string(const std::string& key, const std::string& default_val) const;
    // input.source: resolve a runtime override string ("open"/"high"/"low"/
    // "close"/"volume"/"hl2"/"hlc3"/"ohlc4"/"hlcc4") to the matching native
    // source series. Returns ``default_series`` (the codegen-resolved defval
    // series) when the key is absent OR the override string is non-native —
    // the analyzer hard-rejects non-native defvals, so a non-native override
    // can only arrive from an operator-supplied input value; never crash on it.
    const Series<double>& get_input_source(const std::string& key,
                                           const Series<double>& default_series) const;

    // syminfo.* fundamental/exchange metadata that has no OHLCV source.
    // Returns the value injected via ``set_syminfo_metadata`` for ``key``,
    // or na<double>() when none was injected. Codegen routes the
    // na-by-default SYMINFO_MEMBER_MAP double fields here.
    double get_syminfo_metadata(const std::string& key) const {
        auto it = syminfo_metadata_.find(key);
        return it != syminfo_metadata_.end() ? it->second : na<double>();
    }

    // --- Native source-series history (input.source) ---
    // input.source supports runtime override of WHICH price series feeds an
    // indicator. The generated subclass only materializes ``_s_<field>`` for
    // fields whose history it subscripts, so those cannot back a runtime
    // override to an arbitrary native source. These base-class series are the
    // canonical, always-resolvable backing store. They are advanced exactly
    // once per script bar (same cadence as the subclass ``_s_<field>``) by
    // ``_push_source_series()`` and only when ``_src_series_active_`` — the
    // generated ctor sets it true iff the script uses at least one
    // input.source, so scripts that don't pay nothing but the (small) member
    // footprint.
    bool _src_series_active_ = false;
    Series<double> _src_open_;
    Series<double> _src_high_;
    Series<double> _src_low_;
    Series<double> _src_close_;
    Series<double> _src_volume_;
    Series<double> _src_hl2_;
    Series<double> _src_hlc3_;
    Series<double> _src_ohlc4_;
    Series<double> _src_hlcc4_;

    // Advance every native source series by the current bar. Mirrors the
    // subclass ``_s_<field>`` idiom: push on the first tick, update intrabar
    // (magnifier). Called at each on_bar dispatch point; no-op when inactive.
    // A historical post-C fill recalculation remains barstate.isnew, but the
    // completed ordinary close execution already owns this bar's history
    // slot. Generated history/TA code uses the same predicate so that such an
    // execution recomputes the slot instead of appending a duplicate bar.
    bool history_advances_new_bar() const {
        return is_first_tick_ && history_slot_is_new_;
    }

    // issue #178: the previous CHART bar's close, tracked at every on_bar
    // dispatch regardless of _src_series_active_ (it costs two doubles).
    // A ta.atr / ta.tr call site inside a block that does not execute every
    // bar must read its true range against THIS value (TradingView pin,
    // 2026-09-06: 398/398 sparse executions on BINANCE:BTCUSDT 60), not
    // against the close of the site's previous execution. Advances once
    // per history slot (history_advances_new_bar()); intrabar ticks and a
    // fill recalculation of an owned slot refresh last_chart_close_ only.
    double prev_chart_close_ = std::numeric_limits<double>::quiet_NaN();
    double last_chart_close_ = std::numeric_limits<double>::quiet_NaN();
    double prev_chart_close() const { return prev_chart_close_; }

    void _push_source_series() {
        if (history_advances_new_bar()) prev_chart_close_ = last_chart_close_;
        last_chart_close_ = current_bar_.close;
        if (!_src_series_active_) return;
        const double o = current_bar_.open;
        const double h = current_bar_.high;
        const double l = current_bar_.low;
        const double c = current_bar_.close;
        const double v = current_bar_.volume;
        const double hl2   = (h + l) / 2.0;
        const double hlc3  = (h + l + c) / 3.0;
        const double ohlc4 = (o + h + l + c) / 4.0;
        const double hlcc4 = (h + l + c + c) / 4.0;
        if (history_advances_new_bar()) {
            _src_open_.push(o);   _src_high_.push(h);   _src_low_.push(l);
            _src_close_.push(c);  _src_volume_.push(v);
            _src_hl2_.push(hl2);  _src_hlc3_.push(hlc3);
            _src_ohlc4_.push(ohlc4); _src_hlcc4_.push(hlcc4);
        } else {
            _src_open_.update(o);   _src_high_.update(h);   _src_low_.update(l);
            _src_close_.update(c);  _src_volume_.update(v);
            _src_hl2_.update(hl2);  _src_hlc3_.update(hlc3);
            _src_ohlc4_.update(ohlc4); _src_hlcc4_.update(hlcc4);
        }
    }

    // --- Runtime state ---
    Bar current_bar_;
    int bar_index_ = 0;
    int bar_index_offset_ = 0;
    // Opt-in KI-55 chart warmup parity (see set_syminfo_metadata,
    // "chart_ema_na_warmup"). When enabled, chart-timeframe ta.ema instances
    // first used by on_bar na-warm per TV built-in semantics. This selector is
    // scoped independently from request.security so the two execution contexts
    // cannot leak their warmup mode into each other. Default OFF.
    bool chart_ema_na_warmup_ = false;
    // Independent opt-in KI-55 HTF warmup parity. When enabled,
    // request.security series aggregate from security_range_start_ms_ instead
    // of the feed start and their embedded ta.ema na-warm per TV built-in
    // semantics. The cut is taken per evaluator on HTF-BUCKET opens, not on
    // input timestamps: an input bar is dropped when the D/W/M (or intraday
    // grid) bucket it belongs to opened before the range start, so the first
    // HTF bar every series sees is a whole bucket that opened at/after the
    // range start (security_input_precedes_range_start). Default OFF;
    // consulted only by feed_security_eval_state and the historical
    // lookahead projection builder.
    bool security_range_start_na_warmup_ = false;
    int64_t security_range_start_ms_ = 0;
    // The run's first chart bar (0 outside a run). Without the flag above
    // this is the default cut for every coarser-than-chart and chart-
    // timeframe request.security aggregation: TradingView's deep-backtest
    // series of a timeframe hold the bars of that timeframe whose OPEN lies
    // at or after the range start, and the bucket in progress at the range
    // start is absent -- on every lane (round 8, family P: masayanfx
    // multi-time-score; lab tv famp-sense-{es15full,nq15full,f15full,
    // nifty15full,nifty1d,xau1d,xau15,eur15,eth15,btc1d}, 2026-09-05: "D"
    // on CME_MINI:ES1! 15m first reads on the 05-01 20:45Z bar (bucket 0 is
    // the 04-02 trade date; the 04-01 date opened 03-31 22:00Z before the
    // 04-01 00:00Z range start), "240" on 04-04 13:45Z (the 22:00Z bucket
    // dropped), "W" on the 08-29 / 08-28 bar on every 15m and 1D lane (the
    // Mon 03-31 week dropped), while "60" on a 00:00Z start and "D" on the
    // NYSE / NSE lanes (the chart's first bar IS the session open) keep
    // their first bucket). Whether the bucket was in progress is read from
    // the auxiliary 1m feed (did it trade between the bucket's nominal open
    // and the first chart bar? the NSE week whose Monday was a holiday opens
    // on Tuesday and is kept). Historical intraday single-feed forex/cfd D
    // requests also omit their partial first session, using its actual trading
    // open rather than its label. Other single-feed series keep their feed-start
    // behavior; native feeds retain their own rules. Lower-TF evaluators are
    // untouched (their slices begin at the first chart bar anyway), and the
    // flag above keeps its explicit epoch plus the EMA na-warmup semantics.
    int64_t security_first_chart_bar_ms_ = 0;
    // Timestamp of the input bar that FOLLOWS the one being fed to the
    // request.security evaluators; 0 = unknown (streams, the feed's last
    // bar). A historical run holds its whole feed, and the calendar
    // aggregator uses the hint to finalize a D/W/M bucket on the period's
    // actual last chart bar -- early closes and exchange holidays included
    // (TimeframeAggregator::feed(bar, next_input_ms)). Set by the run loops
    // per input bar, per auxiliary bar on the split-feed path, per sub-bar
    // under the magnifier; never by the stream path.
    int64_t security_next_input_ms_ = 0;
    // Nominal close (TradingView's time_close) of the CALLING chart bar the
    // input bar being fed belongs to; 0 = the input bar is the chart bar
    // (single-feed runs, streams). Set per native chart bar on the
    // split-feed path, where a finer auxiliary slice advances
    // request.security under a D/W/M chart bar whose close an OTC
    // calendar bucket compares against the period's nominal close
    // (TimeframeAggregator::feed(bar, next_input_ms, calling_close_ms)).
    int64_t security_calling_close_ms_ = 0;
    // Opt-in historical-only request.security lookahead projection. TradingView
    // can merge a completed higher-timeframe bar onto the first chart child
    // when a finite historical batch is already known. The normal engine path
    // remains progressive, and stream warmup/realtime deliberately ignore this
    // selector so future data can never leak into a live continuation.
    bool historical_security_lookahead_projection_ = false;
    bool historical_security_lookahead_projection_active_ = false;
    int64_t next_order_seq_ = 1;
    uint64_t next_order_incarnation_ = 1;
    uint64_t exit_leg_event_seq_ = 0;
    // TV: at most one priced ENTRY "open" event per bar; persists across
    // multiple process_pending_orders calls (bar magnifier) and dual-pass
    // opposing-stop resolution (see engine_fills.cpp).
    int priced_entry_activity_bar_ = -1;
    bool priced_entry_filled_this_bar_ = false;

    // Transient: true only while applying a priced (stop/limit/trail) fill
    // (apply_filled_order_to_state). emit_close_trade reads it to fold the
    // pre-exit-fill portion of the current bar's OHLC path into the closing
    // trade's excursion (per-bar sampling can't see the exit bar — the
    // pyramid entry is gone before the next update_per_trade_extremes).
    bool fold_exit_path_extremes_ = false;
    // Transient companion for TRAIL exits: the trail's best (peak) price at
    // fill time. The peak that armed the trailing stop is by definition a
    // pre-fill favorable excursion of the closing trade (TV reports
    // MFE == fill + offset == peak), but first_touch_position can't place a
    // trail fill on the bar path (the level is only active after the peak),
    // so emit_close_trade folds the peak directly. NaN = not a trail fill.
    double fold_exit_trail_peak_ = std::numeric_limits<double>::quiet_NaN();
    // Set by evaluate_fill_price: the just-evaluated exit fill fired on the
    // TRAIL leg (vs stop/limit/gap). Consumed by apply_filled_order_to_state
    // to reconstruct the trail peak above.
    bool last_exit_fill_was_trail_ = false;
    // Transient: true only while dispatching a LIMIT-triggered fill
    // (apply_filled_order_to_state). apply_fill_slippage reads it to route
    // limit fills onto the unslipped limit-or-better path (apply_limit_fill)
    // while market/stop/trail fills keep apply_slippage. Always false
    // outside the dispatch window, so strategy.close / end-of-run /
    // intraday-cap synthetic closes stay on the market (slipped) path.
    bool current_fill_is_limit_ = false;

    std::vector<Trade> trades_;
    // TradingView's range-end accounting (record_range_end_close_trades,
    // engine_orders.cpp): the rows that close a position still open after
    // the final script bar, at that bar's close. Report-only — they are
    // merged behind trades_ by fill_trades_section and never enter trades_,
    // the realized sums, or the live position (a stream continues it).
    std::vector<Trade> range_end_trades_;
    std::vector<PendingOrder> pending_orders_;
    // A rejected strategy.entry call leaves no PendingOrder behind. The exact
    // collision gate can consume only the immediately preceding source bar, so
    // one scalar tombstone is sufficient and cannot grow with feed length.

    // Actual command/review/sizing causes; policy history is a transient fold.
    MarketAdmissionJournal market_admission_journal_;
    // Evaluation-scoped tombstones for live priced ENTRY objects actually
    // removed by strategy.cancel(id). invoke_chart_on_bar clears the map
    // before each script execution; the first fresh same-id strategy.entry
    // consumes the unique cancelled incarnation.
    struct NamedEntryCancelContext {
        uint64_t entry_incarnation = 0;
        uint64_t surviving_exit_incarnation = 0;
    };
    std::unordered_map<std::string, NamedEntryCancelContext>
        named_entry_cancelled_incarnation_in_current_eval_;

    // strategy.exit partial orders are one-shot per open position for a given id
    std::unordered_set<std::string> consumed_partial_exit_ids_;

    // Reusable scratchpad for the per-call opposing-stop deferral set in
    // process_pending_orders. Holds the ids of flat-issued entry stops that
    // lost the intra-bar path race in pass 0 and are reconsidered in pass 1.
    // Cleared at the start of each process_pending_orders call; the retained
    // capacity avoids a fresh heap allocation 2-4x per bar. Typically tiny
    // (0-1 entries). Not state — must be empty across calls.
    std::unordered_set<std::string> scratch_skip_ids_;

    // Reusable scratch for process_pending_orders (capacity persists across
    // calls, mirroring scratch_skip_ids_). Incarnations survive OCA erasure;
    // vector indices and retained replacement priorities do not identify an
    // object. Always cleared before use; never persistent cancellation state.
    std::vector<uint64_t> scratch_filled_incarnations_;

    // Per-PASS dual-entry-stop arbitration winner (a flat position resting
    // one long stop-only ENTRY + one short stop-only ENTRY, both touched
    // this bar -- dual_entry_stop_path_winner, engine_path_resolve.cpp).
    // Reset to None at the top of every process_pending_orders CALL (a
    // process_orders_on_close_ script bar calls it twice per bar -- old-
    // order settlement, then new-order fills -- and each pass re-derives
    // its own flat-position winner) and written where that arbitration is
    // decided. This is working state, NOT the public accessor's value --
    // it goes back to None the moment the winning side fills (position no
    // longer FLAT) or its admission is declined (the release at the
    // `path_winner_stop_margin_decline` site below), even though a real
    // arbitration happened this bar. last_bar_dual_entry_path() reads
    // last_bar_dual_entry_decision_ (below) instead, precisely to survive
    // that. Only the standard (non-calc_on_order_fills) dispatch path
    // updates this; the COOF scheduler's process_next_pending_order keeps
    // its own unrelated local of the same computation and does not persist
    // it here.
    internal::DualEntryStopPathWinner dual_entry_path_{};
    // Per-BAR snapshot of the above: the last non-None value
    // dual_entry_path_ took during this bar, surviving whatever
    // dual_entry_path_ itself does afterward (a fill, a declined admission
    // release, or the next process_pending_orders call's reset). Reset to
    // None once per bar -- at the top of dispatch_bar() and, for the bar
    // magnifier (which never reaches dispatch_bar), where bar_index_
    // advances for each emitted script bar in run_aggregation_bar_loop --
    // and written ONLY alongside dual_entry_path_'s own arbitration write
    // (engine_fills.cpp), never at the declined-admission release. ABI v4
    // live-runtime surface (task 4): this is what last_bar_dual_entry_path()
    // returns, so a live probe (or an ordinary POOC run, tail-suppressed or
    // not) reads the bar's real arbitration even if the winning order later
    // filled, was declined, or the working state otherwise moved on. Same
    // calc_on_order_fills_ caveat as dual_entry_path_ above.
    internal::DualEntryStopPathWinner last_bar_dual_entry_decision_{};

    // --- Trailing stop state ---
    // Best favorable price since position entry (for trailing stop computation)
    double trail_best_price_ = std::numeric_limits<double>::quiet_NaN();
    // The script bar on which a strategy.exit re-issue restarted
    // trail_best_price_ from the bar's CLOSE under process_orders_on_close
    // (round 9 family Z's restart rule, round 10 family Y's bar rule). The
    // restarted extreme is the NEW order's, and that order's path starts at
    // the next bar's open: the same bar's high/low must not be folded into
    // it by the close-time process_pending_orders that follows the script
    // body (update_trail_best_for_bar_open skips this bar). -1 = none.
    int trail_close_restart_bar_ = -1;
    // The position's running extreme as it stood BEFORE the current bar's
    // high / low were folded in (update_trail_best_for_bar_open), and the
    // bar it was captured on: a trail leg killed by a declined reversal on
    // this bar restarts from it (round 10 family AE,
    // PendingOrder::dormant_trail_best).
    double trail_best_before_bar_ = std::numeric_limits<double>::quiet_NaN();
    int trail_best_before_bar_index_ = -1;
    // The ordinary POOC close scan may revisit a retained trail with that
    // same pre-bar extreme only while the carried position is unchanged.
    // A new cycle, add, reduction or close-time trail restart keeps its own
    // established path state instead of inheriting an earlier position's.
    int64_t trail_best_before_bar_position_cycle_ = 0;
    uint64_t trail_best_before_bar_fill_seq_ = 0;

    // Generic synchronous close obligation. Pine quota/cause/beneficiary
    // state remains exclusively in the compatibility facade above.
    broker::PositionCloseObligation position_close_obligation_;

    // Temporary legacy adapter: only value facts cross into Pine policy.
    compat::pine::CapClock pine_cap_clock() const {
        if (!max_intraday_filled_orders_.needs_clock()) return {};
        const BarTime bt = compat::pine::IntradayCap::uses_chart_clock(syminfo_.session)
            ? _decompose_bar_time_chart_tz() : BarTime{};
        return {current_bar_.timestamp, syminfo_.session, syminfo_.timezone,
                bt.dayofmonth, bt.month};
    }
    compat::pine::Calculation pine_cap_calculation() const {
        return {process_orders_on_close_, calc_on_order_fills_, coof_scheduler_active_,
                bar_magnifier_enabled_, stream_warmup_mode_,
                (stream_phase_ == StreamPhase::IDLE), !close_entries_rule_any_, bar_index_};
    }
    static compat::pine::Side pine_cap_side(PositionSide side) {
        return side == PositionSide::FLAT ? compat::pine::Side::Flat
            : side == PositionSide::LONG ? compat::pine::Side::Long
                                         : compat::pine::Side::Short;
    }
    static compat::pine::OrderKind pine_cap_kind(OrderType type) {
        return type == OrderType::MARKET ? compat::pine::OrderKind::Market
            : type == OrderType::ENTRY ? compat::pine::OrderKind::Entry
                                       : compat::pine::OrderKind::Other;
    }
    compat::pine::MatchedAttempt pine_cap_attempt(const PendingOrder& order) const {
        return {pine_cap_kind(order.type), order.incarnation, order.created_bar,
                order.is_long, pine_cap_side(position_side_), position_entry_count_, pyramiding_};
    }
    // Source facade retained for existing native fixtures. RAW placement does
    // not call this gate; extraction must not add one to that path.
    bool _intraday_cap_currently_latched() {
        return max_intraday_filled_orders_.placement(pine_cap_clock())
            == compat::pine::Placement::Deny;
    }

    // --- Cached trade metrics (updated incrementally in execute_market_exit) ---
    double net_profit_sum_ = 0.0;
    // Conservative absolute roundoff accumulated by additions to the cached
    // net-profit sum. This is numerical provenance only: reported PnL and
    // equity continue to use the unchanged sum above. Infinity means a
    // narrower margin comparison cannot be justified from this history.
    double net_profit_roundoff_bound_ = 0.0;
    // The net value whose additions this bound tracked. Direct/synthetic or
    // future restore writes without matching provenance cannot narrow the
    // established margin comparison; the next trade makes them unbounded.
    double net_profit_roundoff_value_ = 0.0;
    double gross_profit_sum_ = 0.0;
    double gross_loss_sum_ = 0.0;
    int win_trades_count_ = 0;
    int loss_trades_count_ = 0;

    // --- Equity extremes for max_drawdown / max_runup ---
    double max_equity_ = 0.0;    // peak equity for drawdown
    double max_drawdown_ = 0.0;  // maximum drawdown (positive number)
    double max_runup_ = 0.0;     // maximum runup (positive number)
    double min_equity_ = 0.0;    // trough equity for runup

    // --- Per-script-bar equity curve (metrics + pf_report_t exposure) ---
    std::vector<pf_equity_point_t> equity_curve_;
    int64_t bars_in_market_ = 0;     // script bars with an open position at close
    double first_bar_open_ = std::numeric_limits<double>::quiet_NaN();  // buy&hold basis

    // --- Per-script-bar broker-state hash recording (ABI v4 live-runtime
    // surface, task 6). Default off: empty vector, empty report array,
    // every historical run byte-identical to before this flag existed. See
    // set_broker_state_hash_recording() and broker_state_hash(). ---
    bool broker_state_hash_recording_ = false;
    std::vector<uint64_t> broker_state_hashes_;

    // --- Position-size extremes (strategy.max_contracts_held_*) ---
    double max_contracts_held_all_ = 0.0;
    double max_contracts_held_long_ = 0.0;
    double max_contracts_held_short_ = 0.0;

    // --- Even-trade counter (strategy.eventrades) ---
    int eventrades_count_ = 0;

    // --- Risk management (strategy.risk.*) ---
    enum class RiskDirection { BOTH, LONG_ONLY, SHORT_ONLY };
    RiskDirection risk_direction_ = RiskDirection::BOTH;
    int risk_max_cons_loss_days_ = 0;       // 0 = unlimited
    double risk_max_drawdown_ = 0.0;        // 0 = unlimited
    bool risk_max_drawdown_is_pct_ = false; // true = percent_of_equity mode
    double risk_max_intraday_loss_ = 0.0;   // 0 = unlimited
    bool risk_max_intraday_loss_is_pct_ = false; // true = percent_of_equity mode
    double risk_max_position_size_ = 0.0;   // 0 = unlimited

    // Risk state tracking
    int cons_loss_day_count_ = 0;
    int last_loss_day_ = -1;
    bool risk_halted_ = false;
    double intraday_pnl_ = 0.0;
    int intraday_pnl_day_ = -1;

    // TradingView's strategy.risk.max_intraday_loss (round 7 family M
    // mechanism 5b, pinned 2026-09-05 by lab tv m45-risk-t1/t6/t9/t3b on
    // BINANCE:BTCUSDT 1D and the JOAT probe's threshold ladder
    // m45-joat-risk-*): the rule keeps the DAY-START equity E_ds = realized
    // + the open position marked at the chart-tz day's first tick, and at
    // every emulated tick compares loss = E_ds - (realized + open P&L at
    // the tick) with pct% of E_ds (percent_of_equity) or the absolute
    // value. A fill that CLOSES position quantity is checked with the
    // position already gone but its own realized P&L NOT yet booked, so a
    // profitable exit whose day-start open profit was >= the threshold
    // fires (the JOAT 2026-02-06 short: open profit 2513.6 = 2.452% of
    // 102513.6 fires at 2.45, not at 2.46; the +2699 exit is a gain by every
    // other measure). Realized P&L booked earlier in the day counts at later
    // ticks (t9). Firing closes the position at the tick as "Close Position
    // (Max intraday Loss)", cancels every pending order and blocks every
    // order placement until the chart-tz day changes (t1: the close-calc
    // order of the fired day is dropped, the next day's fills). The rule
    // never latches risk_halted_ (that stays with max_drawdown /
    // max_cons_loss_days).
    double intraday_loss_day_start_equity_ =
        std::numeric_limits<double>::quiet_NaN();
    int intraday_loss_day_ = -1;         // chart-tz day key of E_ds
    int intraday_loss_block_day_ = -1;   // chart-tz day key while orders are blocked
    bool intraday_loss_evaluating_ = false;
    // A fire inside a fill loop defers the pending-order cancel to the
    // loop's safe point (finish_intraday_loss_cancel); the loop itself
    // removes every order it has not yet applied.
    bool intraday_loss_cancel_pending_ = false;
    // @broker-state end
    int intraday_loss_day_key() const;
    void intraday_loss_begin_bar(const Bar& bar);
    bool intraday_loss_orders_blocked() const;
    bool evaluate_max_intraday_loss(double mark_price, double excluded_realized);
    void evaluate_max_intraday_loss_over_path(const Bar& bar);
    void finish_intraday_loss_cancel();

    bool check_risk_allow_entry(bool is_long) const;
    void update_risk_state();

    // --- Per-trade extreme tracking ---
    void update_per_trade_extremes();

    // Source compatibility extension: settle an already resolved execution
    // using the current chart context and source-day preflight/observation.
    // This does not place an order, perform admission/slippage, or provide
    // cancellation/replay. Explicit native/context seams below are source-day
    // independent. The owning run must abort on an exception; failed commits
    // are not retryable in place. A saved plan is not execution authority.
    // Empty lifecycle effects. Member-pointer type is the original two-argument
    // symbol; it forwards to settle_execution_with_lifecycle.
    execution::Result settle_resolved_execution(
        const execution::Action& action, const execution::Fill& fill);
    // Source coordinator for one execution plus lifecycle effects and source days.
    // Pre-close operations, then close observations and old-cycle unbind, then
    // the listed pending removals, then the quoted opening path which binds
    // only remaining exits. Native settlement does not call compat::pine
    // selectors; the effects value is not retained.
    execution::Result settle_execution_with_lifecycle(
        const execution::Action& action, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle);
    execution::Result settle_native_execution_at(
        const execution::Action& action, const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context);
    execution::Result settle_with_context(
        const execution::Action& action, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context);
    execution::SettlementInspection inspect_native_settlement(
        const execution::Action& action, const execution::Fill& fill) const;
    // Synchronous selected-close extensions. Book preserves the original
    // action semantics; OpeningExposure permits only Flatten/Reduce and is
    // revalidated against the current physical book on every call.
    execution::SettlementInspection inspect_native_settlement_scoped(
        const execution::Action& action, const execution::Fill& fill,
        execution::CloseScope scope) const;
    execution::Result settle_native_execution_scoped_at(
        const execution::Action& action, const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context,
        execution::CloseScope scope);
    // --- Additive selected close (not a CloseScope overload) ---
    execution::SettlementInspection inspect_native_settlement_selected(
        const execution::Action& action,
        const execution::Fill& fill,
        const execution::SelectedOpeningSet& selection) const;
    execution::Result settle_native_execution_selected_at(
        const execution::Action& action,
        const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context,
        const execution::SelectedOpeningSet& selection);
    // Source lifecycle coordinator: current_bar_/fold context, source-day
    // preflight, selected commit, then observation of its committed close rows.
    // Empty lifecycle is valid. Do not fold selection into LifecycleEffects.
    execution::Result settle_execution_selected_with_lifecycle(
        const execution::Action& action,
        const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::SelectedOpeningSet& selection);
    // --- Additive non-applying account/effect projection ---
    execution::AccountEffectProjection project_native_settlement_v1(
        const execution::Action& action,
        const execution::Fill& fill) const;
    execution::AccountEffectProjection project_native_settlement_scoped_v1(
        const execution::Action& action,
        const execution::Fill& fill,
        execution::CloseScope scope) const;
    execution::AccountEffectProjection project_native_settlement_selected_v1(
        const execution::Action& action,
        const execution::Fill& fill,
        const execution::SelectedOpeningSet& selection) const;
    // Opposite-book reversal to an exact signed exposure. Unlike Transact,
    // the opening is not a remainder of transaction units minus held units.
    // These synchronous extensions share the settlement owner and do not
    // introduce a queued native request or saved commit authority.
    execution::SettlementInspection inspect_native_reversal_v1(
        const execution::ReverseTo& reversal,
        const execution::Fill& fill) const;
    execution::AccountEffectProjection project_native_reversal_v1(
        const execution::ReverseTo& reversal,
        const execution::Fill& fill) const;
    execution::Result settle_native_reversal_at_v1(
        const execution::ReverseTo& reversal,
        const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context);
    // Source reversal coordinator with current chart context and source days.
    execution::Result settle_reversal_with_lifecycle_v1(
        const execution::ReverseTo& reversal,
        const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle);
    // Native account value: realized balance plus marked physical lots minus
    // their remaining paid entry costs, for every fee type. No Pine sizing or
    // end-of-range reporting convention participates in this value.
    double marked_equity(double price) const;

    // --- Strategy order commands ---
    // NOTE: prior to v0.2 the runtime accepted a leading `double market_price`
    // positional after `is_long`. The implementation never read it; every
    // fill price came from `current_bar_.close` inside the function body,
    // and every closed-transpiler call site passed `current_bar_.close`
    // verbatim. Parameter dropped to match TradingView's `strategy.entry()`
    // surface. Consumer codegen must be regenerated alongside this commit.
    void strategy_entry(const std::string& id, bool is_long,
                        double limit_price = std::numeric_limits<double>::quiet_NaN(),
                        double stop_price = std::numeric_limits<double>::quiet_NaN(),
                        double qty = std::numeric_limits<double>::quiet_NaN(),
                        const std::string& comment = "",
                        const std::string& oca_name = "",
                        int oca_type = 0,
                        int qty_type = -1);
    void strategy_close(const std::string& id, const std::string& comment = "",
                        double qty = std::numeric_limits<double>::quiet_NaN(),
                        double qty_percent = std::numeric_limits<double>::quiet_NaN(),
                        bool immediately = false);
    // Keep the historical five-argument symbol above; regenerated legacy
    // sources continue to bind token 0. This does not promise that arbitrary
    // objects compiled against an older BacktestEngine class layout can be
    // relinked without rebuilding. New codegen supplies a stable nonzero token
    // for the syntactic strategy.close source site.
    void strategy_close(const std::string& id, const std::string& comment,
                        double qty, double qty_percent, bool immediately,
                        uint64_t callsite_token);
    void strategy_close_all();
    void strategy_exit(const std::string& id, const std::string& from_entry,
                       double limit_price, double stop_price,
                       double trail_points = std::numeric_limits<double>::quiet_NaN(),
                       double trail_offset = std::numeric_limits<double>::quiet_NaN(),
                       double trail_price = std::numeric_limits<double>::quiet_NaN(),
                       double qty_percent = 100.0,
                       const std::string& comment = "",
                       double qty = std::numeric_limits<double>::quiet_NaN(),
                       const std::string& oca_name = "",
                       double profit_ticks = std::numeric_limits<double>::quiet_NaN(),
                       double loss_ticks = std::numeric_limits<double>::quiet_NaN());
    void strategy_cancel(const std::string& id);
    void strategy_cancel_all();
    void strategy_order(const std::string& id, bool is_long, double qty,
                        double limit_price = std::numeric_limits<double>::quiet_NaN(),
                        double stop_price = std::numeric_limits<double>::quiet_NaN(),
                        const std::string& oca_name = "",
                        int oca_type = 0);

    void process_pending_orders(const Bar& bar, bool before_pooc_script = false);
    struct CoofFillResult {
        bool filled = false;
        double fill_price = std::numeric_limits<double>::quiet_NaN();
        uint64_t fill_events = 0;
        // A chart-extreme tick touch books at the tick print, but the path
        // advances from the raw H/L it actually reached. Never walk back from
        // an outward-rounded fill price into an already-consumed segment.
        double chart_waypoint_price = std::numeric_limits<double>::quiet_NaN();
        // A pinned group of resting stop siblings settles on one historical
        // adverse leg before one script recalculation. Broker fills remain
        // individually counted by fill_events and broker_fill_event_seq_.
        bool grouped_stop_recalc = false;
        // Physical lot opened by this actual fresh COOF MARKET fill. Only
        // its first callback may use this provenance; direct later fills do not.
        uint64_t market_entry_incarnation = 0;
    };
    CoofFillResult process_next_pending_order(const Bar& bar,
                                              bool allow_market_orders,
                                              int& exit_closed_from_bar,
                                              uint64_t& exit_closed_from_incarnation,
                                              bool& exit_closed_was_long,
                                              const Bar* chart_bar = nullptr);

    // TradingView forced-liquidation (margin call). Finite-price liquidation
    // paths use the bar's adverse extreme. A 100%-margin long instead uses
    // opening affordability and the separately scoped rounded-money checks.
    void process_margin_call(const Bar& bar);
    // Settle an opening money restore before a later eligible owned exit,
    // retaining the actual chart bar for financial-class eligibility.
    void process_carried_long_money_before_priced_orders(const Bar& bar);
    // Ordinary subcontract shorts and integer MARKET lots expose completed
    // liquidation to the close-time script (R23/R25/R28 TV controls).
    void process_short_margin_before_script(const Bar& bar);
    // An unchanged carried POOC short finishes its adverse-path margin event
    // before the close script observes or reverses it. The caller proves no
    // resting order filled earlier on this bar.
    void process_carried_pooc_short_margin_before_script(const Bar& bar);
    // finding-308: chronological pre-exit forced-liquidation slice. Called
    // from the process_pending_orders fill loop immediately BEFORE a priced
    // exit of the live position is applied. Fires only when (a) no margin
    // call was booked on this bar yet, (b) the bar's adverse extreme comes
    // STRICTLY earlier on the synthesized intrabar path than the exit's
    // fill (a tie — the exit filling exactly at the extreme — keeps the
    // exit first), and (c) the pre-fill position is already in margin
    // deficit at that extreme. The slice mirrors the adverse-cascade
    // trigger/slice arithmetic of process_margin_call byte-for-byte.
    // Returns true when a "Margin call" row was booked; the triggering exit
    // then fills the reduced remainder.
    bool margin_call_slice_before_priced_exit(const Bar& bar,
                                              double exit_fill_price,
                                              double exit_path_position);
    // finding-325 (1x-long entry-fill affordability chronology): TV runs the
    // 1x-long (margin_long=100) opening-affordability check AT THE ENTRY
    // FILL, chronologically before the same bar's intrabar exits. When a
    // priced exit of a just-opened 1x long is about to fill on the entry's
    // own bar and the floor-sized opening cost exceeds post-close equity,
    // the one-shot opening event books its trim FIRST — the ordinary
    // floor-before-4x quantity (including the sub-lot one-contract
    // fallback), filled at the RAW matched entry base, tagged "Margin call"
    // — and the exit then closes the reduced remainder. Consumes the
    // pending opening event; returns true when a slice was booked.
    bool margin_call_1x_long_opening_slice_before_priced_exit(const Bar& bar);
    // A timestamped FX rollover is a broker-open event, not an end-of-bar
    // adverse-price check.  Cell A1 supports carried 1x full-margin long and
    // short in ordinary historical dispatch; leveraged shapes stay fail-closed.
    // Returns true when it emits a broker liquidation row.
    bool process_carried_position_fx_rollover(const Bar& bar);
    // finding-430: forced liquidation at the bar OPEN. A carried position
    // with a finite liquidation price that already breaches the margin
    // requirement at the open is sliced AT THE OPEN (quantity computed at
    // the open price), before any resting order is evaluated there; the
    // survivor keeps its ordinary adverse-extreme check, so one bar can book
    // an open slice AND an extreme slice. Bars whose open does not breach
    // are untouched. Returns true when a "Margin call" row was booked.
    bool margin_call_slice_at_bar_open(const Bar& bar);
    // Round 7 family H residual (NYSE:F 1D short admission tape 2025-04-23 /
    // 2026-04-08): a strategy.close / close_all MARKET order for the WHOLE
    // position resting for this bar's open fills before the open's margin
    // evaluation — TradingView closes 1025 @9.84 through the pending close
    // where the engine sliced 48 @9.84 first. True when such an order rests
    // in the book (created on a prior bar, no priced leg, covers the whole
    // position) AND no opposite-side entry order rests for the same open:
    // a close paired with a reversal entry is voided when TradingView
    // declines that reversal by admission (pin log-20260905t111645z-
    // e1783b94), so the open slice must stand (round-8 regression on the
    // all-in reversal scripts: amandaborgeson06 F@15 2025-05-01 13:30Z,
    // hexatrades AAPL@15 2025-07-29 13:30Z). margin_call_slice_at_bar_open
    // then stands down only for the unconditional close. A partial close or
    // a priced exit the open gapped through keeps the open slice (unpinned).
    bool whole_position_market_close_rests_for_open() const;
    // Round 7 family L (campaign pin log-20260905t093952z-0c4938cb; lab tv
    // tapes scratchpad/r7/pins/xau15-mcpath-{a,b}, fresh-touch-once): on the
    // bar a position OPENS, TradingView marks the forced liquidation only
    // over the part of the synthesized O-H-L-C / O-L-H-C path AFTER the
    // entry fill — a bearish bar whose stop fill lies below the open never
    // sees that bar's high (asian-box 04-01 15:45Z: no slice; xau15-mcpath-a:
    // the slice comes on the next bar at its high), the bar CLOSE is a mark
    // point (fresh-touch-once: 8 @11.25 = the entry bar's close), and a fill
    // at the open (market, or a stop the open gapped through) sees the whole
    // bar (xau15-mcpath-b, mdfe3757 04-08 13:30Z: same-bar slice at the
    // high). Carried bars keep the whole-bar extreme.
    //
    // True when the just-opened position leaves a path suffix on `bar`:
    // *out_mark is the suffix's adverse extreme (RAW price — the waypoints
    // after the fill, the close included; the caller applies the cascade's
    // own mintick rounding), *out_pos its path position (waypoint index, in
    // first_touch_position's units). An unrouted fill coordinate (market /
    // open fills, stop-limit, raw orders) reads as the open, i.e. the whole
    // bar as before; a fill at the close has no suffix (false).
    bool entry_bar_post_fill_adverse(const Bar& bar, double* out_mark,
                                     double* out_pos) const;
    // The dispatch shapes the entry-bar path rule is pinned for: the position
    // opened on this bar under ordinary historical dispatch (no
    // process_orders_on_close, calc_on_order_fills, bar magnifier or
    // streaming). Everything else keeps the whole-bar extreme.
    bool entry_bar_margin_path_scope() const;

    // --- Fill rounding helpers ---
    // Nearest-tick rounding: TradingView's exact double-precision function
    // floor(price / mintick + 0.5) * mintick, with NO epsilon.
    //
    // finding-446: TV's own NASDAQ:AAPL and OANDA:EURUSD series carry
    // sub-tick prints (x.xx5 and a few 4-dp values). Every TV fill taken at
    // one of those RAW BAR PRICES is exactly this function of it: 24,582 /
    // 24,582 half-cent AAPL closes (22,122 rounded up, 2,460 rounded DOWN
    // because the binary quotient lands just under the midpoint —
    // 228.765 / 0.01 = 22876.499999999996 -> 228.76, while
    // 214.385 / 0.01 = 21438.5 -> 214.39) and 142,938 / 142,938 EURUSD
    // fills at tick 1e-5. Any epsilon nudge (floor(r + 0.5 + 1e-6)) or a
    // decimal half-up rule forces every binary midpoint up and breaks the
    // 2,460 down cases. For r >= 1 the form below is bit-identical to
    // std::round(r) (adding 0.5 is exact inside one binade), so the legacy
    // std::round shape was already the right function; it is spelled out so
    // the code reads as the census formula it was fitted to.
    double round_to_mintick(double price) const {
        if (std::isnan(price) || syminfo_mintick_ <= 0.0) return price;
        return std::floor(price / syminfo_mintick_ + 0.5) * syminfo_mintick_;
    }

    // round 8 family R scope: the 10-significant-digit money arithmetic
    // (tv_money_round) is applied where it was pinned and where it can move a
    // lot — a lot-stepped instrument whose lot is worth less than one unit of
    // account currency at the sizing price (OANDA:EURUSD 0.01 x 1.1 = 0.011;
    // BINANCE:BTCUSDT 1e-5 x 85,000 = 0.85; ETHUSDT.P 1e-4 x 2,500 = 0.25).
    // On integer-lot instruments (F, AAPL, ES, NQ, NIFTY: a lot is 10..250k)
    // and on the corpus' continuous qty_step 0 the exact arithmetic stays:
    // there the rounding could only ever bite on a synthetic exact tie.
    bool tv_money_scope(double price) const {
        if (!(qty_step_ > 0.0) || !std::isfinite(price) || price <= 0.0) return false;
        const double lot_value = qty_step_ * price * syminfo_.pointvalue
                                 * active_account_currency_fx();
        return std::isfinite(lot_value) && lot_value < 1.0;
    }
    // POOC flat-parent controls: cost rounding also precedes admission at the
    // terminal close. Named child brackets created after the sole pending
    // parent have no live owner yet; they cannot compete for its opening cash.
    bool rounded_pooc_flat_signal_cost_scope(const PendingOrder& order) const {
        if (!process_orders_on_close_ || calc_on_order_fills_
            || bar_magnifier_enabled_ || coof_scheduler_active_
            || stream_warmup_mode_ || stream_phase_ != StreamPhase::IDLE
            || order.type != OrderType::MARKET || order.incarnation == 0
            || order.created_bar != bar_index_
            || order.created_position_side != PositionSide::FLAT
            || placement_has_prior_close(order)
            || (order.replaced_order_incarnation != 0)
            || order.oca_type != 0 || !order.oca_name.empty()
            || position_side_ != PositionSide::FLAT
            || position_entry_count_ != 0 || !pyramid_entries_.empty()
            || !(qty_step_ > 0.0 && qty_step_ < 1.0)
            || !std::isfinite(order.sizing_price) || order.sizing_price <= 0.0
            || order.sizing_fx != 1.0 || active_account_currency_fx() != 1.0
            || !account_currency_fx_timestamps_.empty()
            || syminfo_.pointvalue != 1.0 || commission_value_ != 0.0
            || slippage_ != 0 || pyramiding_ < 0 || pyramiding_ > 1
            || max_intraday_filled_orders_.active()
            || risk_max_intraday_loss_ != 0.0 || risk_max_drawdown_ != 0.0
            || risk_max_cons_loss_days_ > 0 || pending_orders_.size() > 3) {
            return false;
        }
        for (const auto& other : pending_orders_) {
            if (other.incarnation == order.incarnation) continue;
            const bool priced = std::isfinite(other.legs.prices().limit_price)
                || std::isfinite(other.legs.prices().stop_price);
            const bool trailing = std::isfinite(other.legs.prices().trail_offset)
                && (std::isfinite(other.legs.prices().trail_points) || std::isfinite(other.legs.prices().trail_price));
            if (other.type != OrderType::EXIT || other.from_entry.empty()
                || other.created_bar != order.created_bar
                || other.created_seq <= order.created_seq
                || other.legs.dormant() || other.legs.pending_replacement()
                || (!priced && !trailing)) {
                return false;
            }
            // Matching from_entry attaches only if this parent is admitted.
            // A different named from_entry has neither a live lot (flat) nor
            // another pending parent (every other object is an EXIT).
        }
        return true;
    }
    // Same-bar POOC money admission for one true-flat long MARKET parent.
    // Quantity sizing keeps its existing slipped divisor. The money checks
    // use the recorded signal mark and a tick-built slipped price instead.
    bool pooc_flat_money_admission_scope(const PendingOrder& order,
                                         double fill_price) const {
        if (!process_orders_on_close_ || order.type != OrderType::MARKET
            || !order.is_long || order.incarnation == 0
            || order.created_bar != bar_index_
            || order.created_position_side != PositionSide::FLAT
            || placement_has_prior_close(order)
            || order.birth.from_fill() || (order.replaced_order_incarnation != 0)
            || !order.oca_name.empty() || order.oca_type != 0
            || position_side_ != PositionSide::FLAT || position_entry_count_ != 0
            || !pyramid_entries_.empty() || pyramiding_ < 0 || pyramiding_ > 1
            || margin_long_ != 100.0 || commission_value_ != 0.0
            || slippage_ < 0 || !(syminfo_mintick_ > 0.0)
            || !(qty_step_ > 0.0 && qty_step_ < 1.0)
            || syminfo_.pointvalue != 1.0 || account_currency_fx_ != 1.0
            || active_account_currency_fx() != 1.0
            || !account_currency_fx_timestamps_.empty()
            || bar_magnifier_enabled_ || stream_warmup_mode_
            || stream_phase_ != StreamPhase::IDLE
            || max_intraday_filled_orders_.active() || risk_max_intraday_loss_ != 0.0
            || risk_max_drawdown_ != 0.0 || risk_max_cons_loss_days_ > 0
            || !std::isfinite(fill_price) || !(fill_price > 0.0)) return false;
        if (calc_on_order_fills_) {
            if (!coof_scheduler_active_ || !coof_cursor_is_bar_close_
                || coof_fill_recalc_active_ || coof_evaluating_path_segment_) return false;
        } else if (coof_scheduler_active_) return false;
        for (const auto& other : pending_orders_)
            if (other.incarnation != order.incarnation) return false;

        const bool default_all_in = std::isnan(order.qty)
            && default_qty_type_ == QtyType::PERCENT_OF_EQUITY
            && default_qty_value_ == 100.0
            && opening_admission_eligible(order.market_admission)
            && std::isfinite(order.frozen_default_qty) && order.frozen_default_qty > 0.0
            && std::isfinite(order.sizing_equity) && order.sizing_equity > 0.0
            && order.sizing_fx == 1.0;
        const bool explicit_fixed = std::isfinite(order.qty) && order.qty > 0.0
            && (order.qty_type < 0 || order.qty_type == static_cast<int>(QtyType::FIXED))
            && std::isfinite(order.affordability_placement_equity)
            && order.affordability_placement_equity > 0.0
            && order.affordability_held_qty == 0.0
            && (!order.pine_frozen_market_instruction.active()
                || (order.pine_frozen_market_instruction.transaction()
                    && order.pine_frozen_market_instruction.transaction()->transaction_units
                        == order.pine_frozen_market_instruction.transaction()->own_units
                    && !placement_at_entry_capacity(order)));
        if (!default_all_in && !explicit_fixed) return false;
        const double mark = default_all_in ? order.sizing_mark
                                          : order.affordability_signal_price;
        const double price = default_all_in ? order.sizing_price
            : mark + slippage_ * syminfo_mintick_;
        if (!std::isfinite(mark) || !(mark > 0.0) || !std::isfinite(price)
            || !(price > 0.0) || !tv_money_scope(price)
            || fill_price != mark) return false;
        const double booked = apply_fill_slippage(fill_price, true);
        return slippage_ == 0 ? booked == price
            : round_to_mintick(booked) == round_to_mintick(price);
    }

    // R24 signal-cost controls: a fractional lot worth >=1 account unit can
    // still cross the rounded-money admission boundary. BTC Q9.36259 at
    // 112380.33 costs 1052170.9538547, rounded to 1052170.954; exact signal
    // equity 1052170.9536054998 therefore keeps only a reversal's close leg.
    // XAU Q300 at 3443.625 likewise rejects capital cost-0.0001, while exact
    // cost and cost+0.0001 admit, despite the cheaper next opening price.
    // R39 BTC/XAU controls also pin the independent price-scale check for
    // this ordinary market book. Share its scope while keeping the separately
    // pinned POOC signal-cost extension out of the price-scale extension.
    bool ordinary_fractional_market_admission_scope(const PendingOrder& order) const {
        if (!(qty_step_ > 0.0 && qty_step_ < 1.0)
            || !std::isfinite(order.sizing_price) || order.sizing_price <= 0.0
            || !std::isfinite(order.sizing_equity)
            || !std::isfinite(order.frozen_default_qty)
            || order.sizing_fx != 1.0 || active_account_currency_fx() != 1.0
            || !account_currency_fx_timestamps_.empty()
            || syminfo_.pointvalue != 1.0
            || commission_value_ != 0.0 || slippage_ != 0
            || process_orders_on_close_ || calc_on_order_fills_
            || bar_magnifier_enabled_ || coof_scheduler_active_
            || stream_warmup_mode_ || stream_phase_ != StreamPhase::IDLE
            || pyramiding_ < 0 || pyramiding_ > 1
            || position_entry_count_ > 1 || pyramid_entries_.size() > 1
            || max_intraday_filled_orders_.active()
            || risk_max_intraday_loss_ != 0.0 || risk_max_drawdown_ != 0.0
            || risk_max_cons_loss_days_ > 0 || order.incarnation == 0) {
            return false;
        }
        for (const auto& other : pending_orders_) {
            if (other.incarnation == order.incarnation) continue;
            // Coqueued unpriced strategy.close legs are part of the pins.
            // Competing entries and priced/trailing brackets retain their
            // existing admission and transaction-ordering paths.
            if (other.type != OrderType::EXIT
                || !std::isnan(other.legs.prices().limit_price) || !std::isnan(other.legs.prices().stop_price)
                || !std::isnan(other.legs.prices().trail_points) || !std::isnan(other.legs.prices().trail_price)
                || !std::isnan(other.legs.prices().profit_ticks) || !std::isnan(other.legs.prices().loss_ticks)) {
                return false;
            }
        }
        return true;
    }
    bool rounded_signal_cost_scope(const PendingOrder& order) const {
        return tv_money_scope(order.sizing_price)
            || rounded_pooc_flat_signal_cost_scope(order)
            || ordinary_fractional_market_admission_scope(order);
    }
    bool rounded_price_admission_scope(const PendingOrder& order) const {
        return tv_money_scope(order.sizing_price)
            || ordinary_fractional_market_admission_scope(order);
    }
    // Rule 1's scope (round 10 family AE): the ten-digit equity and the raw
    // lot floor size EVERY lot-stepped instrument — integer shares included
    // (NASDAQ:AAPL 2025-09-05 16:15Z: 1094521.68 / 238.77 floors to 4583 on
    // TradingView, 4584 from the float-accumulated ledger or a nudged
    // floor). Only a continuous qty_step 0 keeps the exact arithmetic.
    bool tv_money_lot_sizing() const { return qty_step_ > 0.0; }
    // The broker's required margin at a mark is money at ten significant
    // digits where that can move a lot (famr-adm-rev-01000: the 4x trim of
    // the fill bar's short is 3900.60 from the ROUNDED 1000527.321 required
    // margin, 3900.56 from the exact 1000527.3207023 — one lot of restore
    // quantity across the 0.01 floor; rev-00800 / -01079 / revb / S3 keep
    // their trims either way). Exact outside the scope.
    double tv_money_required_margin(double required, double mark) const {
        // Same-currency ledgers only (a converted ledger is cent-rounded in
        // TradingView's export; no tape pins the 10-digit form there).
        return tv_money_scope(mark) && account_currency_fx_timestamps_.empty()
            ? tv_money_round(required) : required;
    }

    // A fill taken AT A RAW BAR PRICE — a market order at the bar close
    // (process_orders_on_close) or at the next open, a resting stop/limit
    // the open gapped through, a stop-limit whose limit is already
    // marketable at an OHLC path point, a margin-call slice at the open or
    // adverse extreme, a strategy.close at the close / COOF bar-point
    // cursor — books the raw print rounded to the NEAREST tick and only then
    // carries slippage ticks. The FEED is never quantized (indicators consume
    // the raw sub-tick values); only the fill and the broker's default-sizing
    // snapshot (calc_qty / frozen_sizing_price, same nearest-tick form) are
    // on-tick. The directional
    // snap (round_to_mintick_directional) is reserved for COMPUTED stop /
    // limit LEVELS that fall between ticks; applying it to a raw bar price
    // was the finding-432/446 defect (sells floored, buys ceiled — 43 AAPL
    // slugs off by one tick). The result is on-tick, so the directional snap
    // downstream in apply_slippage / apply_limit_fill is an identity on it
    // (the 1e-9 boundary guard absorbs the n*tick/tick FP residue).
    double bar_fill_price(double raw_bar_price) const {
        return round_to_mintick(raw_bar_price);
    }

    // design-stop-tick-rounding (round 6): the broker emulator TESTS a
    // resting stop / limit against the bar's OHLC quantized to the tick
    // (nearest, the finding-446 formula), while the order LEVEL stays raw;
    // the fill keeps its existing directional / limit-or-better snap.
    //
    // Pinned on NYSE:F 1D (mintick 0.01, sub-penny prints; lab tv tapes
    // scratchpad/r6/pins/stopround-*, 2026-09-04):
    //   long sell-stops 13.74624 / 13.7451 / 13.7449 / 13.745 all SKIP
    //     2026-02-02 (low 13.745 -> 13.75) and fill 02-03 @13.74, while
    //     13.3449 fills 01-26 (low 13.3448 -> 13.34) @13.34 — neither a raw
    //     compare (02-02 would fill) nor a floored/ceiled level (01-26
    //     would not) explains both; only the quantized low does;
    //   short buy-stops 14.0349 / 14.03505 / 14.0352 all fill 02-03 (high
    //     14.0351 -> 14.04) @14.04; 13.225 skips 12-09 (high 13.2202 ->
    //     13.22): the high rounds to NEAREST, not up;
    //   sell-stop 13.776 over the 02-20 open 13.775 (-> 13.78) fills at the
    //     level 13.77, not at the open: the open is quantized too;
    //   the same bars/levels reproduce for strategy.exit(limit=),
    //     strategy.entry(stop=) / (limit=) and strategy.order(stop=), long
    //     and short (stopround-xl-*, -es-*, -el-*, -eo-*);
    //   stopround-ohlc-0/1 encode Pine's own low/high in the trade qty:
    //     13.745, 13.3448, 14.0351 — the RAW prints, identical to the feed,
    //     so the quantization lives in the broker, not the data.
    // The trail leg is NOT covered (stopround-xt-L-trail: trail_points 20 /
    // trail_offset 3 over the 14.035 high exits at the next open, the raw-
    // extreme behaviour the engine already has), so the trail keeps walking
    // the raw path; stop-limit entries, the process_orders_on_close close
    // compares and the calc_on_order_fills cursors were not pinned either
    // and stay raw.
    //
    // The grid point is materialized as k / (1/mintick) when 1/mintick is
    // integral (every decimal tick), which is the double a Pine literal on
    // that tick parses to — so an on-grid level compares EQUAL to a
    // quantized bar price bit-for-bit (14.04 vs k*0.01 = 14.040000000000001
    // would not). Non-decimal ticks fall back to k*mintick.
    double tick_grid_price(double price) const {
        if (std::isnan(price) || syminfo_mintick_ <= 0.0) return price;
        const double k = std::floor(price / syminfo_mintick_ + 0.5);
        const double inv = 1.0 / syminfo_mintick_;
        const double inv_int = std::floor(inv + 0.5);
        if (inv_int > 0.0 && std::abs(inv - inv_int) <= 1e-6 * inv_int) {
            return k / inv_int;
        }
        return k * syminfo_mintick_;
    }
    // round 8 family T (NYSE:F@15, pinned by 40 `lab tv` sensor tapes on
    // NYSE:F / CME_MINI:ES1! / OANDA:EURUSD 15m, scratchpad famT/pins,
    // 2026-09-05): TradingView stores a resting stop / limit LEVEL on the
    // symbol's PRICE GRID (multiples of 1 / pricescale, pricescale =
    // 10^decimals of the tick) whenever the level sits within
    // 0.01 / pricescale^2 of a grid price — the residue a level computed
    // as avg_price +/- k * mintick carries (9.99 + 0.05 =
    // 10.040000000000001, 11.86 - 0.05 = 11.809999999999999) and anything
    // up to 1e-6 on a 2-decimal symbol (10.040001 IS 10.04; 10.0400012 is
    // not and takes the directional snap: a sell limit at 10.0400012 fills
    // at 10.05). ES1! (tick 0.25, pricescale 100) has the same 1e-6 band
    // (5513.7500005 IS 5513.75, 5513.750001 is not); EURUSD (pricescale
    // 1e5) snaps only within 1e-12 (1.135560000001 IS 1.13556,
    // 1.135560000002 is not). The engine used to compare the RAW level
    // against the tick-quantized bar, so a bar whose quantized extreme
    // EQUALS the level (h 10.04, or h 10.035 -> 10.04, vs
    // 10.040000000000001) did not fill and the exit landed bars later at
    // the same snapped price — 148 of the 179 exit-time mismatches on the
    // F@15 lane (masayanfx-scalping 102, latibonit 17, jos-protrader 8,
    // vasudevshenoy 6, lukeborgerding, drakkhon, rhyme17, hariss369,
    // colasbreugnon, fast-scalper, JOAT aureate). Applied where a level is
    // stored on a PendingOrder (strategy.entry / exit / order, and the
    // profit / loss tick conversion), so every trigger test, gap test,
    // marketable-at-placement test and fill snap reads the grid value —
    // materialized as k / pricescale, the double the decimal literal
    // parses to, bit-for-bit equal to tick_grid_price's output. A level
    // outside the band is returned untouched (the directional fill snap
    // and the exact trigger compare keep TV's sub-tick behaviour, round 6).
    // A binary tick (1/128 = 0.0078125) resolves to a 7-decimal grid whose
    // band is 1e-16: effectively untouched; a tick with no short decimal
    // expansion has no grid and is untouched.
    static constexpr double kLevelGridBandPoints = 0.01;  // x 1/pricescale
    int price_grid_decimals() const {
        if (syminfo_mintick_ <= 0.0) return -1;
        double scaled = syminfo_mintick_;
        for (int n = 0; n <= 10; ++n) {
            const double k = std::floor(scaled + 0.5);
            if (k >= 1.0 && std::abs(scaled - k) <= 1e-6 * k) return n;
            scaled *= 10.0;
        }
        return -1;
    }
    double level_on_price_grid(double level) const {
        if (std::isnan(level) || !std::isfinite(level)) return level;
        const int n = price_grid_decimals();
        if (n < 0) return level;
        double pricescale = 1.0;
        for (int i = 0; i < n; ++i) pricescale *= 10.0;
        // Points as level / pointsize (pointsize = 1 / pricescale as a
        // double): of the candidate arithmetics this is the one that
        // reproduces every tape at the band's FP boundary (EURUSD
        // 1.13556 + 1e-12 snaps, + 2e-12 does not; ES 5513.75 + 5e-7
        // snaps, + 1e-6 does not; F 10.04 + 1e-6 snaps, + 1.2e-6 does not).
        const double pointsize = 1.0 / pricescale;
        const double p = level / pointsize;
        const double k = std::floor(p + 0.5);
        if (std::abs(p - k) <= kLevelGridBandPoints / pricescale) {
            return k / pricescale;
        }
        return level;
    }
    Bar broker_tick_bar(const Bar& bar) const {
        Bar b = bar;
        b.open = tick_grid_price(bar.open);
        b.high = tick_grid_price(bar.high);
        b.low = tick_grid_price(bar.low);
        b.close = tick_grid_price(bar.close);
        return b;
    }
    // The bar the stop / limit trigger tests run on. A synthetic bar — the
    // calc_on_order_fills scheduler's point / monotonic-segment bars and the
    // KI-67 cascade waypoint bar — is a slice of an already-decided path and
    // is compared raw, exactly as before; a real chart / lower-TF bar is
    // quantized.
    Bar broker_trigger_bar(const Bar& bar) const {
        if ((calc_on_order_fills_ && coof_scheduler_active_)
            || coof_cascade_force_wp_gap_) {
            return bar;
        }
        return broker_tick_bar(bar);
    }

    // TradingView fills stop entries directionally to mintick rather than
    // rounding to nearest: long stops snap UP (ceil), short stops snap DOWN
    // (floor). Verified against basic/parabolic-asr where the 2,513
    // non-gap stop entry fills show a perfectly one-sided +/-0.01 bias.
    // See investigation report at /tmp/pf_investigation_parabolic_asr.md.
    // This applies to COMPUTED LEVELS only (a stop at (open+high)/2, a
    // user_close + 0.5 level, ...). A fill at a RAW BAR PRICE goes through
    // bar_fill_price (nearest tick, finding-446) before it reaches the
    // slippage path, where this snap is then an identity.
    //
    // The 1e-9 epsilon nudge guards against FP slop: a price computed as
    // ``user_close + 0.5`` may land at ``1803.1199999998`` (just below the
    // 1803.12 mintick boundary), which a raw ``ceil`` would push to 1803.13
    // and a raw ``floor`` to 1803.11. The nudge resolves any value within
    // 1 nanotick of an exact mintick boundary to that boundary, keeping
    // the bias one-sided only for sub-mintick midpoints (e.g. 1804.945).
    double round_to_mintick_directional(double price, bool is_long_stop) const {
        if (std::isnan(price) || syminfo_mintick_ <= 0.0) return price;
        constexpr double kBoundaryEps = 1e-9;
        double r = price / syminfo_mintick_;
        if (is_long_stop) {
            return std::ceil(r - kBoundaryEps) * syminfo_mintick_;
        }
        return std::floor(r + kBoundaryEps) * syminfo_mintick_;
    }

    double apply_slippage(double price, bool is_buy) const {
        if (std::isnan(price) || syminfo_mintick_ <= 0.0) return price;
        // TradingView snaps LEVEL fills to mintick directionally even when
        // slippage is zero: a buy fills at the next-higher mintick, a sell
        // at the next-lower mintick. (A raw bar price arrives here already
        // nearest-rounded by bar_fill_price, finding-446, so the snap below
        // is an identity on it.) The legacy nearest-mintick rounding biased
        // sub-mintick stop levels (e.g. (open+high)/2 for an odd-mintick
        // bar) up by one tick for sells, producing a deterministic +0.01
        // exit-price drift on the magnifier-dist corpus (≈ 180 trades per
        // probe). Matching TV's directional snap removes that drift while
        // preserving the original add-slippage-then-snap shape for the
        // slippage > 0 path.
        if (slippage_ == 0) {
            return round_to_mintick_directional(price, /*is_long_stop=*/is_buy);
        }
        double slip = slippage_ * syminfo_mintick_;
        double slipped = is_buy ? price + slip : price - slip;
        return round_to_mintick_directional(slipped, /*is_long_stop=*/is_buy);
    }

    // TradingView applies slippage to MARKET and STOP fills but NOT to
    // LIMIT fills: a limit order fills at limit-or-better. An off-tick
    // limit price snaps one tick in the FAVORABLE direction (sell limit
    // -> ceil, buy limit -> floor) — the opposite direction of the
    // adverse market/stop snap in apply_slippage. A limit order that gaps
    // through at the bar open fills at the raw open (better price), also
    // unslipped; the open is on-tick in practice so the favorable snap is
    // an identity there.
    //
    // Evidence (2026-06-12): TV export of corpus/validation/
    // bracket-exit-tp-sl-fixed-01 on BINANCE:ETHUSDT.P, commission 0.1%,
    // slippage 2, mintick 0.01 — TP (limit) exits: 152/152 intra-bar
    // fills equal ceil(limit) with no slip (62 of them discriminate ceil
    // from round-to-nearest), 44/44 gap fills equal the raw bar open.
    // SL (stop) exits 195/195 and market entries 396/396 match the
    // slipped path, pinning slippage to market/stop fills only. The
    // probe's slippage=0 tv_trades.csv shows the same favorable snap
    // (143/143 TP fills at ceil(limit)), so this rule is slippage-
    // independent.
    double apply_limit_fill(double price, bool is_buy) const {
        if (std::isnan(price) || syminfo_mintick_ <= 0.0) return price;
        return round_to_mintick_directional(price, /*is_long_stop=*/!is_buy);
    }

    // Fill-time dispatcher: LIMIT-triggered fills take the unslipped
    // limit-or-better path, everything else (market/stop/trail) takes
    // apply_slippage. current_fill_is_limit_ is the transient set around
    // the per-order fill dispatch in apply_filled_order_to_state.
    double apply_fill_slippage(double price, bool is_buy) const {
        return current_fill_is_limit_ ? apply_limit_fill(price, is_buy)
                                      : apply_slippage(price, is_buy);
    }

    // --- Commission helper ---
    // PERCENT commission is a % of the order's notional value. The notional
    // (fill_price × qty × pointvalue) is in the symbol's QUOTE currency; the
    // commission a strategy() reports is in ACCOUNT currency, so it needs the
    // same instrument->account conversion as the margin gate below
    // (account_currency_fx_, default 1.0 — no-op for the corpus). Cash-per-
    // order / cash-per-contract are already account-currency-native (a
    // trader configures "$20 per contract" in their own currency), so they
    // are untouched.
    double calc_commission(double fill_price, double qty) const {
        switch (commission_type_) {
            case CommissionType::PERCENT:
                return fill_price * qty * syminfo_.pointvalue
                       * active_account_currency_fx()
                       * (commission_value_ / 100.0);
            case CommissionType::CASH_PER_ORDER:
                return commission_value_;
            case CommissionType::CASH_PER_CONTRACT:
                return commission_value_ * qty;
        }
        return 0.0;
    }

    // Read the paid entry fee for a still-open pyramid slice. Production entry
    // paths always initialize the snapshot. The fallback keeps hand-constructed
    // PyramidEntry fixtures source-compatible without weakening real lifecycle
    // behavior.
    double open_entry_commission(const PyramidEntry& pe) const {
        return std::isfinite(pe.entry_commission_account)
            ? pe.entry_commission_account
            : calc_commission(pe.price, pe.qty);
    }

    double allocated_entry_commission(const PyramidEntry& pe, double units) const {
        if (units <= 0.0) return 0.0;
        const double paid = open_entry_commission(pe);
        return units >= pe.qty ? paid : paid * (units / pe.qty);
    }

    void snapshot_entry_commission(PyramidEntry& pe) const {
        pe.entry_commission_account = calc_commission(pe.price, pe.qty);
    }

    // Sum the already-paid percent entry commission attributable to the
    // still-open pyramid slices. FIFO partial exits scale each surviving
    // snapshot. Cash commission types remain outside this TV-pinned rule.
    double surviving_open_percent_commission_account() const;

    // TradingView debits percent entry commission at fill, while PineForge
    // realizes both commission legs in net_profit_sum_ when the lot closes.
    // Use this fee-net ledger for percent-of-equity sizing and broker margin.
    double percent_commission_live_equity(double mark_price) const;

    // --- Position sizing helper ---
    // PERCENT_OF_EQUITY / CASH size a budget that is denominated in ACCOUNT
    // currency (equity, and a strategy.cash default_qty_value are both
    // account-currency-native — see emit_close_trade / current_equity()),
    // then convert it into a quantity of the instrument, whose price is in
    // QUOTE currency. Divide the account-currency cash by account_currency_fx_
    // first (the inverse of the instrument->account multiply used for
    // commission/PnL/margin) so the division by fill_price stays dimensionally
    // consistent; default 1.0 leaves the corpus untouched.
    // Floor an order quantity to the instrument's tradable lot increment
    // (qty_step_). TradingView applies this to EVERY order it sends to the
    // exchange, not just forced liquidations — verified row-for-row: a
    // computed DCA/safety-order quantity (e.g. baseOrderSize/close) is
    // floored, not rounded, before it ever contributes to cost basis or a
    // fill (see src/engine_fills.cpp's margin-call path, which already does
    // this for liquidation lots). qty_step_ == 0 (corpus default) leaves qty
    // untouched. A quotient that is only binary64 residue below an integer is
    // treated as that integer, using the same 1e-6-of-a-step tolerance as
    // percent-derived exits below. This keeps an on-grid request such as
    // 1 / 0.00001 from losing a whole lot because the quotient materializes as
    // 99999.999999..., while a genuinely off-grid request still floors. When
    // quantization would be a no-op, preserve the original double so the
    // tolerance never increases a requested quantity. Unlike the liquidation
    // path, a regular entry legitimately CAN floor to zero (an under-funded
    // order is simply not placed), so there is no "never stall"
    // floor-to-one-step fallback here.
    double apply_qty_step(double qty) const {
        if (qty_step_ <= 0.0 || !std::isfinite(qty) || qty <= 0.0) return qty;
        double floored = std::floor(qty / qty_step_ + 1e-6) * qty_step_;
        return floored < qty ? floored : qty;
    }

    // Percent-derived strategy.exit lots are floored to the same lot
    // increment (TV evidence, BINANCE:ETHUSDT.P qty_step 0.0001: a
    // qty_percent=50/50 short bracket over a 5.4103 position fills
    // 2.7051 + 2.7051, leaving a 0.0001 dust short OPEN until the next
    // reversal/close/margin-call — 39 of stockhunter2025-btcusd-4h-ema-
    // swing-strategy's 56 unmatched TV trades were exactly such dust
    // rows). Unlike apply_qty_step this floor is epsilon-tolerant: 50%
    // of an on-grid position is often exactly on-grid in real numbers
    // but lands one ulp below the grid ratio in doubles (2.7051/0.0001
    // = 27050.999999…), and a plain floor would knock such a leg a FULL
    // step down, inventing dust TV does not have. The tolerance (1e-6 of
    // a step) sits far above double representation error at realistic
    // qty/step magnitudes yet far below any genuine sub-step remainder.
    // When the floor is a no-op (qty already on-grid) the ORIGINAL double
    // is returned unchanged: reconstructing it as floor(...)*step lands
    // one ulp away (0.3 -> 0.30000000000000004) and that representation
    // jitter leaks into printed PnL at the 1e-6 digit for strategies whose
    // percent legs were already exact (officialjackofalltrades' 30%-of-1
    // legs) — a pure artifact this fix must not introduce.
    double apply_exit_qty_step(double qty) const {
        if (qty_step_ <= 0.0 || !std::isfinite(qty) || qty <= 0.0) return qty;
        double floored = std::floor(qty / qty_step_ + 1e-6) * qty_step_;
        return floored < qty ? floored : qty;
    }

    // Integer-lot symbols keep one minimum contract/share for any positive
    // percent-derived strategy.exit request when at least one whole step is
    // still unreserved. TradingView evidence on one-contract ES/NQ/NIFTY
    // positions shows a pair of qty_percent=50 siblings reserving 1 + 0, not
    // 0 + 0. Fractional-lot symbols retain the floor/dust rule above.
    //
    // This helper is intentionally exit-percent-specific: explicit exit qty,
    // full-percent exits, entries and other broker quantities must not acquire
    // a minimum-one-step fallback.
    double apply_percent_exit_qty_step(double requested_qty,
                                       double available_qty) const {
        double gridded = apply_exit_qty_step(requested_qty);
        if (qty_step_ >= 1.0
            && requested_qty > 0.0
            && requested_qty < qty_step_
            && available_qty >= qty_step_) {
            return qty_step_;
        }
        return gridded;
    }

    // TradingView reserves the entry commission when sizing percent_of_equity:
    // it sizes the notional so that notional + entry_fee <= equity*pct, i.e.
    // divides the sizing cash by (1 + commRate). Proven from TV exports for
    // BOTH fractional (pct=10) and all-in (pct=100) sizing — the reservation is
    // not gated on headroom (KI-52 probes: ki52-pct-equity-commission-{frac,allin},
    // first-entry qty = equity/(price*(1+commRate)) to the lot step, 16/16). Only
    // percent commission reserves; cash-per-order/contract and a zero rate are
    // exact no-ops, so FIXED/CASH qty types and commission_value_==0 are unchanged.
    double reserve_percent_commission(double cash) const {
        return (commission_type_ == CommissionType::PERCENT && commission_value_ > 0.0)
            ? cash / (1.0 + commission_value_ / 100.0) : cash;
    }

    // The broker's sizing arithmetic runs ON-TICK. Both the price the budget
    // is divided by and the price the open position is marked at for the
    // equity term are round_to_mintick() of their raw inputs; the FEED itself
    // stays raw (ta.*, crossovers, plots and every strategy.* metric TV
    // reports on raw values keep reading current_bar_.close directly — only
    // this sizing snapshot and the fill are quantized). The evidence is the
    // same tape family that pinned the signal-bar freeze below:
    //
    //   - taro-s-c-c-ma-simplified-2-color replayed over the NYSE:F and
    //     NASDAQ:AAPL tapes: qty = floor(E / tick(close_S)) with E marked at
    //     tick(close_S) reproduces 674/674 F and 832/832 AAPL reversals; the
    //     raw-close divisor fits only 476/674 on F. The same replay matches
    //     675/675 TV entries by RAW-close crossovers, which is why the signal
    //     path is left alone.
    //   - drgunjan-F trade 1: a 9.565 signal close, TV qty 10460 =
    //     floor(100000 / 9.56) (9.565 / 0.01 = 956.49999... rounds DOWN under
    //     the census formula, exactly as 228.765 does); the raw divisor gave
    //     floor(100000 / 9.565) = 10454.
    //   - The raw basis also DECLINED entries TV filled: when an x.xx5 close
    //     rounds UP at the fill (bar_fill_price) while the quantity was
    //     floored against the raw close, qty * fill exceeds the sizing
    //     equity by ~qty * mintick/2 and the true-flat gap-reject / reversal
    //     float-guard arms in apply_filled_order_to_state saw a phantom gap.
    //     463/463 missing taro-F entries were predicted by that mechanism
    //     with 0 counterexamples; 26/26 drgunjan-F and 6/6 mazi-F missing
    //     entries had sub-penny signal closes.
    //
    // On a price that is already n*tick (bar_fill_price output, a
    // directionally-snapped level, or the slipped sizing price
    // frozen_sizing_price builds) round_to_mintick is identical to within
    // ONE ULP — not an identity: double(tick) is inexact for every decimal
    // tick, so floor(x/0.01 + 0.5)*0.01 != x for 6,951 of 49,900 decimal-
    // parsed 2dp prices 1.00..500.00 (always +1 ulp, double(0.01) > 0.01),
    // for 35,736 of 70,000 5dp prices at tick 1e-5, and for 0 of 12,000 at
    // the binary-exact 0.25. The ulp is absorbed by apply_qty_step's 1e-6
    // nudge (0 floor flips of floor(100000/x) across all 49,900 prices) and
    // by the 1e-9 / 1e-12 float guards on every admission arm, so no
    // quantity or verdict moves on an on-tick feed: the fill-time legacy
    // callers and the frozen path reproduce the pre-fix numbers there, and
    // only sub-tick prints move — to TV's number.
    //
    // QtyType::CASH follows percent_of_equity by construction (the same
    // broker division, only the numerator differs) and is UNPINNED: every
    // census above is default percent_of_equity sizing, and no strategy.cash
    // tape discriminating round(close) from close has been replayed. A
    // future CASH mismatch on a sub-tick feed is traced here first.
    double calc_qty(double fill_price) const {
        const double equity = default_qty_type_ == QtyType::PERCENT_OF_EQUITY
            ? percent_commission_live_equity(round_to_mintick(current_bar_.close)) : 0.0;
        return calc_default_qty_from_equity(fill_price, equity);
    }

    // TradingView freezes DEFAULT (qty=na) market-order sizing at the SIGNAL
    // bar — the bar whose on_bar issued the strategy.entry/strategy.order
    // call — not at the fill:
    //
    //   tick(x)      = round_to_mintick(x)          // nearest tick, census form
    //   equity_S     = initial_capital + realized net profit
    //                  + open_profit(tick(close(S)))  // position may still be OPEN
    //   sizing_price = tick(close(S)) + slippage*mintick*(+1 buy / -1 sell)
    //   qty          = floor_step( reserve_percent_commission(budget)
    //                              / fx / (sizing_price * pointvalue) )
    //
    // The market order then fills at the NEXT bar's open carrying this frozen
    // quantity. calc_qty(price) implements exactly that shape when evaluated
    // AT SIGNAL TIME (current_bar_ IS the signal bar: open_profit marks at
    // tick(close(S)) and the divisor is the rounded argument), so the freeze
    // is simply calc_qty(slipped rounded signal close) captured at
    // placement. Evaluating the same expression at FILL time — the
    // pre-freeze behavior — was wrong in
    // three separable ways on a reversal/gap: it double-counted the just-
    // closed position's PnL (current_equity() already realized the exit while
    // position_* still held the stale lot for open_profit), it marked open
    // profit at the FILL bar's close (a look-ahead: that close is unknown
    // when the order fills at the open), and it divided by the fill price
    // instead of the signal close. Freezing at placement removes all three.
    //
    // Only PERCENT_OF_EQUITY / CASH default sizing is price/equity-dependent;
    // FIXED default sizing stays qty=NaN at placement (identical value at
    // fill, and keeping NaN preserves the isnan(order.qty)-keyed semantics
    // elsewhere, e.g. the OCA "fully filled" heuristic).
    //
    // Priced (limit/stop) entries are NOT frozen: TV's sizing basis for an
    // order armed one or more bars before its fill is not empirically
    // established, so they conservatively keep the legacy fill-time sizing.
    // The sizing price of the frozen rule above, exposed separately so the
    // placement sites can persist it on the order (PendingOrder::sizing_price)
    // for the fill-time margin-admission re-check.
    //
    // The basis is the mintick-ROUNDED signal close. Rounding happens BEFORE
    // the slippage ticks are added so the result is n*tick for any feed
    // print, exactly as a bar_fill_price fill carries its slippage: TV's
    // broker never sees the sub-tick close Pine sees (674/674 F, 832/832
    // AAPL reversals on the taro tapes fit tick(close_S); the raw close fits
    // 476/674 — see calc_qty). A feed that is already on-tick is unaffected
    // in every quantity and verdict, though not bit-for-bit: round_to_mintick
    // returns the n*tick double to within one ulp (double(tick) is inexact
    // for decimal ticks — the measurement is in calc_qty's comment), and
    // that ulp is absorbed by apply_qty_step's 1e-6 nudge and by the
    // admission arms' float guards.
    double frozen_sizing_price(bool is_buy) const {
        double sizing_price = round_to_mintick(current_bar_.close);
        if (slippage_ != 0 && syminfo_mintick_ > 0.0) {
            sizing_price += (is_buy ? 1.0 : -1.0) * slippage_ * syminfo_mintick_;
        }
        return sizing_price;
    }

    double frozen_default_market_qty(bool is_buy) const {
        return calc_qty(frozen_sizing_price(is_buy));
    }

    // round 7 (family M, JOAT BTC@1D; campaign note log-20260905t121513z-
    // 50167cb8, CORRECTING the m1d-coof-ctx pin): a DEFAULT-sized
    // (percent_of_equity / cash) MARKET order that a calc_on_order_fills
    // FILL RECALC places is sized by TradingView at ITS OWN FILL, not at the
    // signal bar's close and not at the recalc's cursor:
    //
    //   lab tv scratchpad/pins/m1d-coof-size-btc (BINANCE:BTCUSDT 1D,
    //   2025-10-01..12-31, tv-tape-m1d-coof-size-btc-7ee8712b): "B", born in
    //   the SECOND recalc at the 10-02 open and filled at W1 = the low
    //   118279.31, has qty 845.4564 = 10% x 1e9 / 118279.31 (cursor O
    //   118594.99 -> 843.2; the bar's close 120529.35 -> 829.7); thirteen
    //   entries born in a first-O recalc and filled at O size at O, never at
    //   the finals close. The probe itself: TV 4 0.09245 = 9802.56 /
    //   (106011.13 x 1.0001) at the 11-11 open fill (the engine froze 0.0951
    //   at the 11-11 close 103058.99); TV 10 0.14674 at its W2 fill 69988.83
    //   (cursor W1 63913.27 -> 0.16069, close 67988.04 -> 0.15106).
    //
    // The script context of such a recalc is unchanged — TradingView runs it
    // on the CURRENT bar's finals (scratchpad/pins/m1d-coof-ctx2-{btc,f}:
    // 103/103 encoded firings read bar k's high/low/close/volume, bar_index k,
    // barstate.isconfirmed true, close[1] = bar k-1) — exactly what
    // execute_coof_script_body presents. Only the SIZING moment differs from
    // an ordinary close-calc placement: the placement freeze above is skipped
    // for recalc-born default market orders (strategy.entry MARKET and
    // strategy.order RAW alike), frozen_default_qty stays NaN, and the fill
    // kernels size with calc_qty(slipped fill) — open lots marked at the fill
    // (current_bar_ is the scheduler's point bar there). No KI-54 / gap-reject
    // / gross-admission snapshot is taken for them: those gates are pinned on
    // close-calc placements (their frozen invariant qty * sizing_price <=
    // sizing_equity has no meaning at a fill-time size); the zero-lot decline
    // and the affordability gate read the fill-time quantity. FIXED default
    // sizing and explicit quantities are untouched (never frozen); priced
    // (stop/limit) entries keep their own paths. Ordinary close executions
    // (coof_fill_recalc_active_ false) freeze exactly as before, so a script
    // without calc_on_order_fills is byte-identical.
    bool coof_default_market_sizes_at_fill() const {
        return calc_on_order_fills_ && coof_scheduler_active_
            && coof_fill_recalc_active_;
    }

    // KI-54 defect fix: the frozen sizing snapshot must see POST-liquidation
    // equity. TradingView liquidates intrabar, BEFORE the bar-close script
    // body runs; the engine's process_margin_call runs at the END of
    // dispatch_bar, AFTER on_bar placed (and froze) this bar's default-sized
    // market orders. When a margin call fires on the placement bar, the
    // frozen qty was computed on pre-liquidation equity — over-sized, so the
    // next bar's fill opens a position whose notional exceeds equity and the
    // long_full_margin branch of process_margin_call then emits a phantom
    // LONG margin call TV does not have. Rather than moving process_margin_call
    // (which would change what strategy.equity reads inside on_bar for every
    // strategy), the dispatch loop calls this refresh right after a margin
    // call actually liquidated something: every still-pending frozen
    // default-sized market order placed on THIS bar is re-frozen on the
    // post-liquidation state. Strict no-op on bars without a margin call
    // (the caller checks), and bit-identical recompute for untouched state.
    void refresh_frozen_default_sizing_after_margin_call() {
        for (auto& o : pending_orders_) {
            if (std::isnan(o.frozen_default_qty)) continue;
            if (o.type != OrderType::MARKET && o.type != OrderType::RAW_ORDER)
                continue;
            if (o.created_bar != bar_index_) continue;
            const admission::SizingObservation before{
                o.frozen_default_qty,o.sizing_equity,o.sizing_price,o.sizing_mark,o.sizing_fx};
            const double affordability_before=o.affordability_placement_equity;
            o.frozen_default_qty = calc_qty(o.sizing_price);
            if (!std::isnan(o.sizing_equity)) {
                // Same on-tick mark the placement sites took
                // (engine_strategy_commands.cpp): the re-freeze must land on
                // the number placement would have produced post-liquidation.
                o.sizing_equity = percent_commission_live_equity(
                    round_to_mintick(current_bar_.close));
            }
            o.sizing_fx = active_account_currency_fx();
            record_market_sizing_revision(o,before,affordability_before);
        }
        // design-market-entry-affordability: the placement-equity snapshot of
        // THIS bar's affordability-gated market entries must see the same
        // post-liquidation state.
        for (auto& o : pending_orders_) {
            if (o.type != OrderType::MARKET) continue;
            if (o.created_bar != bar_index_) continue;
            if (!std::isfinite(o.affordability_placement_equity)) continue;
            const admission::SizingObservation before{
                o.frozen_default_qty,o.sizing_equity,o.sizing_price,o.sizing_mark,o.sizing_fx};
            const double affordability_before=o.affordability_placement_equity;
            o.affordability_placement_equity =
                current_equity() + open_profit(current_bar_.close);
            record_market_sizing_revision(o,before,affordability_before);
        }
        // round 7 (family K): a default percent_of_equity <= 100 STOP placed
        // by this bar's on_bar was sized on pre-liquidation equity too.
        // Re-size it at its sizing basis on the post-liquidation state, the
        // same re-freeze the market orders above get. The placement verdict
        // is not revisited (this runs inside process_pending_orders on the
        // finding-308 path, where the book must not be mutated); the
        // fill-time admission still costs the re-sized quantity at the fill.
        for (auto& o : pending_orders_) {
            if (o.type != OrderType::ENTRY) continue;
            if (o.created_bar != bar_index_) continue;
            if (!std::isfinite(o.default_stop_placement_qty)) continue;
            if (!std::isfinite(o.default_stop_sizing_price)) continue;
            o.default_stop_placement_qty =
                calc_qty(o.default_stop_sizing_price);
            o.default_stop_placement_equity =
                current_equity() + open_profit(current_bar_.close);
            o.default_stop_placement_signal_close =
                round_to_mintick(current_bar_.close);
        }
    }

    // --- Strategy variable accessors ---
    double signed_position_size() const {
        // KI-64: while a POOC same-bar in-line close is frozen for this bar,
        // the SCRIPT sees the pre-close position (TV defers close visibility to
        // the next bar). Broker/internal reads use position_side_/position_qty_
        // directly and are unaffected.
        if (pos_view_freeze_bar_ == bar_index_) {
            if (pos_view_frozen_side_ == PositionSide::LONG) return pos_view_frozen_qty_;
            if (pos_view_frozen_side_ == PositionSide::SHORT) return -pos_view_frozen_qty_;
            return 0.0;
        }
        if (position_side_ == PositionSide::LONG) return position_qty_;
        if (position_side_ == PositionSide::SHORT) return -position_qty_;
        return 0.0;
    }

    // KI-64: freeze the pre-close position for the script-visible position
    // accessor before an ordinary POOC strategy.close/close_all fills in-line
    // this bar. Capture-once per on_bar (a second same-bar close keeps the
    // FIRST pre-close snapshot). Caller guards process_orders_on_close_ &&
    // !immediately; this reads position_side_/position_qty_ while they still
    // hold the pre-close values (execute_immediate_close has not run yet).
    void freeze_script_position_view() {
        if (pos_view_freeze_bar_ == bar_index_) return;
        pos_view_freeze_bar_ = bar_index_;
        pos_view_frozen_side_ = position_side_;
        pos_view_frozen_qty_ = position_qty_;
        pos_view_frozen_entry_qty_.clear();
        for (const auto& entry : pyramid_entries_) {
            pos_view_frozen_entry_qty_[entry.entry_id] += entry.qty;
        }
    }
    // KI-64: release the freeze so the next script-visible read returns the real
    // (post-close) position. Called at the top of flush_same_bar_close(), i.e.
    // immediately after every POOC on_bar returns.
    void clear_script_position_view() { pos_view_freeze_bar_ = -1; }

    double net_profit() const { return net_profit_sum_; }
    double gross_profit() const { return gross_profit_sum_; }
    double gross_loss() const { return gross_loss_sum_; }
    double current_equity() const { return initial_capital_ + net_profit_sum_; }

    double max_runup_percent() const {
        return (initial_capital_ > 0.0) ? (max_runup_ / initial_capital_) * 100.0 : 0.0;
    }
    double grossprofit_percent() const {
        return (initial_capital_ > 0.0) ? (gross_profit_sum_ / initial_capital_) * 100.0 : 0.0;
    }
    double grossloss_percent() const {
        return (initial_capital_ > 0.0) ? (gross_loss_sum_ / initial_capital_) * 100.0 : 0.0;
    }
    double avg_trade() const {
        int n = (int)trades_.size();
        return (n > 0) ? (net_profit_sum_ / (double)n) : 0.0;
    }
    double avg_trade_percent() const {
        int n = (int)trades_.size();
        if (n <= 0) return 0.0;
        double s = 0.0;
        for (const auto& t : trades_) s += t.pnl_pct;
        return s / (double)n;
    }
    double avg_winning_trade() const {
        return (win_trades_count_ > 0) ? (gross_profit_sum_ / (double)win_trades_count_) : 0.0;
    }
    double avg_losing_trade() const {
        return (loss_trades_count_ > 0) ? (gross_loss_sum_ / (double)loss_trades_count_) : 0.0;
    }
    double avg_winning_trade_percent() const {
        if (win_trades_count_ <= 0) return 0.0;
        double s = 0.0;
        int c = 0;
        for (const auto& t : trades_) {
            if (t.pnl > 0.0) { s += t.pnl_pct; ++c; }
        }
        return (c > 0) ? (s / (double)c) : 0.0;
    }
    double avg_losing_trade_percent() const {
        if (loss_trades_count_ <= 0) return 0.0;
        double s = 0.0;
        int c = 0;
        for (const auto& t : trades_) {
            if (t.pnl < 0.0) { s += t.pnl_pct; ++c; }
        }
        return (c > 0) ? (s / (double)c) : 0.0;
    }
    // strategy.margin_liquidation_price — the price at which TradingView's
    // broker emulator force-liquidates the current open position. Returns na
    // when flat, when the instrument has no valid size/point-value, or when
    // ``margin/100 - direction == 0`` (a 1x long has no leverage-derived
    // liquidation price; process_margin_call separately handles an eligible
    // one-shot post-fill affordability trim). See compute_liquidation_price
    // for the derivation.
    double margin_liquidation_price() const { return compute_liquidation_price(); }

    // Shared liquidation-price formula (TradingView docs, validated against the
    // p2 margin-call probe and the leverage-margin-call-perp-5x corpus probe):
    //
    //   liqPrice = ((initial_capital + net_profit) / (pointvalue * |size|)
    //               - direction * entry) / (margin_pct/100 - direction)
    //
    //   direction = +1 long / -1 short; net_profit = realized closed-trade PnL;
    //   entry = current average entry price; size = open position size.
    //
    // Rounded UP to mintick for shorts, DOWN for longs (TV convention).
    double compute_liquidation_price() const {
        if (position_side_ == PositionSide::FLAT) return na<double>();
        const double pv = syminfo_.pointvalue;
        const double qty = position_qty_;
        if (!(qty > 0.0) || !(pv > 0.0)) return na<double>();
        const double direction = (position_side_ == PositionSide::LONG) ? 1.0 : -1.0;
        const double margin_pct = (position_side_ == PositionSide::LONG)
                                      ? margin_long_ : margin_short_;
        const double denom = (margin_pct / 100.0) - direction;
        // A long at 100% margin (denom == 0) has no liquidation PRICE.
        // Its separate post-fill affordability trim is handled by
        // process_margin_call without fabricating a later adverse threshold.
        if (std::abs(denom) < 1e-12) return na<double>();
        // equity_basis is account-currency (initial_capital_ is account-
        // currency-native; net_profit_sum_ is account-currency post-FX —
        // see emit_close_trade). liq must come out in QUOTE currency (it's
        // compared against bar.high/low), so convert back via the same
        // account_currency_fx_ inverse used in calc_qty; default 1.0 is a
        // no-op for the corpus.
        const double equity_basis = (initial_capital_ + net_profit_sum_) / active_account_currency_fx();
        double liq = (equity_basis / (qty * pv) - direction * position_entry_price_)
                     / denom;
        if (syminfo_mintick_ > 0.0) {
            liq = (position_side_ == PositionSide::SHORT)
                      ? std::ceil(liq / syminfo_mintick_) * syminfo_mintick_
                      : std::floor(liq / syminfo_mintick_) * syminfo_mintick_;
        }
        return liq;
    }
    double open_trades_capital_held() const {
        if (position_side_ == PositionSide::FLAT) return 0.0;
        return std::abs(position_qty_ * position_entry_price_) * syminfo_.pointvalue;
    }

    // Mark-to-market open profit in account currency. The point-value
    // multiplier keeps this consistent with realized PnL (emit_close_trade)
    // so equity = capital + net_profit + open_profit stays in one unit.
    double open_profit(double current_price) const {
        if (position_side_ == PositionSide::FLAT) return 0.0;
        double diff = (position_side_ == PositionSide::LONG)
            ? (current_price - position_entry_price_)
            : (position_entry_price_ - current_price);
        // Account-currency, matching emit_close_trade / open_trade_profit —
        // callers combine this with initial_capital_ + net_profit_sum_ (both
        // account-currency) to get total equity. fx=1.0 is a no-op.
        return diff * position_qty_ * syminfo_.pointvalue * active_account_currency_fx();
    }

    int count_wintrades() const { return win_trades_count_; }
    int count_losstrades() const { return loss_trades_count_; }

    // --- Time/date extraction from bar timestamp ---
    // Pine's bare ``hour`` / ``minute`` / ``dayofweek`` (the variable form,
    // not the 1-arg function form) returns the wall-clock for the **exchange
    // timezone** of the symbol (per TV reference docs). For crypto symbols
    // like ETH-USDT the exchange TZ is UTC, which matches the engine's
    // storage TZ — so the cheap ``gmtime_r`` path is correct for the
    // overwhelming majority of strategies in the corpus.
    //
    // The 1-arg function form ``hour(time)`` is handled separately by the
    // codegen (see codegen/visit_call.py) and DOES honour
    // ``syminfo_.timezone`` (set via ``strategy_set_chart_timezone``) since
    // TV's reference says the function form defaults its tz arg to
    // ``syminfo.timezone``, which TV harnesses commonly set to the chart's
    // display TZ for cross-exchange / multi-zone work.
    struct BarTime {
        int year, month, dayofmonth, hour, minute, second, dayofweek, weekofyear;
    };

    // Single-entry memo: generated scripts commonly read several time
    // components per bar (hour + minute + dayofweek); decompose once per
    // distinct bar timestamp instead of per accessor. Keyed on the raw
    // timestamp, so no per-run invalidation is needed (same ts -> same
    // UTC decomposition, run-independent).
    mutable int64_t bar_time_memo_ts_ = std::numeric_limits<int64_t>::min();
    mutable BarTime bar_time_memo_{};

    BarTime _decompose_bar_time() const {
        if (current_bar_.timestamp == bar_time_memo_ts_) return bar_time_memo_;
        time_t secs = (time_t)(current_bar_.timestamp / 1000);
        struct tm tm_buf;
        gmtime_r(&secs, &tm_buf);
        BarTime bt;
        bt.year = tm_buf.tm_year + 1900;
        bt.month = tm_buf.tm_mon + 1;
        bt.dayofmonth = tm_buf.tm_mday;
        bt.hour = tm_buf.tm_hour;
        bt.minute = tm_buf.tm_min;
        bt.second = tm_buf.tm_sec;
        bt.dayofweek = tm_buf.tm_wday + 1;
        bt.weekofyear = (tm_buf.tm_yday + 7 - ((tm_buf.tm_wday + 6) % 7)) / 7;
        bar_time_memo_ts_ = current_bar_.timestamp;
        bar_time_memo_ = bt;
        return bt;
    }

    // Chart-timezone-aware decomposition for the existing loss-day clocks
    // and the continuous/unconfigured-session order-counter fallback. The
    // order counter on an explicitly timed session instead consumes
    // compat::pine::IntradayCap::risk_day(), which follows the symbol's trading day.
    //
    // Falls back to plain ``_decompose_bar_time()`` (UTC) when no chart
    // timezone has been set, preserving the legacy fast path for
    // engine consumers that don't call ``set_chart_timezone``.
    //
    // Defined out-of-line in src/engine_risk.cpp so we can use the
    // private ``ScopedTimezone`` helper without leaking its header into
    // the public engine.hpp surface.
    BarTime _decompose_bar_time_chart_tz() const;

    int _bar_hour() const { return _decompose_bar_time().hour; }
    int _bar_minute() const { return _decompose_bar_time().minute; }
    int _bar_second() const { return _decompose_bar_time().second; }
    int _bar_dayofmonth() const { return _decompose_bar_time().dayofmonth; }
    int _bar_dayofweek() const { return _decompose_bar_time().dayofweek; }
    int _bar_month() const { return _decompose_bar_time().month; }
    int _bar_year() const { return _decompose_bar_time().year; }
    int _bar_weekofyear() const { return _decompose_bar_time().weekofyear; }

    // --- Bar magnifier state ---
    bool bar_magnifier_enabled_ = false;
    bool is_first_tick_ = true;
    bool is_last_tick_ = true;
    bool barstate_islast_ = false;
    // Independent from barstate.isnew. False only when a COOF execution
    // restores a completed ordinary-close checkpoint that already contains
    // the current bar's one committed history slot.
    bool history_slot_is_new_ = true;
    int magnifier_samples_ = 4;
    MagnifierDistribution magnifier_dist_ = MagnifierDistribution::ENDPOINTS;
    // When true, run_magnified_bar scales per-sub-bar sample count by
    // (sub_bar.volume / mean_sub_bar_volume) within each script bar — dense
    // tick approximation on high-volume sub-bars without real tick data.
    bool magnifier_volume_weighted_ = false;

    // KI-60 scheduler transients. Script executions see the complete
    // historical bar, while direct POOC/immediate market closes use the
    // monotonic broker cursor price held here.
    bool coof_scheduler_active_ = false;
    bool coof_fill_recalc_active_ = false;
    bool coof_cursor_is_bar_close_ = false;
    // finding-446: true when coof_cursor_price_ is a RAW OHLC path point /
    // magnifier tick (a broker-price fill there is nearest-tick rounded via
    // bar_fill_price); false when it is a resolved fill price (a bar-point
    // fill is already rounded, a level fill keeps its directional snap).
    bool coof_cursor_is_bar_point_ = false;
    bool coof_evaluating_path_segment_ = false;
    // KI-67: true only while the active fill recalc owns the FIRST fill event
    // at the bar-open tick (O). Orders placed while this holds keep STANDARD
    // exact-level semantics. Later fills at that same O, like fills at every
    // other path point, are MID-BAR cascades (the Pine historical cascade permission).
    bool coof_recalc_at_bar_open_ = false;
    // True only while executing a fill recalc triggered by a later fill event
    // at O, after the first O fill has already consumed bar-open provenance.
    // Such a recalc is mid-bar for KI-67 and resumes on leg 0 (O->W1). This bit
    // lets strategy.exit apply the one pinned exception: a marketable LIMIT may
    // resume at W1, while marketable STOP suppression remains whole-entry-bar.
    bool coof_recalc_after_first_open_fill_ = false;
    // Round15: identify the MARKET opening whose first callback is active.
    // A direct close/partial/reentry in that body changes the serial and must
    // not inherit the original fill's permission to arm a recrossing limit.
    uint64_t coof_market_entry_recalc_incarnation_ = 0;
    uint64_t coof_market_entry_recalc_fill_seq_ = 0;
    // KI-67: true only during a point-bar evaluation that sits AT an extreme
    // waypoint (W1 or W2) of the historical 4-tick path. Cascade orders born
    // this bar may fill only while this holds; on segments, at O, at C, and on
    // the ordinary-close / POOC-C / margin passes it is false so cascade orders
    // are held (they convert to ordinary resting orders at bar end). Set only by
    // the historical dispatch; the magnifier path never sets it.
    bool coof_at_extreme_waypoint_ = false;
    // KI-67 exit cascade: the historical dispatch publishes its current path
    // position here for the strategy.exit cascade gate. coof_hist_is_segment_
    // marks a segment (vs point) evaluation; coof_hist_path_index_ is the LEG
    // index (0..2) on a segment, or the path WAYPOINT index (0..3, cursor =
    // path[index]) on a point. Meaningful only while coof_scheduler_active_ on
    // the non-magnifier historical path; the POOC-C / margin passes publish the
    // C waypoint (index 3) so cascade exits are held there.
    bool coof_hist_is_segment_ = false;
    int coof_hist_path_index_ = -1;
    // KI-67 exit cascade: the in-flight leg index (0..2) the CURRENT fill recalc
    // was triggered on — the leg the dispatch cursor traverses next after the
    // triggering fill. Published by the loop right before each recalc so a
    // strategy.exit placed in that recalc records its seg_i from the loop's real
    // position ("a fill AT a waypoint starts the NEXT leg"), rather than
    // re-deriving it from the fill price (ambiguous exactly at waypoints). -1 (or
    // >=3) outside a mid-bar historical recalc / at the terminal C tick.
    int coof_cascade_recalc_leg_ = -1;
    // KI-67 exit cascade: set by the gate immediately before evaluate_fill_price
    // so resolve_exit_path_fill runs its open-gap shortcut on the in-flight
    // leg-end waypoint POINT even when is_entry_bar (entry + exit share a bar).
    // Reset right after that evaluation; never set on the magnifier path.
    bool coof_cascade_force_wp_gap_ = false;
    bool coof_checkpoint_contains_current_bar_ = false;
    double coof_cursor_price_ = std::numeric_limits<double>::quiet_NaN();
    // Direct strategy.close / POOC fills can occur inside on_bar rather than
    // through process_next_pending_order. The scheduler refreshes this budget
    // before every speculative execution so those fills consume the same
    // finite historical/magnifier event budget as every other broker fill.
    uint64_t coof_direct_fill_events_remaining_ = 0;
    // @broker-state begin
    // Monotonic cross-bar fill sequence counter; compared against
    // trail_best_before_bar_fill_seq_ (hashed above) and against
    // PendingOrder::signal_close_mc_fill_seq (hashed per-order) by fill-time
    // gates that cross the bar boundary (engine_fills.cpp).
    uint64_t broker_fill_event_seq_ = 0;
    // @broker-state end

    // input.source histories are base-owned script state and must roll back
    // with generated state between historical fill recalculations.
    Series<double> coof_checkpoint_src_open_;
    Series<double> coof_checkpoint_src_high_;
    Series<double> coof_checkpoint_src_low_;
    Series<double> coof_checkpoint_src_close_;
    Series<double> coof_checkpoint_src_volume_;
    Series<double> coof_checkpoint_src_hl2_;
    Series<double> coof_checkpoint_src_hlc3_;
    Series<double> coof_checkpoint_src_ohlc4_;
    Series<double> coof_checkpoint_src_hlcc4_;
    // issue #178 (JOAT aureate, round 9): the chart-close tracker
    // (prev_chart_close_ / last_chart_close_) is base-owned script state
    // too. Every historical fill recalculation and the ordinary close
    // execution start from this checkpoint and push the bar's slot again
    // (history_slot_is_new_), so without rolling the tracker back the close
    // execution of a bar whose open filled an order read prev_chart_close_
    // = the recalc's own close: its true range lost the gap to close[1].
    double coof_checkpoint_prev_chart_close_ = std::numeric_limits<double>::quiet_NaN();
    double coof_checkpoint_last_chart_close_ = std::numeric_limits<double>::quiet_NaN();

    // --- Session predicate bar-state tracking ---
    // Tracks whether the previous bar was inside the regular session.
    // Used to compute session.isfirstbar (in_session && !prev_in_session_)
    // and session.islastbar (prev_in_session_ && !in_session).
    bool prev_in_session_ = false;
    // Current-bar session predicates — recomputed at the start of each bar
    // by set_session_bar_state() (engine_run.cpp) on every bar pump.
    bool session_ismarket_ = false;
    bool session_isfirstbar_ = false;
    bool session_islastbar_ = false;

    // session.ismarket of the CHART bar stamped bar_ms on the symbol's
    // session clock — the chart-timeframe-aware rule of session_time.hpp:
    // every bar of a daily-or-higher chart is the regular-session bar,
    // intraday bars keep the time-of-day test.
    bool chart_bar_ismarket(int64_t bar_ms) const;
    // Set the three per-bar predicates for the chart bar being dispatched.
    // in_session is chart_bar_ismarket(that bar); intraday_islastbar is the
    // pump's own lookahead verdict for an intraday chart (peek at the next
    // bar, barstate.islast, or never in magnifier mode). On a D/W/M chart
    // the bar IS the whole session — its own first and last bar — so
    // session.isfirstbar and session.islastbar both equal in_session there
    // and the prev/next bookkeeping does not apply.
    void set_session_bar_state(bool in_session, bool intraday_islastbar);

    // The session.is* market-state variables as the generated strategy
    // evaluates them. Codegen lowers session.ismarket / ispremarket /
    // ispostmarket to the unqualified call
    //   pine_session_is*(syminfo_.session, syminfo_.timezone, current_bar_.timestamp)
    // inside the generated class, and class-scope lookup resolves it to these
    // members (a member hides the namespace-scope function of the same name
    // and suppresses ADL), so the chart timeframe joins the predicate with
    // the emitted code unchanged. TradingView: on "1D" and above
    // session.ismarket is always true, ispremarket / ispostmarket always
    // false — OANDA:XAUUSD @1D (1800-1700, bars stamped 17:00 ET) took 0
    // trades against TradingView's 57 while the time-of-day test decided.
    // Every BacktestEngine member resolves here too; the one caller that
    // wants the raw time-of-day test (the streaming clock's closed-interval
    // skip) qualifies pineforge:: explicitly.
    bool pine_session_ismarket(const std::string& session,
                               const std::string& tz, int64_t bar_ms) const {
        return pineforge::pine_session_ismarket(session, tz, bar_ms, script_tf_);
    }
    bool pine_session_ispremarket(const std::string& session,
                                  const std::string& tz, int64_t bar_ms) const {
        return pineforge::pine_session_ispremarket(session, tz, bar_ms, script_tf_);
    }
    bool pine_session_ispostmarket(const std::string& session,
                                   const std::string& tz, int64_t bar_ms) const {
        return pineforge::pine_session_ispostmarket(session, tz, bar_ms, script_tf_);
    }

    // --- Timeframe state ---
    std::string input_tf_;
    std::string script_tf_;
    // Cached tf_to_seconds(script_tf_). MUST be refreshed immediately after
    // every assignment to script_tf_ (both sites live in engine_run.cpp).
    // Avoids a string parse per strategy.* call.
    int script_tf_seconds_ = 0;
    TimeframeAggregator script_tf_agg_;
    int64_t prev_bar_timestamp_ = 0;

    // --- Historical -> realtime stream lifecycle ---
    // stream_begin() executes the historical warmup through the normal run()
    // path exactly once, then these fields carry the SAME broker, Pine series,
    // TA and timeframe-aggregator state forward while normalized trades arrive.
    enum class StreamPhase { IDLE, REALTIME, ENDED };
    StreamPhase stream_phase_ = StreamPhase::IDLE;
    bool stream_warmup_mode_ = false;
    int64_t stream_input_tf_ms_ = 0;
    int64_t stream_next_input_open_ms_ = 0;
    int64_t stream_clock_ms_ = 0;
    int64_t stream_last_tick_ms_ = 0;
    uint64_t stream_last_sequence_ = 0;
    bool stream_seen_sequence_ = false;
    bool stream_has_input_bar_ = false;
    Bar stream_input_bar_{};
    double stream_last_price_ = 0.0;
    bool stream_has_last_price_ = false;
    int stream_next_script_bar_index_ = 0;
    bool stream_script_bar_had_tick_ = false;
    bool stream_script_tick_seen_ = false;
    enum class StreamInputMode { UNSET, TICKS, BARS };
    StreamInputMode stream_input_mode_ = StreamInputMode::UNSET;
    bool stream_observe_actions_ = false;
    uint64_t stream_action_sequence_ = 0;
    std::vector<StreamOrderAction> stream_order_actions_;

    // --- request.security state ---
    struct HistoricalSecurityProjection {
        Bar bar{};
        // The instant the projection is dispatched on: the first retained
        // chart child's timestamp on the single-feed path, that child's first
        // auxiliary bar on the split-feed path (the requested-context
        // evaluator is fed the finer slice there). Keyed by instant, not by
        // feed-call index, so both paths consume one projection per bucket.
        int64_t first_child_ms = 0;
        bool is_complete = false;
    };

    struct SecurityEvalState {
        int sec_id = 0;
        std::string tf;
        TimeframeAggregator aggregator;
        Bar current_bar{};
        bool gaps_on = false;
        bool lookahead_on = false;
        // Heikin-Ashi same-symbol read: request.security(ticker.heikinashi(
        // syminfo.tickerid), ...). When set, the completed (aggregated) bar's
        // OHLC is replaced by its Heikin-Ashi candle before the security
        // expression is evaluated, so close/open/high/low inside the call see
        // HA values. HA is stateful (ha_open depends on the prior HA bar), so
        // the running state lives here per sec_id.
        bool heikinashi = false;
        double ha_prev_open = 0.0;
        double ha_prev_close = 0.0;
        bool ha_seeded = false;
        bool lower_tf_requested = false;
        bool lower_tf_emulation = false;
        int lower_tf_ratio = 0;
        int lower_tf_seconds = 0;
        int current_sub_bar_count = 0;
        int64_t feed_count = 0;
        int64_t eval_complete_count = 0;
        int64_t eval_partial_count = 0;
        // Requested-context bar index of the latest dispatch_security_eval()
        // (the ring address its TA members saw, see ta::bar_context()); -1
        // before the first dispatch. The calling-boundary replay re-dispatches
        // the same bar under the same index.
        int64_t ta_bar_index = -1;
        // ``request.security_lower_tf`` returns one element per
        // synthesised sub-bar of the current chart bar, so the codegen
        // needs to know which sub-bar inside the current chart bar is
        // currently being processed by the per-sec_id evaluator method.
        // ``lower_tf_array_requested`` is set by
        // ``register_security_lower_tf_eval`` and forces an extra
        // lower-TF-emulation validity check in
        // ``validate_security_timeframes``. ``lower_tf_sub_bar_index``
        // is reset to 0 at the start of every
        // ``feed_security_eval_state`` invocation in lower-TF
        // emulation mode and incremented after each per-sub-bar
        // dispatch so the codegen can clear its accumulator on index
        // 0 and then push for every subsequent sub-bar.
        bool lower_tf_array_requested = false;
        int lower_tf_sub_bar_index = 0;
        // ``lower_tf_use_input`` selects the input-passthrough LTF path:
        // when the requested TF is >= input_tf and < script_tf we hand
        // the per-script-bar window of real input bars to the codegen
        // (optionally roll-up aggregated when req > input). Mutually
        // exclusive with ``lower_tf_emulation`` (synthesis) — only one
        // is set per state. ``lower_tf_input_aggregation_ratio`` is
        // ``req_seconds / input_seconds`` (>=1; 1 means raw passthrough,
        // N means N raw input bars roll up into one returned LTF bar).
        // ``lower_tf_input_buffer`` accumulates raw input bars within
        // the current script-TF chunk and is flushed at chunk
        // completion (or at end of feed for trailing partial chunks).
        bool lower_tf_use_input = false;
        int lower_tf_input_aggregation_ratio = 1;
        std::vector<Bar> lower_tf_input_buffer;
        // Plain ``request.security`` (not ``_lower_tf``) with a requested TF
        // STRICTLY FINER than script_tf (e.g. so2TF="5" read from a 15m
        // chart) under ``lookahead=barmerge.lookahead_ON``: the security's
        // own aggregator completes multiple times
        // (script_seconds / requested_seconds) per calling/script bar. A
        // history-offset read (``expr[1]`` inside the security call, see
        // the ``*_hist`` push/read machinery in codegen) is meant to expose
        // "the value already confirmed as of the close of the PREVIOUS
        // calling bar" — TV's lookahead_on merge takes the FIRST intrabar
        // of each calling bar, so the publish granularity is the CALLING
        // bar, not the security's own (finer) period. Without this, the
        // read-before-push ``hist[0]`` gets refreshed on every one of the
        // R completions inside the current calling bar, so by the time
        // on_bar() reads it the value has silently drifted to "one
        // security-period behind the LAST completion of THIS SAME calling
        // bar" (e.g. the middle of 3 sub-periods) instead of "the last
        // completion of the PREVIOUS calling bar" — an aliasing bug
        // confirmed against TradingView-exported trades on a triple-RSI
        // DCA strategy using so2Rsi = request.security(sym, "5",
        // ta.rsi(close,7)[1], lookahead=barmerge.lookahead_on) on a 15m
        // chart (finer target under lookahead + offset).
        //
        // ``lookahead_OFF`` is deliberately NOT gated (field stays 0): TV's
        // lookahead_off merge takes the LAST intrabar of the calling bar,
        // so the exposed value — and any ``[k]`` history offset off it —
        // advances at the security's own finer cadence (one hist.push per
        // completed security period), which is exactly the ungated
        // behavior. Gating lookahead_off regressed
        // masayanfx-multi-time-score-strategy
        // (request.security(sym, "5", ta.highest(high, 20)[1],
        // barmerge.gaps_off, barmerge.lookahead_off) on a 15m chart) from
        // 100.0% to 93.7% trade parity vs TradingView.
        //
        // When nonzero, this holds the requested TF's duration in seconds
        // (script_seconds % this == 0 verified at validate time) and gates
        // ``feed_security_eval_state``'s aggregator branch: only the
        // completion whose bucket END aligns to a script_tf boundary is
        // passed through to ``evaluate_security`` as ``is_complete = true``
        // (letting codegen's ``hist.push()`` fire); all other completions
        // within the same calling bar are still evaluated (so the
        // underlying TA state keeps advancing at native/security
        // resolution) but are passed ``is_complete = false`` so they do not
        // advance the exposed history buffer. Zero (the default) means "not
        // applicable" (target TF coarser than or equal to script_tf, or
        // lookahead_off — the already-correct cases) and leaves behavior
        // unchanged.
        int publish_gate_tf_seconds = 0;
        // Plain ``request.security`` with a requested TF strictly finer than
        // script_tf, served by the auxiliary finer feed (the split-feed
        // path), under ``lookahead_off``: TradingView surfaces the LAST
        // intrabar of the calling chart bar at that bar's close whatever
        // the bucket's sub-bar count -- on the OANDA:XAUUSD 1D chart the
        // Thanksgiving 2025-11-26 bar's last 3m bucket (21:57Z, holding
        // the 21:59Z minute alone before the 22:00Z session close) is the
        // value ``request.security(tickerid, "3", ta.rsi(close, 14))``
        // reads at the daily close (72.64, lab tv dca-ltf-last-intrabar,
        // 2026-09-05), where the aggregator's count / real-end /
        // session-close rules leave that bucket partial until the next
        // chart bar's first sub-bar and the close read the 21:54Z bucket
        // (38.87). When set, feed_security_eval_state
        // finalizes and publishes the pending partial bucket on the
        // calling bar's last auxiliary bar (TimeframeAggregator::
        // complete_pending_partial), once: the next chart bar's first
        // sub-bar resets the bucket without re-emitting it. Dense feeds
        // whose final bucket completes on its count are untouched (no
        // partial is pending), and so are lanes without the auxiliary
        // slice, lookahead_on (its gated publication is untouched: on this
        // shape it stays one bucket behind, as before -- the tape pins
        // lookahead_off only), lower-TF arrays and calendar / same-TF
        // requests. False (the default) means "not applicable".
        bool calling_close_completes_partial = false;
        // Plain ``request.security`` with a requested TF strictly finer than
        // script_tf, served by the auxiliary finer feed (the split-feed
        // path), under ``lookahead_on``: TradingView's merge takes the FIRST
        // intrabar of the calling chart bar and holds it for the bar -- on
        // the BINANCE:BTCUSDT 1D chart ``request.security(tickerid, "15",
        // ta.rsi(close, 14)[1], lookahead_on)`` reads, on every daily bar,
        // the 15m RSI of the previous day's LAST bucket, i.e. ``rsi[1]``
        // evaluated on the day's first 15m bucket, na on the range's first
        // bar (lab tv notrade-ltf-sample-btc1d, 2025-04-01..20, 18/18,
        // 2026-09-05), so a plain ``expr`` reads the day's first bucket and
        // ``expr[k]`` the k-th bucket before it, at the requested cadence.
        // The legacy gate above (publish_gate_tf_seconds) publishes one
        // bucket per calling bar -- the LAST one -- which reads right for
        // ``expr[1]`` alone and one bucket late for ``expr``. When set, the
        // evaluator publishes EVERY completed requested bucket (the exposed
        // history advances per bucket, as under lookahead_off), and
        // feed_aux_security_for_chart_bar feeds the calling bar's auxiliary
        // bars only up to the one completing its FIRST bucket before the
        // chart body runs; the rest of the slice is held in ``deferred_aux``
        // and fed by feed_deferred_aux_security_for_chart_bar right after
        // dispatch_bar, so the body reads the first-bucket evaluation while
        // the TA state still sees every sub-bar, in order, before the next
        // chart bar. publish_gate_tf_seconds stays 0 on this path; lanes
        // without the auxiliary slice keep the gate. False (the default)
        // means "not applicable".
        bool calling_open_latches_first = false;
        // Per calling chart bar: whether this state's first bucket of the
        // slice has been published (the deferral point), and the auxiliary
        // bars held back until after the chart body, each with the
        // security_next_input_ms_ / calling_bar_complete it was fed with.
        bool first_bucket_published = false;
        // The label (bucket open) of the slice's first requested bucket:
        // a completion published by this slice's first auxiliary bars that
        // carries an OLDER label is the boundary emission of the previous
        // slice's still-pending bucket (a tail the count / real-end /
        // session-close rules left partial), not this bar's first bucket.
        int64_t slice_open_label = 0;
        // The label of the latest completed bucket this evaluator published
        // through its aggregator (feed_security_eval_state), whatever the
        // state's current bucket is afterwards.
        int64_t last_published_label = 0;
        struct DeferredAuxBar {
            Bar bar;
            int64_t next_input_ms = 0;
            bool calling_bar_complete = false;
        };
        std::vector<DeferredAuxBar> deferred_aux;
        // One entry per projected HTF bucket, populated only for an explicitly
        // opted-in finite historical batch. Empty for every default/streaming
        // run and for sites outside the narrow HTF lookahead_on+gaps_off
        // contract. The feed index advances once per retained input bar (bars
        // before an opt-in security range start are dropped by both producer
        // and consumer); the projection cursor advances only at the next
        // bucket's first child.
        std::vector<HistoricalSecurityProjection> historical_projections;
        std::size_t historical_projection_cursor = 0;
        // Which projection (cursor) has already been dispatched: every later
        // input of the same bucket is a no-op for the evaluator.
        bool historical_projection_dispatched = false;
        // Native higher-timeframe feed routing, rebuilt per run by
        // prepare_native_security_feeds(): the index into
        // native_security_feeds_ serving this state's requested timeframe
        // (-1: none, the aggregate stands), and that feed's bars keyed by
        // the label this state's aggregator stamps on the same bucket --
        // TimeframeAggregator::bar_label_ms of the native bar's covered
        // session instant -- so a completed bucket finds its exchange bar by
        // the timestamp the aggregate already carries. The same call installs
        // the feed's stamps into this state's aggregator as its period
        // partition (TimeframeAggregator::set_native_periods): the bucket's
        // span, label and completion bar are the native bar's own.
        int native_feed_index = -1;
        std::unordered_map<int64_t, Bar> native_bars_by_label;
    };

    std::vector<SecurityEvalState> security_eval_states_;
    // Boundary-fallback publication replays the completed caller's already
    // evaluated final requested value. Force generated TA sites down their
    // recompute path so the replay advances merged history only, never the
    // requested-context TA cadence. Keep this byte layout-unconditional so
    // generated strategy TUs and the statically linked runtime always agree on
    // BacktestEngine offsets.
    bool security_history_publication_replay_ = false;

#ifdef PINEFORGE_HAS_AUX_SECURITY_FEED_V1
    // Optional immutable finer feed for request.security. Native chart bars
    // remain the sole source for current_bar_, broker execution and
    // bar_index_. Per-run ranges map each chart bar to its auxiliary slice.
    std::vector<Bar> aux_security_bars_;
    std::string aux_security_input_tf_;
    std::vector<std::size_t> aux_security_chart_begin_;
    std::vector<std::size_t> aux_security_chart_end_;
#endif
    // The raw feed used by security aggregators in the active run. This is the
    // chart input TF on the legacy path and the auxiliary TF on the split path.
    std::string security_input_tf_;

    // Native higher-timeframe request.security feeds: the exchange's own
    // bars of one timeframe each (TradingView's "D" bar on an intraday chart
    // is the settlement / official close, not the last intraday close). A
    // completed request.security bucket of a fed timeframe takes the native
    // bar's OHLCV; timing, other timeframes, chart and broker are untouched.
    // Layout-unconditional like the aux feed's siblings above.
    struct NativeSecurityFeed {
        std::string tf;
        int seconds = 0;
        std::vector<Bar> bars;
    };
    std::vector<NativeSecurityFeed> native_security_feeds_;
    int64_t diag_native_security_substitutions_ = 0;
    int64_t diag_native_security_misses_ = 0;
    // The chart symbol's own daily partition, built per run from the native
    // "D" feed's stamps on an intraday chart (prepare_chart_day_partition)
    // and installed for the run's bar loop (NativeDayPartitionScope) so the
    // chart-level D consumers -- time("D") / time_close("D"),
    // timeframe.change("1D"), ta.change(time("D")), ta.vwap's daily anchor --
    // read TradingView's trade-date daily bars (timeframe.hpp). Empty on a
    // run without the feed or on a calendar chart: every rule nominal.
    NativeDayPartition chart_day_partition_;

    // --- Runtime trace state ---
    // Gated by ``trace_enabled_`` (default false) so production strategies
    // pay zero cost; the validator flips it on per-strategy when it needs
    // engine-internal per-bar values for TV cross-referencing.
    //
    // ``trace_buffer_`` is a flat vector of POD records (no string allocs
    // per call); each entry holds a ``name_id`` indexing into
    // ``trace_names_``, which is the unique-name table built by
    // ``intern_trace_name``. A first-time name pays one ``unordered_map``
    // insert + ``string`` push_back; subsequent calls with the same name
    // are a single map lookup.
    bool trace_enabled_ = false;

    // Live-runtime surface (ABI v4). All default off/zero; historical runs are
    // byte-identical when untouched (tests/test_live_flags_off_identity.cpp).
    int last_run_status_ = 0;               // 0 completed, 1 NOT_COMPLETED (abort)

    // Cooperative abort (spec §3.5): set from any thread via request_abort();
    // consumed by the run in progress at the top of each bar-loop iteration
    // via check_abort(), which unwinds the run with AbortRequested. Cleared
    // at every run() entry, so a request made while idle is a no-op.
    //
    // AbortFlag wraps std::atomic<bool> in a copy/move-constructible shell:
    // std::atomic itself has its copy/move members deleted, and some tests
    // (e.g. tests/test_pooc_global_full_exit.cpp's ``run_case``) return a
    // BacktestEngine subclass by value, which needs the class to stay
    // implicitly copyable. Copying/moving never carries an in-flight abort
    // request across — there is no "run in progress" on a copy — so the
    // copy always starts cleared.
    struct AbortFlag {
        std::atomic<bool> value{false};
        AbortFlag() = default;
        AbortFlag(const AbortFlag&) noexcept {}
        AbortFlag(AbortFlag&&) noexcept {}
        AbortFlag& operator=(const AbortFlag&) noexcept {
            value.store(false, std::memory_order_relaxed);
            return *this;
        }
        AbortFlag& operator=(AbortFlag&&) noexcept {
            value.store(false, std::memory_order_relaxed);
            return *this;
        }
        bool load(std::memory_order order) const { return value.load(order); }
        void store(bool v, std::memory_order order) { value.store(v, order); }
    };
    AbortFlag abort_requested_;
    struct AbortRequested {};               // thrown inside the bar loops only
    void check_abort() {
        if (abort_requested_.load(std::memory_order_relaxed)) throw AbortRequested{};
    }

    std::vector<TraceEntryC> trace_buffer_;
    std::vector<std::string> trace_names_;
    std::unordered_map<std::string, int32_t> trace_name_index_;

    int32_t intern_trace_name(const std::string& name);

    int64_t diag_input_bars_processed_ = 0;
    int64_t diag_script_bars_processed_ = 0;
    int64_t diag_magnifier_sub_bars_processed_ = 0;
    int64_t diag_magnifier_sample_ticks_processed_ = 0;
    int diag_script_tf_ratio_ = 0;
    bool diag_needs_aggregation_ = false;

    // Captured by the public run() wrappers when the underlying engine logic
    // throws. Cleared at the start of every run(). Surfaces through
    // last_error() / pf_strategy_get_last_error() so the C ABI never
    // unwinds a C++ exception across the extern "C" boundary.
    std::string last_error_;

    void register_security_eval(int sec_id, const std::string& requested_tf,
                                const std::string& input_tf, bool lookahead_on,
                                bool gaps_on = false, bool heikinashi = false);
    // ``request.security_lower_tf`` registers the same per-sec_id eval
    // state but with the additional contract that the requested TF must
    // resolve to a finer-than-input TF emulation. This wrapper sets the
    // ``lower_tf_array_requested`` flag so ``validate_security_timeframes``
    // can throw a precise error if the chart's input TF turns out to be
    // <= the requested TF (mirroring TradingView's "lower timeframe
    // required" error for ``request.security_lower_tf``).
    void register_security_lower_tf_eval(int sec_id, const std::string& requested_tf,
                                         const std::string& input_tf);
    // Sub-bar index (0-based) of the current ``request.security_lower_tf``
    // synthesis within the current chart bar. Returns 0 outside the
    // synthesis loop. Used by codegen to clear its per-call vector at
    // sub-bar 0 and push one element per sub-bar after.
    int security_lower_tf_sub_bar_index(int sec_id) const;
    void validate_security_timeframes(const std::string& input_tf);
    bool security_series_slot_is_new(int sec_id) const;
    // The one path to evaluate_security(): installs the requested context's
    // bar index for the evaluator's TA members (ta::bar_context()) for the
    // duration of the dispatch. `bar_index` is the 0-based index of the
    // requested-context bar being evaluated — the just-completed bucket for a
    // complete evaluation (eval_complete_count - 1), the in-progress bucket
    // for a partial/lookahead one (eval_complete_count) — so every
    // compute()/recompute() dispatch of one requested bar rewrites the same
    // ring slot, and a conditional window call inside the security expression
    // is addressed exactly like TradingView addresses it.
    void dispatch_security_eval(SecurityEvalState& state, const Bar& bar,
                                bool publish, int64_t bar_index);
    // KI-55 range-start gate for one evaluator: true when the input bar at
    // `input_ts` belongs to an HTF bucket that opened before the cut --
    // security_range_start_ms_ under the flag, else the run's first chart
    // bar for a coarser-than-chart / chart-timeframe evaluator
    // (security_first_chart_bar_ms_, split-feed runs with the auxiliary feed
    // proving prior trading, or single-feed historical intraday forex/cfd D
    // requests keyed to their session's actual open; false for lower TFs). The
    // progressive feed and the historical lookahead projection builder must
    // agree on this predicate so projected child indexes line up with the
    // per-state feed cursor.
    bool security_input_precedes_range_start(const SecurityEvalState& state,
                                             int64_t input_ts) const;
#ifdef PINEFORGE_HAS_AUX_SECURITY_FEED_V1
    // True when the auxiliary request.security feed holds a bar in
    // [from_ms, to_ms): the evidence that an HTF bucket whose nominal open
    // precedes the run's first chart bar was in progress at the range start.
    bool aux_security_traded_between(int64_t from_ms, int64_t to_ms) const;
#endif
    void feed_security_eval_state(
        SecurityEvalState& state, const Bar& input_bar,
        bool calling_bar_complete = false);
    void publish_security_eval_state_at_calling_boundary(
        SecurityEvalState& state);

    // A new batch run (including stream_begin's historical warmup) starts a
    // fresh script lifecycle. Called once after broker reset, before any
    // requested/chart computation or per-bar checkpoint. Generated subclasses
    // reset their own persistent state here, then optionally prepare the
    // current run's static TA cache. Config/inputs/feeds belong to the engine
    // and survive. Streaming ticks and fill recalculations never call this.
    virtual void prepare_script_run(const Bar*, int, bool) {}

    virtual void configure_security_evaluators() {}
    virtual void evaluate_security(int sec_id, const Bar& bar, bool is_complete) {}
    virtual void clear_security(int sec_id) {}

    // Generated-state transaction hooks for calc_on_order_fills. Snapshot is
    // called once before the broker walks a historical bar; restore precedes
    // every fill recalc and the ordinary close execution. The completed
    // ordinary-close execution becomes the committed checkpoint. Historical
    // post-C fill recalculations start from it, recompute its current-bar
    // history slot, and are rolled back after their broker effects persist.
    virtual void snapshot_script_state() {}
    virtual void restore_script_state() {}
    virtual void commit_script_state() {}

    // Magnifier helpers
    void run_magnified_bar(
        const std::vector<Bar>& sub_bars, int64_t script_bar_ts,
        bool caller_completed_on_boundary = false);
    void run_magnified_bar_calc_on_order_fills(const std::vector<Bar>& sub_bars,
                                               int64_t script_bar_ts,
                                               bool caller_completed_on_boundary = false);
    virtual void finalize_bar() {}

    // --- Equity extremes update (called after each on_bar) ---
    // NOTE: the dd/runup walk in src/engine_metrics.cpp (compute_equity_stats)
    // MUST mirror this trough-reset logic; keep in lockstep. The fold is
    // exactly one per script bar and always paired with record_equity_point,
    // so the curve holds the very values folded here and a re-walk of the
    // curve through fold_equity_extreme reproduces the scalars bit for bit
    // — record_range_end_close_trades (engine_orders.cpp) relies on that
    // when it re-marks the last point.
    void fold_equity_extreme(double eq) {
        if (eq > max_equity_) {
            max_equity_ = eq;
            min_equity_ = eq;  // reset trough on new peak
        }
        if (eq < min_equity_) {
            min_equity_ = eq;
        }
        double dd = max_equity_ - eq;
        if (dd > max_drawdown_) max_drawdown_ = dd;
        double ru = eq - min_equity_;
        if (ru > max_runup_) max_runup_ = ru;
    }
    void update_equity_extremes() {
        fold_equity_extreme(initial_capital_ + net_profit_sum_ + open_profit(current_bar_.close));

        // --- Update max_contracts_held_* running peaks ---
        double abs_qty = std::abs(position_qty_);
        if (position_side_ != PositionSide::FLAT) {
            if (abs_qty > max_contracts_held_all_) max_contracts_held_all_ = abs_qty;
            if (position_side_ == PositionSide::LONG && abs_qty > max_contracts_held_long_)
                max_contracts_held_long_ = abs_qty;
            if (position_side_ == PositionSide::SHORT && abs_qty > max_contracts_held_short_)
                max_contracts_held_short_ = abs_qty;
        }
    }

    // Record one equity point per SCRIPT bar. ``script_bar_ts`` must be the
    // script-bar open timestamp captured BEFORE dispatch — current_bar_.timestamp
    // is overwritten by the magnifier sub-bar walk (engine_run.cpp), which would
    // make the curve differ between magnifier on/off.
    void record_equity_point(int64_t script_bar_ts) {
        if (equity_curve_.empty()) first_bar_open_ = current_bar_.open;
        pf_equity_point_t p;
        p.time_ms = script_bar_ts;
        p.open_profit = open_profit(current_bar_.close);
        p.equity = initial_capital_ + net_profit_sum_ + p.open_profit;
        equity_curve_.push_back(p);
        if (position_side_ != PositionSide::FLAT) ++bars_in_market_;
    }

    // --- Trade history accessors (for strategy.closedtrades.*) ---
    double closed_trade_profit(int index) const {
        if (index >= 0 && index < (int)trades_.size())
            return trades_[index].pnl;
        return 0.0;
    }
    double closed_trade_profit_percent(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::numeric_limits<double>::quiet_NaN();
        return trades_[idx].pnl_pct;
    }
    double closed_trade_commission(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::numeric_limits<double>::quiet_NaN();
        return trades_[idx].commission;
    }
    int closed_trade_entry_bar_index(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return na<int>();
        return trades_[idx].entry_bar_index;
    }
    int closed_trade_exit_bar_index(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return na<int>();
        return trades_[idx].exit_bar_index;
    }
    std::string closed_trade_entry_comment(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::string();
        return trades_[idx].entry_comment;
    }
    std::string closed_trade_exit_comment(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::string();
        return trades_[idx].exit_comment;
    }
    std::string closed_trade_entry_id(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::string();
        return trades_[idx].entry_id;
    }
    std::string closed_trade_exit_id(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::string();
        return trades_[idx].exit_id;
    }
    uint64_t closed_trade_entry_incarnation(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0;
        return trades_[idx].entry_incarnation;
    }
    double closed_trade_entry_price(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::numeric_limits<double>::quiet_NaN();
        return trades_[idx].entry_price;
    }
    double closed_trade_exit_price(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::numeric_limits<double>::quiet_NaN();
        return trades_[idx].exit_price;
    }
    int64_t closed_trade_entry_time(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0;
        return trades_[idx].entry_time;
    }
    int64_t closed_trade_exit_time(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0;
        return trades_[idx].exit_time;
    }
    double closed_trade_size(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return std::numeric_limits<double>::quiet_NaN();
        return trades_[idx].qty;
    }
    double closed_trade_max_runup(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0.0;
        return trades_[idx].max_runup;
    }
    // Percent excursions: trade.max_runup / max_drawdown are stored in
    // account currency (× pointvalue, see emit_close_trade), so the entry
    // cost denominator must be in currency too (entry × qty × pointvalue).
    // pointvalue=1 cancels out and matches the legacy ratio bit-for-bit.
    double closed_trade_max_runup_percent(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0.0;
        const Trade& t = trades_[idx];
        double cost = t.entry_price * t.qty * syminfo_.pointvalue;
        return (cost > 0.0) ? (t.max_runup / cost) * 100.0 : 0.0;
    }
    double closed_trade_max_drawdown(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0.0;
        return trades_[idx].max_drawdown;
    }
    double closed_trade_max_drawdown_percent(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return 0.0;
        const Trade& t = trades_[idx];
        double cost = t.entry_price * t.qty * syminfo_.pointvalue;
        return (cost > 0.0) ? (t.max_drawdown / cost) * 100.0 : 0.0;
    }

    // --- Direction accessors ---
    std::string closed_trade_direction(int idx) const {
        if (idx < 0 || idx >= (int)trades_.size()) return "";
        return trades_[idx].is_long ? "long" : "short";
    }
    std::string open_trade_direction(int idx) const {
        if (position_side_ == PositionSide::FLAT || idx < 0 || idx >= (int)pyramid_entries_.size()) return "";
        return (position_side_ == PositionSide::LONG) ? "long" : "short";
    }

    // --- Open position trade accessors (strategy.opentrades.*) ---
    double open_trade_profit(int idx) const;
    double open_trade_profit_percent(int idx) const;
    double open_trade_commission(int idx) const;
    int open_trade_entry_bar_index(int idx) const;
    std::string open_trade_entry_comment(int idx) const;
    std::string open_trade_entry_id(int idx) const;
    double open_trade_entry_price(int idx) const;
    int64_t open_trade_entry_time(int idx) const;
    double open_trade_size(int idx) const;
    double open_trade_max_drawdown(int idx) const;
    double open_trade_max_drawdown_percent(int idx) const;
    double open_trade_max_runup(int idx) const;
    double open_trade_max_runup_percent(int idx) const;

    std::string position_entry_name() const {
        if (position_side_ == PositionSide::FLAT || pyramid_entries_.empty()) return "";
        return pyramid_entries_.back().entry_id;
    }

    double max_drawdown_percent() const {
        return (initial_capital_ > 0.0) ? (max_drawdown_ / initial_capital_) * 100.0 : 0.0;
    }

    int64_t time_close() const {
        return pine_time_close(current_bar_.timestamp, script_tf_, syminfo_.session, syminfo_.timezone, script_tf_);
    }

    // Internal sizing helper; protected (alongside calc_qty) so the sizing-guard
    // test can exercise the fill_price<=0 / NaN rejection path directly. See
    // tests/test_adversarial_ohlcv.cpp.
    double calc_qty_for_type(double fill_price, double qty_value, int qty_type) const;

private:
    execution::Result settle_with_context_scoped(
        const execution::Action& action, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context,
        execution::CloseScope scope);
    execution::Result settle_with_context_selected(
        const execution::Action& action, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context,
        const execution::SelectedOpeningSet& selection);
    execution::AccountEffectProjection project_with_membership(
        const execution::Action& action,
        const execution::Fill& fill,
        execution::CloseScope book_or_opening,
        const execution::SelectedOpeningSet* selected) const;
    execution::SettlementInspection inspect_with_membership(
        const execution::Action& action,
        const execution::Fill& fill,
        execution::CloseScope book_or_opening,
        const execution::SelectedOpeningSet* selected) const;
    execution::Result settle_with_membership(
        const execution::Action& action, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context,
        execution::CloseScope book_or_opening,
        const execution::SelectedOpeningSet* selected);
    struct NativeSettlementStage;
    struct NativeSettlementRows;
    execution::Status validate_native_settlement_book(double& held) const;
    execution::Status allocate_native_settlement_closes(
        NativeSettlementStage& stage,
        const execution::CloseScope& book_or_opening,
        double& remaining) const;
    void finish_native_settlement_stage(
        NativeSettlementStage& stage, const execution::Fill& fill) const;
    execution::SettlementInspection inspect_native_settlement_stage(
        const NativeSettlementStage& stage, const execution::Fill& fill) const;
    execution::AccountEffectProjection project_native_settlement_stage(
        const NativeSettlementStage& stage, const execution::Fill& fill) const;
    execution::Result commit_native_settlement_stage(
        NativeSettlementStage& stage, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context);
    void build_native_settlement_close_rows(
        const NativeSettlementStage& stage, const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context,
        NativeSettlementRows& rows) const;
    execution::Status prepare_native_settlement_commit(
        const NativeSettlementStage& stage, const execution::Fill& fill,
        const execution::PhysicalExecutionContext& context,
        NativeSettlementRows& rows) const;
    execution::Status preflight_native_settlement_effects(
        const NativeSettlementStage& stage,
        const execution::LifecycleEffects& lifecycle,
        const NativeSettlementRows& rows);
    execution::Result commit_prepared_native_settlement_stage(
        NativeSettlementStage& stage, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context,
        NativeSettlementRows& rows);
    execution::Result settle_source_staged_execution(
        NativeSettlementStage& stage, const execution::Fill& fill,
        const execution::LifecycleEffects& lifecycle,
        const execution::PhysicalExecutionContext& context);
    void stage_native_settlement(
        NativeSettlementStage& stage,
        const execution::Action& action,
        const execution::Fill& fill,
        execution::CloseScope book_or_opening,
        const execution::SelectedOpeningSet* selected,
        const execution::LifecycleEffects* lifecycle) const;
    void stage_native_settlement(
        NativeSettlementStage& stage,
        const execution::ReverseTo& reversal,
        const execution::Fill& fill,
        const execution::LifecycleEffects* lifecycle) const;
    enum class PositionReductionCause {
        SCRIPT_ORDER,   // strategy.close / close_all / market exit / reversal
        BRACKET_EXIT,   // a strategy.exit bracket leg fill
        MARGIN_CALL,
    };

    void execute_market_entry(const std::string& id, bool is_long, double fill_price,
                              double explicit_qty,
                              int explicit_qty_type,
                              PositionSide created_position_side,
                              bool close_only_opposite,
                              bool is_priced_entry,
                              double tv_carry_qty,
                              int created_bar,
                              bool later_same_tick_entry,
                              bool paired_flat_market_transaction,
                              bool explicit_qty_prequantized,
                              uint64_t entry_incarnation);
    void execute_market_exit(double fill_price);
    void append_same_side_fill(PyramidEntry lot);
    void append_quoted_lot(PyramidEntry lot, double total_qty, double average_price);
    // Allocates the new position cycle, lots and observations, then binds
    // exits that still remain in pending_orders_. Settlement that authorized
    // pending removals applies those erasures after old-cycle unbind and
    // before this opening bind.
    void open_quoted_position(PositionSide requested, PyramidEntry lot);
    // Range-end accounting: record the rows that close a position still
    // open after the final script bar at that bar's close, the way
    // TradingView's deep-backtest report does (engine_orders.cpp). Called by
    // every run() overload after its bar loop; a no-op when flat or during
    // a stream warmup replay. Reporting only: the live position is kept; the
    // last equity point is re-marked to the flat account and the scalar
    // drawdown / run-up extremes re-folded from the curve to match.
    void record_range_end_close_trades();
    void execute_partial_exit_qty(
        double fill_price, double qty_to_close,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    void execute_partial_exit(
        double fill_price, double qty_percent,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    void execute_partial_exit_by_entry(
        double fill_price, const std::string& from_entry,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    void execute_partial_exit_by_entry_qty(
        double fill_price,
        const std::string& from_entry,
        double qty_to_close,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    void execute_partial_exit_by_entry_percent(
        double fill_price, const std::string& from_entry, double qty_percent,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    // KI-62: scratch (close dur-0) any same-bar same-id MARKET pyramid-add
    // slices still open after a from_entry priced bracket exit fills — TV's
    // open-tick fill sequence covered them. Targets only flagged same-bar add
    // slices (never the frozen pre-add lot, never a prior-bar slice). Returns
    // the qty scratched (0 = no collision → strict no-op).
    double cover_samebar_market_adds_on_exit(
        const PendingOrder& order, double fill_price,
        PositionReductionCause cause = PositionReductionCause::SCRIPT_ORDER);
    void cancel_oca_group(std::string oca_name, std::string exclude_id);
    // Pine v6 oca.reduce: when one sibling fills qty Q, reduce remaining
    // siblings' qty by Q. Siblings whose qty becomes <= 0 are cancelled.
    void reduce_oca_group(std::string oca_name, std::string exclude_id,
                          double filled_qty);
    void purge_exit_orders(bool retain_for_pending_entries = false);

    // process_pending_orders helpers (defined in engine_fills.cpp).
    // Decomposed during the function-decomposition refactor so the
    // bar-pump fill loop is reviewable rather than a 600-line monolith.
    void update_trail_best_for_bar_open(const Bar& bar);
    void sort_exit_siblings_by_path_fill(const Bar& bar);
    admission::Configuration admission_configuration() const;
    admission::CurrentPrices admission_current_prices(const PendingOrder& order) const;
    admission::BookObservation admission_book_observation(const PendingOrder& order) const;
    admission::CommandCapture begin_market_command(admission::CommandKind kind,
        const std::string& id, bool buy, double qty, int qty_type,
        double limit, double stop, const std::string& oca, int oca_type);
    void bind_market_command(PendingOrder& order, admission::CommandCapture& command);
    admission::ReviewCapture begin_market_review(admission::Checkpoint checkpoint);
    void reclaim_market_admission();
    // The generic engine asks for an opening-admission decision through this
    // source-owned seam.  The Pine compatibility adapter is implemented in
    // engine_market_admission.cpp and is deliberately absent from this
    // public engine header.
    bool opening_admission_eligible(const MarketAdmissionDraft& draft) const;
    void record_market_sizing_revision(PendingOrder& order, admission::SizingObservation before,
                                      double affordability_before);
    bool pending_flat_market_pair_scope_is_live() const;
    bool default_flat_market_gross_scope_is_live() const;
    void finalize_default_flat_market_gross_admission();
    void apply_pooc_coof_explicit_flat_market_gross_admission();
    void finalize_pending_flat_market_pairs(const Bar& bar);
    void sort_orders_by_fill_phase(const Bar& bar);
    bool short_seed_collision_materialization_is_live(
        const PendingOrder& order) const;
    bool short_seed_collision_final_short_is_live(
        const PendingOrder& order) const;
    // round 8 family S (PendingOrder::pine_frozen_market_instruction): the same-bar MARKET
    // transaction's scope, the close-artifact predicate (rule 4) and the
    // frozen-transaction reversal kernel (rules 1/2).
    bool same_bar_market_tx_scope_is_live() const;
    void finalize_same_bar_market_tx_book();
    bool same_bar_market_close_artifact_is_live(
        const PendingOrder& order) const;
    void apply_same_bar_market_tx_reversal(PendingOrder& order, double fill_price,
                                           const Bar& bar,
                                           double& trail_best_path_state);
    // TradingView binds a valid, single/full, non-trailing strategy.exit to a
    // co-queued high-level MARKET parent. If that parent fills at the next open
    // and exactly one bracket leg is already marketable there — the stop
    // breached, or the limit at-or-through the open — the newborn lot
    // scratches at that open (duration-0, PnL-0). On a market REVERSAL parent
    // this is the standing prior-bar strategy.exit whose levels were computed
    // from the reversed-away position's avg price: TV honors that stale order
    // at the fill bar's open instead of waiting for the re-priced bracket
    // (rhyme17 finding 278 seed (b), six tape-proven limit-leg events).
    // The helper proves the parent/child/fresh-lot provenance; it deliberately
    // excludes POOC, COOF, magnifier, same-direction adds, priced parents,
    // multi-child groups, and dual-marketable brackets.
    // limit_leg (optional out): set true iff the LIMIT leg is the marketable
    // one, so the fill site can take the unslipped limit-or-better path.
    bool prearmed_market_parent_bracket_gaps_at_open(
        const PendingOrder& order, const Bar& bar,
        bool* limit_leg = nullptr) const;
    bool pending_flat_market_pair_is_live(const PendingOrder& order) const;
    void invalidate_pending_flat_market_pair(int64_t created_seq);
    void compact_filled_pending_orders(std::vector<uint64_t>& retired_incarnations,
                                       int exit_closed_from_bar,
                                       uint64_t exit_closed_from_incarnation,
                                       bool exit_closed_was_long);
    // Apply a fill to engine state: dispatches by order.type to the
    // per-type apply_*_order_fill helpers below, plus runs the risk
    // gate, intraday-fill cap, OCA cancellation, and bookkeeping that
    // is common to every fill kind. The caller resolves an incarnation to a
    // current index; admission borrows the book, then dispatch owns a value.
    void apply_filled_order_to_state(size_t order_index,
                                     double fill_price,
                                     bool fill_is_limit,
                                     const Bar& bar,
                                     double& trail_best_path_state,
                                     int& exit_closed_from_bar,
                                     uint64_t& exit_closed_from_incarnation,
                                     bool& exit_closed_was_long,
                                     std::vector<uint64_t>& retired_incarnations,
                                     bool flat_dual_stop_pair = false);
    bool stop_entry_margin_admission_declines(
        const PendingOrder& order, double fill_price, const Bar& bar,
        bool flat_dual_stop_pair = false) const;
    // True iff `order` is a default percent_of_equity <= 100 pure STOP that
    // carries its placement snapshot (PendingOrder::default_stop_placement_qty)
    // and the fill price is a usable positive print: the fill-time admission
    // and dispatch then consume the placement quantity instead of re-sizing
    // at the fill.
    // The pair context exists only inside the ordinary atomic two-stop scan.
    // No callback or stable-frame ABI read occurs between its two fills.
    bool flat_dual_stop_opposite_is_live(
        const PendingOrder& order, bool flat_dual_stop_pair) const;
    bool use_default_stop_placement_qty(
        const PendingOrder& order, double fill_price,
        bool flat_dual_stop_pair = false) const;
    // design-declined-reversal-close-leg: called at the KI-54 reversal-decline
    // site with the just-declined MARKET reversal entry. Flags every pending
    // FULL close that was co-queued after it on the same bar against the held
    // side (see PendingOrder::cancellation), releasing each close claim
    // exactly once.
    void suppress_declined_reversal_close_legs(const PendingOrder& declined_entry);
    // round 8 family R / round 10 family AB: the 10-significant-digit
    // margin-call trigger on a margin-100 LONG (process_margin_call; rule
    // and pins on tv_money_long_margin_call in engine_fills.cpp).
    // The POOC extension is called only before the close-time script or at
    // the specifically scoped positive-slip opening point, normally with no
    // pending broker orders. End-of-bar callers keep it disabled so a
    // close/add cannot make earlier prices act on the post-close position.
    // Opening-only callers retain the actual chart bar for all eligibility
    // checks while restricting valuation to its first path point. A scoped
    // old trailing exit can instead bound valuation strictly before its fill.
    bool tv_money_long_margin_call(const Bar& bar,
                                  bool carried_pooc_pre_close = false,
                                  bool opening_only = false,
                                  double before_exit_path_position =
                                      std::numeric_limits<double>::quiet_NaN());
    bool pooc_trail_money_pre_exit_scope(const Bar& bar,
                                        const PendingOrder& order,
                                        double exit_path_position) const;
    // Positive-slip, single terminal-C MARKET lot covered by the opening
    // money-event controls. Shared by post-entry deferral and next-O dispatch.
    bool pooc_opening_money_scope(const Bar& bar) const;
    // finding-311: mark the live position's standing strategy.exit brackets
    // dormant when an in-position reversal entry is declined at fill.
    void mark_position_brackets_dormant_on_declined_reversal(const Bar& bar);
    // Round 9 family X: the kill is leg-scoped — a dormant bracket's trail
    // leg (trail_points / trail_price) stays live; its stop / limit die. Not
    // on the decline bar itself (dormant_reversal_kill_bar): the flip attempt
    // holds the brackets for the rest of that bar.
    bool dormant_bracket_trail_leg_live(const PendingOrder& o) const;
    // finding-311: a margin-call partial re-registers the surviving
    // position's exit brackets (revive with original prices). When the
    // margin-call event price makes a revived bracket marketable, the whole
    // remaining position closes at that price through the bracket's id.
    void revive_position_brackets_after_margin_call_partial(
        double margin_call_event_price);
    // Round 7 family M mechanism 2a: after the bar's process_margin_call, a
    // re-issued bracket that inherited its predecessor's dormancy and was not
    // revived by a margin-call partial goes live for the next bar (the
    // close-time re-issue takes effect once the bar's broker events are
    // done). Called right after every process_margin_call dispatch site.
    void settle_dormant_bracket_reissues(exit_legs::Domain domain);
    exit_legs::Frame next_leg_event(exit_legs::Phase phase = exit_legs::Phase::Observation);
    exit_legs::Frame preview_next_leg_event(
        exit_legs::Phase phase = exit_legs::Phase::Observation) const;
    void apply_leg_action(PendingOrder& order, exit_legs::Operation operation,
                          std::optional<exit_legs::Frame> cause = std::nullopt);
    exit_legs::Domain current_exit_leg_domain() const;
    enum class ExitLegTransitionResult {
        Applied, Replay, StaleIdentity, BindRefused, ActionRefused, Exhausted,
        RevisionExhausted
    };
    ExitLegTransitionResult transition_exit_leg(
        exit_legs::Lifecycle& legs, uint64_t order_incarnation,
        exit_legs::Operation operation, std::optional<exit_legs::Frame> supplied,
        uint64_t& event_seq, int64_t position_cycle) const;
    std::optional<execution::Status> validate_lifecycle_effects(
        const execution::LifecycleEffects& lifecycle) const;
    std::optional<execution::Status> preflight_settlement_lifecycle(
        const execution::LifecycleEffects& lifecycle,
        bool will_reset_to_flat, bool will_open_quoted);
    void apply_pre_close_lifecycle_batch(const execution::LifecycleBatch& batch);
    void apply_authorized_pending_removals(
        const std::vector<execution::PendingRemoval>& removals);
    std::vector<execution::PendingRemoval> snapshot_exit_pending_removals() const;
    std::optional<execution::LifecycleBatch> select_declined_reversal_pre_close(
        const Bar& bar) const;
    const PendingOrder* find_unique_pending(
        uint64_t incarnation, int64_t created_seq) const;
    PendingOrder* find_unique_pending(uint64_t incarnation, int64_t created_seq);
    // Per-OrderType fill kernels. Called only after risk + intraday
    // gates pass; each updates the engine's position/trade state and
    // any per-type out-parameters the post-fill bookkeeping needs.
    bool replaced_percent_short_market_is_live(const PendingOrder& order) const;
    void apply_market_order_fill(PendingOrder& order, double fill_price,
                                 const Bar& bar,
                                 double& trail_best_path_state,
                                 bool later_same_tick_entry);
    void apply_entry_order_fill(PendingOrder& order, double fill_price,
                                const Bar& bar,
                                double& trail_best_path_state,
                                bool flat_dual_stop_pair = false);
    void apply_exit_order_fill(PendingOrder& order, double fill_price,
                               int& exit_closed_from_bar,
                               uint64_t& exit_closed_from_incarnation,
                               bool& exit_closed_was_long);
    // Freeze the reserved qty of LAYERED strategy.exit legs (a qty_percent<100
    // partial + a sibling default/100% leg) that were armed while the position
    // was FLAT (their entry still pending) and therefore stored qty=NaN. Called
    // when such an entry first opens a position: each leg is bound to a fixed
    // share of the just-opened lot so it no longer over-closes depending on
    // sibling fill order. Mirrors TV binding each bracket leg to a fixed slice
    // of the entry it attaches to. Only acts on multi-leg from_entry groups that
    // contain at least one partial leg; single brackets and pure 100% OCA pairs
    // are left untouched (qty=NaN → full remaining close, as before).
    void reconcile_deferred_layered_exits(
        const std::string& entry_id,
        std::vector<uint64_t>& zero_reservation_incarnations);
    void apply_raw_order_fill(PendingOrder& order, double fill_price,
                              double& trail_best_path_state,
                              int& exit_closed_from_bar,
                              uint64_t& exit_closed_from_incarnation,
                              bool& exit_closed_was_long);
    void materialize_relative_exit_prices_for_live_position();

    // Inner-loop phase split for process_pending_orders.
    // The inner loop iterates `pending_orders_` and processes each via
    // 3 phases: eligibility (should we even consider this order?),
    // fill-price (if eligible, what price would it fill at?), and
    // apply (mutate engine state with the fill — see apply_*_order_fill
    // declarations above).
    enum class OrderEligibility { Proceed, Skip, Remove };
    double pooc_short_exit_trigger_close(const PendingOrder& order,
                                         const Bar& bar) const;
    OrderEligibility classify_order_eligibility(
        PendingOrder& order, int opposing_pass,
        internal::DualEntryStopPathWinner dual_entry_path,
        const std::unordered_set<std::string>& pass0_opposing_skip_ids,
        int exit_closed_from_bar, uint64_t exit_closed_from_incarnation,
        bool exit_closed_was_long, const Bar& bar,
        bool flat_dual_stop_pair = false);
    struct FillEvaluation {
        enum class Kind { Fill, NoFill, DeferredToOpposingPass };
        Kind kind;
        double fill_price;
        // True when the LIMIT leg produced the fill (exit limit, entry
        // limit, or the limit leg of an entry stop-limit) — routes the
        // fill onto the unslipped limit-or-better price path.
        bool is_limit_fill = false;
        // True when the fill came from resolve_exit_path_fill's walk of the
        // intrabar path for an exit-style order (stop, limit, gap-open or
        // TRAIL leg — but not a market / same-bar-close-priced exit). Only
        // such fills carry a chronological path position, which the
        // finding-308 pre-exit margin-call slice requires.
        bool exit_path_fill = false;
        // The fill's position on the bar's 4-waypoint path, in
        // first_touch_position units. Set whenever exit_path_fill is true.
        double exit_path_position = std::numeric_limits<double>::quiet_NaN();
    };
    FillEvaluation evaluate_fill_price(
        PendingOrder& order, size_t order_index, const Bar& bar,
        int opposing_pass, double trail_best_path_state,
        std::unordered_set<std::string>& pass0_opposing_skip_ids);

    // strategy_close / strategy_exit helpers (defined in
    // engine_strategy_commands.cpp).
    // retired_ledger_qty_out: the id_unclosed_qty_[id] balance the default-
    // FIFO branch retired beyond qty_to_close_out (0 on every other branch).
    bool compute_close_target_qty(const std::string& id,
                                  double qty,
                                  double qty_percent,
                                  bool use_script_position_view,
                                  double& matching_qty_out,
                                  double& qty_to_close_out,
                                  bool& all_entries_match_out,
                                  double& retired_ledger_qty_out);
    void cancel_orders_for_full_close(const std::string& id, bool closing_long);
    // Round 7 family M mechanism 2a: a whole-position strategy.close(id)
    // co-queued with a same-bar opposite MARKET entry holds the id's
    // brackets dormant instead of cancelling them (see the definitions).
    bool reversal_pair_close_keeps_brackets(const std::string& id) const;
    void hold_brackets_dormant_for_reversal_pair_close(const std::string& id);
    void cancel_same_bar_market_reentries_after_full_close(
        bool closed_long, bool preserve_undercap_entries);
    // Same-bar default-FIFO close routing. Token 0 uses the accepted global
    // survivor; nonzero compiler tokens use source-callsite scoped orders.
    void enqueue_same_bar_close(const std::string& id,
                                const std::string& comment,
                                uint64_t callsite_token);
    void flush_same_bar_close();
    // retire_ledger_whole: see SameBarCloseCallsite::retire_ledger_whole.
    // Token 0 has no same-bar pending reservation, so it always retires whole.
    void flush_active_same_bar_close(
        double admitted_target = std::numeric_limits<double>::quiet_NaN(),
        double pending_later_qty = 0.0,
        bool defer_first_ledger_consume = false,
        uint64_t callsite_token = 0,
        bool retire_ledger_whole = true);
    double close_reserved_other_qty(const std::string& id) const;
    double callsite_close_reserved_other_qty(
        uint64_t callsite_token, const std::string& id) const;
    double callsite_close_physical_reserved_other_qty(
        uint64_t callsite_token, const std::string& id) const;
    double pending_same_bar_close_target() const;
    void execute_immediate_close(const std::string& id,
                                 const std::string& comment,
                                 double qty_to_close,
                                 double matching_qty,
                                 bool closes_full_position,
                                 bool closes_fifo_qty,
                                 bool closes_any_qty,
                                 bool use_script_position_view,
                                 bool preserve_undercap_entries);
    uint64_t queue_deferred_close_order(
        const std::string& id,
        const std::string& comment,
        double qty_to_close,
        double matching_qty,
        bool closes_full_position,
        bool closes_any_qty,
        double consumed_ledger_qty =
            std::numeric_limits<double>::quiet_NaN(),
        double retired_ledger_qty = 0.0);
    // cleared_leg_count_out: how many live EXIT legs carried this
    // (id, from_entry) before the erase. TV re-issues MODIFY every live leg
    // (each keeping its own entry binding) rather than collapsing them into
    // one, so strategy_exit needs the census to re-arm the same multiplicity.
    bool from_entry_holds_live_lot(const std::string& from_entry) const;
    // replaced_dormant_out / replaced_dormant_stop_out (optional): whether a
    // cleared leg was a dormant bracket (finding-311) and the stop it was
    // last armed with — the re-issue inherits both (round 7 family M
    // mechanism 2a, PendingOrder::dormant_reissue_pending).
    void clear_existing_exit_order(const std::string& id,
                                   const std::string& from_entry,
                                   bool has_trail_request,
                                   double trail_points,
                                   double trail_offset,
                                   double trail_price,
                                   int64_t& preserved_seq_out,
                                   uint64_t& replaced_incarnation_out,
                                   double& preserved_reserved_qty_out,
                                   int& cleared_leg_count_out,
                                   std::optional<exit_legs::Definition>* replaced_definition_out = nullptr);
    bool compute_exit_reserved_qty(const std::string& from_entry,
                                   double preserved_reserved_qty,
                                   double live_pos_qty,
                                   double& qp_io,
                                   bool& is_partial_io,
                                   double& reserved_qty_out);
    void close_reservation_capture_populations(uint64_t admitted_incarnation);

    // execute_market_entry / execute_partial_exit_* helpers (defined in
    // engine_orders.cpp).
    void emit_close_trade(const PyramidEntry& pe, double close_qty,
                          double fill_price, bool was_long);
    void record_close_trade(Trade trade);
    void validate_close_trade_counters(const Trade* rows, size_t count) const;
    execution::Status preflight_source_close_observation(
        const Trade* rows, size_t count, std::optional<int>& loss_day) const;
    void observe_source_close_rows(
        const Trade* rows, size_t count, std::optional<int> loss_day);
    // Quote one resolved execution's current charges. Entry costs on the
    // closed rows are historical allocations. Returns close shares in FIFO
    // order followed by the opening share (zero when there is no opening).
    std::vector<double> quote_execution_commissions(
        const std::vector<double>& closed_units, double opening_units,
        const execution::Fill& fill) const;
    // The arithmetic of emit_close_trade without its bookkeeping: the Trade
    // row a close of ``close_qty`` of ``pe`` at ``fill_price`` on the
    // current bar would record (pnl, pnl_pct, commission, excursions, bar
    // indexes). emit_close_trade builds and commits; the range-end close
    // builds only.
    Trade build_close_trade(const PyramidEntry& pe, double close_qty,
                            double fill_price, bool was_long) const;
    Trade build_close_trade_with_costs(const PyramidEntry& pe, double close_qty,
        double fill_price, bool was_long, double entry_commission,
        double exit_commission,
        const execution::PhysicalExecutionContext& context) const;
    // FIFO-drain up to qty_limit from pyramid_entries_, in order, splitting the
    // boundary entry as needed. When from_entry is non-null only entries whose
    // entry_id == *from_entry are eligible (others are kept untouched); null
    // drains across all entries. Emits one close Trade per drained slice at
    // fill_price (already slippage-adjusted) and rebuilds pyramid_entries_ /
    // decrements position_qty_ by the amount drained. Returns the total qty
    // drained. Shared by execute_partial_exit_qty and both entry-scoped
    // partial-exit helpers.
    double fifo_drain(const std::string* from_entry, double qty_limit,
                      double fill_price, bool was_long);
    void reset_position_state_to_flat();
    // Reset ALL per-run state (trades, accumulators, position, pending orders,
    // equity extremes, risk latches, intraday/day counters, source-series
    // history) so a reused handle's run N is bit-identical to a fresh handle's
    // run 1. Preserves configuration (initial_capital_, pyramiding_, slippage_,
    // commission_*, default_qty_*, syminfo_, inputs_, risk thresholds) — those
    // are set before run() and must survive it. Called at the top of every
    // run() loop entrypoint. See tests/test_handle_reuse_reset.cpp.
    void reset_run_state();
    double account_currency_fx_at(int64_t timestamp_ms) const;
    double active_account_currency_fx() const;
    void settle_position_after_partial_exit(
        PositionReductionCause cause);
    void restore_source_partial_exit_slots(int pre_count, PositionReductionCause cause);
    execution::Result settle_source_opening(
        PositionSide requested, double fill_price, double qty,
        const std::string& id, const std::string& comment, uint64_t incarnation);
    void enter_market_from_flat(const std::string& id, bool is_long,
                                double fill_price, double explicit_qty,
                                int explicit_qty_type,
                                PositionSide created_position_side,
                                bool is_priced_entry, double tv_carry_qty,
                                int created_bar,
                                bool explicit_qty_prequantized,
                                uint64_t entry_incarnation);
    void add_to_pyramid_market(const std::string& id, bool is_long,
                               double fill_price, double explicit_qty,
                               int explicit_qty_type,
                               PositionSide created_position_side,
                               bool is_priced_entry,
                               uint64_t entry_incarnation);
    void add_to_pyramid_market_with_qty_provenance(
        const std::string& id, bool is_long, double fill_price, double explicit_qty,
        int explicit_qty_type, PositionSide created_position_side,
        bool is_priced_entry, bool explicit_qty_prequantized,
        uint64_t entry_incarnation);
    // `fill_price` is already resolved. Source sizing, direction and dust
    // selection stay here; purge_pending_exits is translated into exact
    // pending removals for the settlement coordinator. False does not
    // touch pending_orders_ storage.
    void close_opposite_then_enter(const std::string& id, bool is_long,
                                   double fill_price, double explicit_qty,
                                   int explicit_qty_type,
                                   bool purge_pending_exits,
                                   bool explicit_qty_prequantized,
                                   uint64_t entry_incarnation);
    void apply_resolved_close_opposite_then_enter(
        const std::string& id, bool is_long, double fill_price,
        double explicit_qty, int explicit_qty_type,
        bool explicit_qty_prequantized, uint64_t entry_incarnation,
        execution::LifecycleEffects lifecycle);
    void flip_market_position_to(const std::string& id, bool is_long,
                                 double fill_price, double explicit_qty,
                                 int explicit_qty_type,
                                 bool explicit_qty_prequantized,
                                 bool close_only,
                                 uint64_t entry_incarnation);
    void sequential_same_tick_reversal_fill(const std::string& id, bool is_long,
                                            double fill_price, double explicit_qty,
                                            int explicit_qty_type,
                                            uint64_t entry_incarnation);
    void sequential_same_tick_reversal_fill_with_qty_provenance(
        const std::string& id, bool is_long, double fill_price, double explicit_qty,
        int explicit_qty_type, bool explicit_qty_prequantized,
        uint64_t entry_incarnation);
    double calc_default_qty_from_equity(double fill_price, double equity) const;
    double calc_qty_for_type_from_equity(
        double fill_price, double qty_value, int qty_type, double equity) const;
    double source_reversal_qty(double fill_price, double explicit_qty,
                               int explicit_qty_type, bool prequantized) const;
    void bind_exit_activation(PendingOrder& order);
    void bind_retained_exit_activations();
    void unbind_exit_activations();
    void open_fresh_position(PositionSide requested, double fill_price,
                             double qty, const std::string& id,
                             uint64_t entry_incarnation);
    void consume_tv_carry_from_siblings(const std::string& id,
                                        PositionSide created_position_side,
                                        int created_bar);

    // run() helpers (defined in engine_run.cpp).
    int  count_expected_script_bars(const Bar* input_bars, int n_input,
                                    bool needs_aggregation) const;
    void init_security_eval_states_for_run(const std::string& effective_input_tf);
    // Native HTF feed routing (engine_aux_security.cpp): per-state label maps
    // built after the evaluators' aggregators exist for this run, and the
    // substitution a completed bucket applies. Returns whether `bar` was
    // replaced by its native sibling.
    void prepare_native_security_feeds(const Bar* input_bars, int n_input);
    void prepare_chart_day_partition(const Bar* input_bars, int n_input);
    bool substitute_native_security_bar(SecurityEvalState& state, Bar& bar,
                                        bool count_miss = true);
    void prepare_historical_security_lookahead_projections(
        const Bar* input_bars, int n_input,
        const std::string& effective_input_tf);
    void clear_historical_security_lookahead_projections();
#ifdef PINEFORGE_HAS_AUX_SECURITY_FEED_V1
    bool aux_security_feed_enabled() const { return !aux_security_bars_.empty(); }
    void prepare_aux_security_chart_ranges(const Bar* chart_bars, int n_chart,
                                           const std::string& chart_tf);
    void feed_aux_security_for_chart_bar(int chart_index);
    // The calling chart bar's nominal close on the split-feed path (the
    // value feed_aux_security_for_chart_bar installs as
    // security_calling_close_ms_ while the slice is fed).
    int64_t aux_security_calling_close_ms() const;
    // After dispatch_bar: feed the auxiliary bars a first-bucket-latched
    // evaluator (calling_open_latches_first) held back from this chart
    // bar's slice, in feed order, with the same next-input / calling-close
    // context the slice loop would have given them.
    void feed_deferred_aux_security_for_chart_bar(int chart_index);
    void clear_aux_security_chart_ranges();

    // Neutral capability bridge for independent factorial patches. The
    // two-argument feed exists in the base engine. A completion-aware factor
    // may add a third bool argument; dependent-expression overload selection
    // forwards the native chart completion only when that capability exists.
    // Neither factor names or requires the other's feature macro.
    template <typename EngineT>
    static auto feed_security_at_calling_bar_boundary_impl(
            EngineT* engine, SecurityEvalState& state, const Bar& bar,
            bool calling_bar_complete, int)
        -> decltype(engine->feed_security_eval_state(
                        state, bar, calling_bar_complete), void()) {
        engine->feed_security_eval_state(state, bar, calling_bar_complete);
    }

    template <typename EngineT>
    static void feed_security_at_calling_bar_boundary_impl(
            EngineT* engine, SecurityEvalState& state, const Bar& bar,
            bool, long) {
        engine->feed_security_eval_state(state, bar);
    }

    void feed_security_at_calling_bar_boundary(
            SecurityEvalState& state, const Bar& bar,
            bool calling_bar_complete) {
        feed_security_at_calling_bar_boundary_impl(
            this, state, bar, calling_bar_complete, 0);
    }

#endif
    // Runs the standard per-script-bar order/strategy sequence on current_bar_:
    //   process_pending_orders -> update_per_trade_extremes -> on_bar,
    // plus a second process_pending_orders when process_orders_on_close_ is set
    // (TV process_orders_on_close: new market orders fill at this bar's close).
    // Shared by run(), run_simple_bar_loop, and the no-magnifier aggregation
    // path. The magnifier tick loop does NOT use this — it gates the sequence
    // on is_last_tick_ and forces is_first_tick_ before on_bar.
    OrderBirth capture_order_birth() const;
    void invoke_chart_on_bar(const Bar& bar);
    void dispatch_bar();
    void dispatch_bar_calc_on_order_fills();
    void snapshot_coof_script_state();
    void restore_coof_script_state();
    void commit_coof_script_state();
    uint64_t execute_coof_script_body(const Bar& script_bar,
                                      double broker_cursor_price,
                                      bool cursor_is_bar_point,
                                      const OrderBirth& evaluation_origin,
                                      uint64_t direct_fill_event_budget,
                                      bool opening_money_prefix = false);
    uint64_t run_coof_recalc_chain(const Bar& script_bar,
                                   double broker_cursor_price,
                                   bool cursor_is_bar_point,
                                   BirthCursor cursor,
                                   uint64_t& evaluation_ordinal,
                                   uint64_t triggering_events,
                                   uint64_t max_events,
                                   uint64_t events_already,
                                   bool grouped_stop_recalc = false,
                                   uint64_t market_entry_incarnation = 0,
                                   bool opening_money_prefix = false);
    void run_simple_bar_loop(const Bar* input_bars, int n_input);
    void run_aggregation_bar_loop(const Bar* input_bars, int n_input,
                                  bool bar_magnifier, int expected_script_bars);
    // Live-runtime tail (spec §3.1): once script_tf_seconds_ is known for
    // this run, freeze pine_last_bar_index()/last_bar_time_ at the horizon
    // bar instead of the fed array's actual last index. No-op unless
    // realtime_tail_ is on and realtime_tail_horizon_bars_ > 0.
    //
    // script_bar_geometry selects which timestamp rule applies to
    // last_bar_time_ (last_bar_index_ = horizon - 1 either way):
    //   true  -- `bars` IS the script-bar array (the single-TF run(bars, n)
    //            path, and run_tf_impl's !needs_aggregation call, where
    //            input_tf == script_tf so input bars ARE script bars):
    //            exact bars[horizon - 1].timestamp when horizon <= n, else
    //            extrapolated from bars[n - 1] one script-TF step per
    //            missing bar past the array's last bar.
    //   false -- `bars` is the *input* array under aggregation
    //            (needs_aggregation, input_tf < script_tf): indexing it by
    //            a script-bar horizon would land on the wrong input bar
    //            (final-rereview.md N1), so instead extrapolate from the
    //            first input bar's timestamp, one script-TF step per
    //            horizon bar (the pre-fix formula, restored for this path
    //            only).
    void apply_realtime_tail_horizon(const Bar* bars, int n,
                                      bool script_bar_geometry);
    // The TF-aware run()'s actual work (dispatch loop selection, the
    // try/catch, both cleanup paths). Does NOT touch last_error_,
    // last_run_status_, or abort_requested_ -- every public run() overload
    // clears those exactly once at its own entry before reaching here, so a
    // request_abort() arriving during a delegating overload's own setup
    // (e.g. the SymInfo/overrides overload's syminfo/inputs copy) is never
    // silently wiped by a second, later clear.
    // The caller has already validated the complete chart bar array; do not
    // rescan here or clear an abort that arrived during preflight/setup.
    void run_tf_impl(const Bar* input_bars, int n_input,
                     const std::string& input_tf,
                     const std::string& script_tf,
                     bool bar_magnifier,
                     int magnifier_samples,
                     MagnifierDistribution magnifier_dist);
    void stream_observe_entry(const PyramidEntry& pe);
    void stream_observe_exit(size_t trade_index);
    void stream_refresh_action_metadata(size_t first_action, size_t first_trade);
    bool stream_finalize_until(int64_t timestamp_ms);
    void stream_feed_input_bar(const Bar& bar, bool had_tick);
    void stream_dispatch_script_bar(const Bar& bar, bool had_tick);

    // fill_report helpers (defined in engine_report.cpp).
    void fill_trades_section(ReportC* out) const;
    void fill_metrics_section(ReportC* out) const;
    void fill_security_diag_section(ReportC* out) const;
    void fill_trace_section(ReportC* out) const;

    void guard_native_mutation(const char* operation);
    void legacy_run_simple(const Bar* bars, int n);
    void legacy_run_tf(const Bar* input_bars, int n_input,
                       const std::string& input_tf,
                       const std::string& script_tf,
                       bool bar_magnifier,
                       int magnifier_samples,
                       MagnifierDistribution magnifier_dist);
    void legacy_run_rich(const Bar* input_bars, int n_input,
                         const std::string& input_tf,
                         const std::string& script_tf,
                         const std::unordered_map<std::string, std::string>& inputs,
                         const SymInfo& syminfo,
                         const StrategyOverrides* overrides,
                         bool bar_magnifier,
                         int magnifier_samples,
                         MagnifierDistribution magnifier_dist);
    bool legacy_stream_begin(const Bar* warmup_bars, int n_warmup,
                             const std::string& input_tf,
                             const std::string& script_tf);
    bool legacy_stream_push_bar(const Bar& bar);
    bool legacy_stream_push_tick(const TradeTick& tick);
    bool legacy_stream_push_ticks(const TradeTick* ticks, int n);
    bool legacy_stream_advance_time(int64_t timestamp_ms);
    bool legacy_stream_end(bool finalize_partial_input_bar);

    struct ExecutionConsumerSlot {
        bool native = false;
        mutable std::unique_ptr<IExecutionConsumer> ptr;
        ExecutionConsumerSlot() = default;
        ExecutionConsumerSlot(const ExecutionConsumerSlot& other) noexcept
            : native(other.native) {}
        ExecutionConsumerSlot& operator=(const ExecutionConsumerSlot& other) noexcept {
            if (this != &other) {
                native = other.native;
                ptr.reset();
            }
            return *this;
        }
        ExecutionConsumerSlot(ExecutionConsumerSlot&& other) noexcept : native(other.native) {
            other.ptr.reset();
        }
        ExecutionConsumerSlot& operator=(ExecutionConsumerSlot&& other) noexcept {
            if (this != &other) {
                native = other.native;
                ptr.reset();
                other.ptr.reset();
            }
            return *this;
        }
    };
    ExecutionConsumerSlot execution_consumer_slot_;

public:
    explicit BacktestEngine(compat::pine::CapAttachment cap_attachment =
                                compat::pine::CapAttachment::None);
    // Explicit frontend selection, not a generic native risk switch. This
    // preserves any prior declaration values and does not reset quota/state.
    void enable_pine_intraday_cap() {
        guard_native_mutation("enable_pine_intraday_cap");
        max_intraday_filled_orders_.attach();
    }
    // Current execution-adapter scope: intraday cap + retained-parent priority.
    // Idempotent configuration attachment, not a reset or universal Pine mode.
    // Generated constructors call this before any host metadata is forwarded.
    void attach_pine_execution_adapter() {
        guard_native_mutation("attach_pine_execution_adapter");
        max_intraday_filled_orders_.attach();
        pine_order_priority_.attach();
    }
    virtual ~BacktestEngine();
    int execution_contract() const;
    bool native_bound() const;
    virtual void on_bar(const Bar& bar) = 0;

    // All run() overloads preflight the entire chart array before modifying
    // configuration, resetting state, preparing scripts or dispatching bars.
    // Require n >= 0, a non-null pointer when n > 0, finite enclosed OHLC,
    // volume that is finite >= 0 or NaN (unavailable), and strictly increasing
    // timestamps with representable positive int64 deltas. Finite signed/zero
    // prices, off-grid prices and gaps are structurally admitted, without a
    // guarantee about their financial or extreme-calendar arithmetic.
    // Rejection sets last_error() and preserves state except entry-time error,
    // run-status and abort bookkeeping. n == 0 retains empty-new-run semantics.
    // Processing exceptions after preflight do not imply state rollback.
    void run(const Bar* bars, int n);

    void run(const Bar* input_bars, int n_input,
             const std::string& input_tf,
             const std::string& script_tf,
             bool bar_magnifier = false,
             int magnifier_samples = 4,
             MagnifierDistribution magnifier_dist = MagnifierDistribution::ENDPOINTS);

#ifdef PINEFORGE_HAS_AUX_SECURITY_FEED_V1
    // Copies a finer request.security-only feed for subsequent historical
    // runs. n == 0 clears it. Validation that depends on native chart bars is
    // intentionally deferred to run(), where failures reach last_error().
    bool set_aux_security_feed(const Bar* bars, int n,
                               const std::string& input_tf);
#endif

    // Copies the exchange's own bars of one higher timeframe for the
    // request.security evaluators that request exactly it (see
    // strategy_set_native_security_feed in pineforge.h). n == 0 clears that
    // timeframe's feed. Routing is built per run once the evaluators exist.
    bool set_native_security_feed(const std::string& timeframe,
                                  const Bar* bars, int n);
    bool native_security_feed_enabled() const {
        return !native_security_feeds_.empty();
    }
    // Per-run diagnostics: completed buckets that took a native bar, and
    // completed buckets of a fed timeframe that found none (kept aggregate).
    int64_t native_security_substitutions() const {
        return diag_native_security_substitutions_;
    }
    int64_t native_security_misses() const {
        return diag_native_security_misses_;
    }
    // Whether the last run built the chart symbol's native daily partition
    // (an intraday chart with a native "D" feed installed).
    bool chart_day_partition_installed() const {
        return !chart_day_partition_.empty();
    }

    // Execute confirmed historical bars, then keep this exact instance alive
    // for realtime trade updates. The warmup feed must contain at least one
    // complete input-timeframe bar. Normalized ticks begin at or after the next
    // input bar's open; in-session gaps are materialized as zero-volume
    // carry-forward bars when a later tick or stream_advance_time() crosses
    // their close boundary. Configured out-of-session intervals are skipped.
    bool stream_begin(const Bar* warmup_bars, int n_warmup,
                      const std::string& input_tf,
                      const std::string& script_tf = "");
    // Confirmed input bars use the same OHLC broker kernel as batch. The first
    // tick/bar locks the input mode; mixing them is rejected. Missing in-session
    // bars are rejected rather than padded. Closed-session gaps may be skipped.
    bool stream_push_bar(const Bar& bar);
    bool stream_push_tick(const TradeTick& tick);
    bool stream_push_ticks(const TradeTick* ticks, int n);
    bool stream_advance_time(int64_t timestamp_ms);
    bool stream_end(bool finalize_partial_input_bar = false);
    bool stream_is_realtime() const { return stream_phase_ == StreamPhase::REALTIME; }
    int stream_order_actions_len() const { return static_cast<int>(stream_order_actions_.size()); }
    const StreamOrderAction& stream_order_action_at(int i) const {
        return stream_order_actions_.at(static_cast<size_t>(i));
    }
    void stream_order_actions_clear() { stream_order_actions_.clear(); }
    // Observable broker + stream cursors/forming bars, not a serialization of
    // arbitrary strategy members. Deterministic strategy code is required.
    uint64_t stream_state_hash() const;

    // Install an effective-time FX curve (account-currency units per one unit
    // of symbol quote currency). Points are copied and must have strictly
    // increasing epoch-ms timestamps plus positive finite rates. The latest
    // point whose timestamp is <= the current broker event is active. Passing
    // n=0 clears the curve and restores the scalar metadata fallback.
    bool set_account_currency_fx_series(const int64_t* timestamps_ms,
                                        const double* rates, int n);

    void run(const Bar* input_bars, int n_input,
             const std::string& input_tf,
             const std::string& script_tf,
             const std::unordered_map<std::string, std::string>& inputs,
             const SymInfo& syminfo,
             const StrategyOverrides* overrides = nullptr,
             bool bar_magnifier = false,
             int magnifier_samples = 4,
             MagnifierDistribution magnifier_dist = MagnifierDistribution::ENDPOINTS);

    int trade_count() const { return (int)trades_.size(); }
    const Trade& get_trade(int i) const { return trades_[i]; }
    // The REPORT's row space: trades_ followed by range_end_trades_, in the
    // order fill_trades_section lays pf_report_t::trades out. trade_count()
    // / get_trade() stay the Pine-visible closed trades (strategy.closedtrades
    // never sees a range-end row); the report-indexed C ABI accessors
    // (strategy_closed_trade_entry_incarnation) must index THIS space, or
    // every range-end row reads as index-out-of-range (round-4b F3).
    int report_trade_count() const {
        return (int)(trades_.size() + range_end_trades_.size());
    }
    const Trade& get_report_trade(int i) const {
        const int n_closed = (int)trades_.size();
        return i < n_closed ? trades_[(size_t)i]
                            : range_end_trades_[(size_t)(i - n_closed)];
    }

    // ABI v4 live-runtime surface (task 9): classify why a REPORT-row
    // closed trade exited -- report-row scope (spans trades_ then
    // range_end_trades_, like get_report_trade above), so this cannot reuse
    // the existing protected closed_trade_* names below (strategy.
    // closedtrades.* scope: trades_ only, std::string returns). 0 UNKNOWN
    // (bad index), 1 SCRIPT, 2 BRACKET, 3 MARGIN_CALL, 4 INTRADAY_LOSS_CAP,
    // 5 INTRADAY_FILL_CAP, 6 RANGE_END. Defined in engine_trade_accessors.cpp;
    // see strategy_closed_trade_close_cause (pineforge.h) for the exact
    // derivation order.
    int closed_trade_close_cause(int i) const;

    // --- Position-size extremes (strategy.max_contracts_held_*) ---
    double max_contracts_held_all() const { return max_contracts_held_all_; }
    double max_contracts_held_long() const { return max_contracts_held_long_; }
    double max_contracts_held_short() const { return max_contracts_held_short_; }

    // --- Even-trade count (strategy.eventrades) ---
    int eventrades() const { return eventrades_count_; }

    void fill_report(ReportC* out) const;
    static void free_report(ReportC* report);

    // Returns the error message captured by the most recent run() if it
    // failed, or an empty string if the run completed normally. Cleared at
    // the start of every run(). The C ABI exposes this via
    // pf_strategy_get_last_error().
    const std::string& last_error() const { return last_error_; }

    // Per-input override (title -> serialized value). Must be set before run()
    // so get_input_*() lookups pick up the TV-tester value rather than the
    // Pine default.
    void set_input(const std::string& key, const std::string& value) {
        guard_native_mutation("set_input");
        inputs_[key] = value;
    }
    void clear_inputs() {
        guard_native_mutation("clear_inputs");
        inputs_.clear();
    }
    void set_trade_start_time(int64_t timestamp_ms) {
        guard_native_mutation("set_trade_start_time");
        trade_start_time_ = timestamp_ms;
    }

    // Set the chart's display timezone. Stored in a dedicated slot so it
    // does NOT clobber ``syminfo_.timezone`` (the symbol/exchange TZ).
    //
    // Pre-fix this method wrote the chart TZ into ``syminfo_.timezone``,
    // which the codegen reads as the default tz argument of the 1-arg
    // ``hour(time)`` / ``minute(time)`` / ``dayofweek(time)`` form. That
    // conflated two distinct TV concepts and silently shifted the result
    // by the chart-vs-exchange offset (e.g. Asia/Taipei vs UTC = +8h)
    // for crypto symbols. The shift cascaded into ``hour``-bucketed
    // accumulators — see
    // ``validation_typed_matrix/typed-matrix-probe-01-bool-regime-mask``,
    // whose 24x7 ``matrix<bool>`` regime mask filled in 8 hours earlier
    // than TV and produced ~9% trade-count divergence (TV 773, engine 714
    // before this fix; ~778 after).
    //
    // TV semantics (Pine v6 reference docs):
    //   * Bare variable ``hour`` / ``minute`` / ``dayofweek``: exchange
    //     timezone (``syminfo.timezone``). Already correct via
    //     ``_decompose_bar_time()``'s hardcoded ``gmtime_r``, which
    //     matches the corpus' ETH-USDT (UTC) data.
    //   * 1-arg function form ``hour(time)``: defaults its tz arg to
    //     ``syminfo.timezone`` (NOT the chart display TZ). With this
    //     change, ``syminfo_.timezone`` retains its constructor default
    //     ("UTC") and the codegen lambda lands on the cheap gmtime_r
    //     branch — matching TV.
    //   * 2-arg function form ``hour(time, tz)``: honours the explicit
    //     argument, unchanged by this fix.
    void set_chart_timezone(const std::string& tz) {
        guard_native_mutation("set_chart_timezone");
        chart_timezone_ = tz;
    }
    const std::string& chart_timezone() const { return chart_timezone_; }

    // --- Symbol metadata injection (data feed → syminfo.*) ---
    // The exchange timezone + session feed session.ismarket / time(session)
    // predicates. They default to UTC / 24x7 (crypto); a data feed pushes
    // the real values via these setters before run().
    //
    // max_intraday_filled_orders consumes a valid explicit session and this
    // timezone through compat::pine::IntradayCap::risk_day(). Other risk-day rules keep
    // chart_timezone_, as do continuous/unconfigured order-counter clocks;
    // the existing crypto-on-shifted-chart contract therefore remains intact.
    void set_syminfo_timezone(const std::string& tz) {
        guard_native_mutation("set_syminfo_timezone");
        syminfo_.timezone = tz;
    }
    void set_syminfo_session(const std::string& s) {
        guard_native_mutation("set_syminfo_session");
        syminfo_.session = s;
    }
    // ``syminfo.type`` ("crypto" default; "forex" / "stock" / "futures" /
    // "index" / "fund" / "cfd" per TradingView). Scripts branch on it for
    // instrument conventions — the canonical one being the pip size
    // (``syminfo.type == "forex" ? 0.0001 : syminfo.mintick``), which on a
    // 5-digit FX symbol under the crypto default computed every pip-scaled
    // stop/target 10x too tight (finding 454). Empty is ignored.
    void set_syminfo_type(const std::string& t) {
        guard_native_mutation("set_syminfo_type");
        if (!t.empty()) syminfo_.type = t;
    }
    /// Whether TradingView's session template for this symbol carries the
    /// exchange's early closes and holidays, so a D/W/M request.security
    /// bucket completes on a shortened session's actual last chart bar
    /// (TimeframeAggregator::set_early_close_completes): exchange-listed
    /// kinds (stock, futures, index, fund, dr, ...) yes -- NYSE:F's 12:45 ET
    /// half-day bar and CME's 11:45 CT early-close bar are pinned; the OTC
    /// quote streams -- forex, cfd, crypto -- no: their period ends at the
    /// nominal close and a session ending early completes lazily on the
    /// next period's first bar (OANDA:XAUUSD 15m, lab tv oanda pin, ledger
    /// log-20260905t034240z-30be11fe). syminfo.type comes from the harness
    /// (strategy_set_syminfo_type <- PINEFORGE_VERIFY_SYMTYPE); the
    /// constructor default "crypto" keeps an untyped run on the lazy rule.
    bool session_template_knows_early_close() const;
    // Generic string-field injection for the remaining OHLCV-less syminfo
    // members (ticker / tickerid / currency / basecurrency / description /
    // volumetype / type). Unknown keys and empty values are ignored; returns
    // true when a field was set.
    bool set_syminfo_string(const std::string& key, const std::string& value) {
        guard_native_mutation("set_syminfo_string");
        if (value.empty()) return false;
        if (key == "type") { syminfo_.type = value; return true; }
        if (key == "ticker") { syminfo_.ticker = value; return true; }
        if (key == "tickerid") { syminfo_.tickerid = value; return true; }
        if (key == "currency") { syminfo_.currency = value; return true; }
        if (key == "basecurrency") { syminfo_.basecurrency = value; return true; }
        if (key == "description") { syminfo_.description = value; return true; }
        if (key == "volumetype") { syminfo_.volumetype = value; return true; }
        return false;
    }
    // Runtime syminfo injection (by design — the engine stores no instrument
    // metadata of its own; the harness supplies it per run). mintick drives the
    // directional fill snap + slippage*tick economics; pointvalue is the
    // futures $-per-point multiplier applied to every money path (realized
    // PnL + excursions, open profit / equity, percent/cash sizing, percent
    // commission notionals, margin check — see tests/test_pointvalue.cpp).
    // Both default to crypto/equity values (0.01 / 1.0) and only matter when the
    // harness sets a non-default instrument.
    void set_syminfo_mintick(double m) {
        guard_native_mutation("set_syminfo_mintick");
        if (m > 0.0) { syminfo_.mintick = m; syminfo_mintick_ = m; }
    }
    void set_syminfo_pointvalue(double pv) {
        guard_native_mutation("set_syminfo_pointvalue");
        if (pv > 0.0) { syminfo_.pointvalue = pv; }
    }

    // Toggle TradingView's forced-liquidation (margin call) emulation. Defaults
    // ON to match TV; set false for the legacy hold-the-position behaviour.
    void set_margin_call_enabled(bool enabled) {
        guard_native_mutation("set_margin_call_enabled");
        margin_call_enabled_ = enabled;
    }
    bool margin_call_enabled() const { return margin_call_enabled_; }
    void set_syminfo_metadata(const std::string& key, double value) {
        guard_native_mutation("set_syminfo_metadata");
        syminfo_metadata_[key] = value;
        // Pine's public bar_index is chart-history relative. Validation feeds
        // can start after TradingView's hidden first chart bar, while engine
        // internals still need zero-based array indices for TA precalc and
        // broker bookkeeping. This metadata key shifts only codegen-emitted
        // Pine bar_index reads via pine_bar_index()/pine_last_bar_index().
        if (key == "bar_index_offset") {
            bar_index_offset_ = std::isfinite(value)
                ? static_cast<int>(std::llround(value))
                : 0;
        }
        // Opt-in KI-55 HTF warmup parity. The value is the TV deep-backtest
        // range start in epoch-ms (exactly representable as a double for any
        // realistic date — 2025 is ~1.7e12 << 2^53). A positive, finite value
        // enables it; anything else (0 / NaN / negative) is the disabled
        // default, so a run that never sets this key is byte-identical.
        if (key == "security_range_start_na_warmup") {
            if (std::isfinite(value) && value > 0.0) {
                security_range_start_na_warmup_ = true;
                security_range_start_ms_ =
                    static_cast<int64_t>(std::llround(value));
            } else {
                security_range_start_na_warmup_ = false;
                security_range_start_ms_ = 0;
            }
        }
        // Opt-in KI-55 chart-timeframe EMA warmup parity. This is a boolean
        // run configuration carried through the existing metadata channel:
        // positive finite values enable it; 0 / NaN / negative disable it.
        // Unlike security_range_start_na_warmup, it carries no timestamp and
        // does not change request.security aggregation boundaries.
        if (key == "chart_ema_na_warmup") {
            chart_ema_na_warmup_ = std::isfinite(value) && value > 0.0;
        }
        // Historical batch-only lookahead projection. This is intentionally a
        // default-off verifier candidate: regular execution and every stream
        // path keep progressive HTF aggregation unless a caller explicitly
        // supplies a positive finite metadata value.
        if (key == "historical_security_lookahead_projection") {
            historical_security_lookahead_projection_ =
                std::isfinite(value) && value > 0.0;
        }
        // Default-off verifier candidate for a finite-price margin call whose
        // lot-quantized restore quantity is zero.  Positive finite values close
        // the residual; absent/zero/non-finite values preserve the established
        // one-step progress fallback.
        if (key == "margin_zero_cover_full_liquidation") {
            margin_zero_cover_full_liquidation_ =
                std::isfinite(value) && value > 0.0;
        }
        pine_order_priority_.metadata(key, value);
        // Forward through the real base setter used by the C ABI. A selected
        // frontend owns recognition and numeric validation; no derived shadow
        // setter or cap-key interpretation belongs in this transport.
        max_intraday_filled_orders_.metadata(key, value);
        // "qty_step" is the per-instrument lot increment used by the forced-
        // liquidation quantizer. Route it onto the dedicated member so the
        // codegen run(const Bar*, int) path (which never overwrites it) keeps
        // the value the data feed injected. A non-positive value disables it.
        if (key == "qty_step") {
            qty_step_ = (std::isfinite(value) && value > 0.0) ? value : 0.0;
            syminfo_.qty_step = qty_step_;
        }
        // Account-currency FX rate (account-currency units per quote-currency
        // unit). Scales the broker affordability gate's required_margin when
        // the script's currency differs from the symbol quote currency. A
        // non-positive / non-finite value resets to the 1.0 (no-op) default.
        if (key == "account_currency_fx") {
            account_currency_fx_ =
                (std::isfinite(value) && value > 0.0) ? value : 1.0;
        }
        // Per-instrument margin/leverage DEFAULT (percent of position value
        // required as collateral; 100 = fully collateralized / no leverage,
        // matching Pine's own margin_long/margin_short default). This is a
        // data-feed-level fallback for a script whose header OMITS
        // margin_long/margin_short — without it, a leveraged futures/
        // perpetual instrument has no way to reflect its real (non-100%)
        // exchange margin requirement (see the tv-margin-call-gap project
        // history). It must NOT override an EXPLICIT strategy(...,
        // margin_long=X) header arg. Unlike qty_step/account_currency_fx,
        // this can't rely on "whichever assignment runs last wins": the
        // codegen-generated constructor assigns margin_long_/margin_short_
        // from an explicit header arg in strategy_create(), which the C ABI
        // / run_strategy.py call BEFORE strategy_set_syminfo_metadata — so a
        // later injected default would silently clobber an explicit script
        // value. Guard on "still at the class's own 100.0 default", i.e.
        // apply only when the header did NOT already set it (the one
        // imprecise edge case — a header that explicitly writes
        // margin_long=100, matching the default value — is indistinguishable
        // from "unset" here, but 100 is also the semantic no-override value,
        // so this is a no-op in that case either way).
        if (key == "margin_long" && margin_long_ == 100.0) {
            margin_long_ = (std::isfinite(value) && value > 0.0) ? value : 100.0;
        }
        if (key == "margin_short" && margin_short_ == 100.0) {
            margin_short_ = (std::isfinite(value) && value > 0.0) ? value : 100.0;
        }
    }

    // Returns the script's active timeframe string (e.g. "15" for 15-minute,
    // "D" for daily). Backs timeframe.main_period in generated Pine v6 code.
    const std::string& main_period() const { return script_tf_; }
    int pine_bar_index() const { return bar_index_ + bar_index_offset_; }
    int pine_last_bar_index() const { return last_bar_index_ + bar_index_offset_; }

    // Live-runtime tail semantics (spec §3.1, ABI v4): the caller's fed array
    // ends with a still-forming bar rather than the chart's rightmost
    // historical bar. When `on`, the LAST bar of every subsequent run() (this
    // is persistent configuration, not a one-shot flag -- it stays set until
    // a caller passes on=false, and reset_run_state() does not touch it)
    // gets barstate.islast == false, session.islastbar computed from the
    // bucket calendar (no i+1 bar to peek at), pine_last_bar_index() /
    // last_bar_time_ frozen at the horizon bar (`horizon_bars - 1`), and no
    // range-end close row/trade. Default off: every historical run is
    // byte-identical to before this flag existed.
    void set_realtime_tail(bool on, int horizon_bars) {
        guard_native_mutation("set_realtime_tail");
        realtime_tail_ = on;
        realtime_tail_horizon_bars_ = horizon_bars;
    }
    bool realtime_tail() const { return realtime_tail_; }

    // Live probe tail suppression (spec §3.2, ABI v4): when `on`, the LAST
    // bar of every subsequent run() runs only dispatch_bar()'s pre-on_bar
    // broker steps (intraday-cap deferred close, _push_source_series,
    // process_pending_orders, evaluate_max_intraday_loss_over_path,
    // update_per_trade_extremes) and returns — on_bar is never invoked for
    // that bar, and nothing after it runs (no flush_same_bar_close, no POOC
    // second pass, no process_margin_call, no settle_dormant_bracket_
    // reissues, no sizing refresh). Margin-call / intraday-cap closes
    // therefore surface only at settlement (the next non-suppressed run),
    // not against the still-forming probe bar. This is persistent
    // configuration, like set_realtime_tail, and independent of it — do not
    // couple the two flags.
    // Honoured only on the standard dispatch_bar path (single-TF run loop,
    // run_simple_bar_loop). Silent no-op under calc_on_order_fills (COOF
    // scheduler) and under the bar magnifier (run_magnified_bar) -- both
    // gated in live v1. Semantics UNDEFINED on the non-magnifier aggregation
    // path (input_tf < script_tf) until the partial-bucket forming-bar flag
    // lands; see pineforge.h.
    // Default off (@p on == 0): every historical run stays byte-identical to
    // before this flag existed.
    void set_probe_suppress_tail_logic(bool on) {
        guard_native_mutation("set_probe_suppress_tail_logic");
        probe_suppress_tail_logic_ = on;
    }
    bool probe_suppress_tail_logic() const { return probe_suppress_tail_logic_; }

    // Force this run's intrabar path order (ABI v4 live-runtime surface,
    // task 4): 0 AUTO (the unchanged |H-O| vs |O-L| rule), 1 HIGH_FIRST
    // (O -> H -> L -> C), 2 LOW_FIRST (O -> L -> H -> C). Any other value is
    // clamped to AUTO. A live probe runs the SAME forming bar under both
    // forced orders and keeps only the fills that agree between the two --
    // a fill that depends on which leg TradingView's own still-forming bar
    // will resolve to is path-dependent and must be suppressed rather than
    // guessed. See internal::bar_path_uses_high_first's thread-local
    // override (engine_path_resolve.cpp) and the PathOrderScope guard in
    // engine_run.cpp that installs/clears it for exactly the duration of
    // this run's own dispatch.
    // Persistent configuration, like set_realtime_tail -- stays set until a
    // caller passes mode=0. Applies to run() only: a stream continued via
    // strategy_stream_begin dispatches its realtime ticks outside any
    // PathOrderScope and always sees AUTO, regardless of this setting.
    // Default AUTO (mode=0): every historical run stays byte-identical to
    // before this flag existed.
    void set_path_order(int mode) {
        guard_native_mutation("set_path_order");
        path_order_mode_ = (mode == 1 || mode == 2) ? mode : 0;
    }

    // The dual-entry-stop arbitration decided on the LAST bar this run
    // dispatched (a flat position resting one long stop-only ENTRY and one
    // short stop-only ENTRY, both touched that bar --
    // dual_entry_stop_path_winner, engine_path_resolve.cpp): 0 None (no
    // such pair was arbitrated on that bar), 1 LongFirst, 2 ShortFirst --
    // internal::DualEntryStopPathWinner's own enumerator order (its Tie
    // value never reaches here; dual_entry_stop_path_winner always resolves
    // a tie to LongFirst). This reads last_bar_dual_entry_decision_, a
    // per-bar snapshot of the arbitration that survives whatever the
    // working state (dual_entry_path_) does afterward this same bar -- a
    // fill, a declined stop-entry admission, or (under
    // process_orders_on_close) the bar's second process_pending_orders
    // pass, all of which reset dual_entry_path_ to None without undoing the
    // fact that an arbitration happened. Only the standard
    // (non-calc_on_order_fills) dispatch path updates it; this is a silent
    // no-op (stays at its last standard-path value) under the COOF
    // scheduler, mirroring set_probe_suppress_tail_logic's
    // dispatch-path-scope caveat.
    int last_bar_dual_entry_path() const {
        return static_cast<int>(last_bar_dual_entry_decision_);
    }

    // Live runtime G1 (spec §3.4): a deterministic, order-independent
    // FNV-1a 64 hash over every piece of broker state that decides the next
    // bar's fills (position, book, pyramid lots, trail scalars, cycle/
    // intraday/risk latches, frozen sizing, equity sums). Two engines with
    // equal broker state hash equally regardless of unordered-container
    // insertion history; any difference in that state changes the hash.
    // Implemented in engine_state_hash.cpp; coverage of the marked
    // broker-state region(s) below (grep this file for "broker-state") is
    // enforced by scripts/check_broker_state_hash_coverage.py.
    uint64_t broker_state_hash() const;

    // ABI v4 live-runtime surface (task 7, spec 3.6): read-only view of the
    // resting-order book after the most recent run() -- the book in force
    // for the next bar, in the vector's own (insertion) order; fill
    // priority is decided at fill time from created_seq. The C ABI
    // (strategy_pending_orders_len / strategy_pending_order_get) copies
    // each order out through the generated POD mirror
    // (pf_pending_order_v1_t, include/pineforge/pending_order_mirror.hpp),
    // never by pointer. `i` must be in [0, pending_order_count()).
    int pending_order_count() const { return static_cast<int>(pending_orders_.size()); }
    const MarketAdmissionJournal& market_admission_journal() const {
        return market_admission_journal_;
    }
    std::vector<admission::Field> market_admission_fields() const;
    const PendingOrder& pending_order_at(int i) const {
        return pending_orders_[static_cast<size_t>(i)];
    }

    // ABI v4 live-runtime surface (task 8, spec 3.6): engine-computed
    // derived values of a resting order and the position scalars the live
    // runtime would otherwise have to re-derive. Pure const reads of the
    // engine's own sizing / admission / level-resolution predicates; none
    // of them mutates the engine, so a historical run is byte-identical
    // whether or not a caller reads them. Implemented in engine_fills.cpp
    // next to use_default_stop_placement_qty, the rules they mirror.
    //
    // probe_fill_qty: the quantity the entry kernel would open if the
    // order at `index` filled at `fill_price`, and which sizing partition
    // produced it -- exactly the "quantity the market / priced-entry kernel
    // would actually open with" computation of the zero-lot decline gate in
    // apply_filled_order_to_state, tagged:
    //   0 EXPLICIT               a script-supplied qty: for strategy.entry
    //                            calc_qty_for_type at the slipped fill
    //                            (apply_qty_step of the contracts for FIXED,
    //                            the budget sized at the fill for a per-call
    //                            percent/cash override); a strategy.order
    //                            explicit qty is dispatched VERBATIM
    //                            (apply_raw_order_fill, no lot step).
    //   1 FROZEN_PLACEMENT       a quantity the engine fixed before the fill,
    //                            never re-derived from the fill price:
    //                            frozen_default_qty (the default
    //                            percent_of_equity / cash MARKET or
    //                            strategy.order size at the signal close), a
    //                            MARKET's frozen broker transaction
    //                            (paired_flat_market_transaction_qty; a
    //                            same-bar-market transaction's frozen total from
    //                            FLAT or as a kept over-cap add), or what one
    //                            of the two MARKET reversal kernels opens:
    //                            a same-bar-market member against an
    //                            opposite live position opens the remainder
    //                            transaction_units - min(transaction_units, live qty)
    //                            (apply_same_bar_market_tx_reversal), and the
    //                            exact SHORT-seed collision's final short
    //                            re-opens the residual pyramid_entries_[0].qty
    //                            - pyramid_entries_[1].qty after closing both
    //                            lots (short_seed_collision_final_short_is_
    //                            live). Both kernels are modelled; each is
    //                            reported with close_only = 1 when it opens
    //                            nothing.
    //   2 DEFAULT_STOP_PLACEMENT default_stop_placement_qty, when
    //                            use_default_stop_placement_qty says
    //                            dispatch consumes it (round 7 family K).
    //   3 AT_FILL                default sizing at the slipped fill,
    //                            calc_qty(fill).
    // `fill_price` is slipped the way the kernel slips it
    // (apply_slippage; a LIMIT-triggered entry takes apply_limit_fill).
    // `close_only` is 1 when the kernel's close-only predicate fires -- the
    // fill closes against the live opposite position and that predicate
    // opens no leg of its own (where the order was created FLAT the branch
    // is close_opposite_then_enter: a transaction larger than the live
    // position still opens the remainder, so a consumer compares `qty` with
    // the live position): the order's
    // affordability_close_only (entry leg declined at placement), the
    // priced-entry prior_cycle_close_only rule (opposite live position,
    // created_position_side != position_side_, and not a KI-65
    // reverses_same_bar_market_from_flat), the same-cycle frozen
    // explicit-FIXED transaction that the close consumes exactly, or a
    // finalized flat MARKET pair, or one of the two reversal kernels above
    // opening nothing -- each spelled as apply_entry_order_fill /
    // apply_market_order_fill spell it. A replaced default-percent short
    // (replaced_percent_short_market_is_live) is dispatched
    // close_opposite_then_enter with its frozen_default_qty: `qty` is that
    // transaction, close_only 0. Not folded into `qty`: the
    // deferred-flip carry (tv_carry_qty, enter_market_from_flat's
    // tv_deferred_flip rule adds it on top of this quantity for a priced
    // entry firing from FLAT whose placement side is the opposite of the
    // requested side) -- the mirror exposes tv_carry_qty and
    // created_position_side verbatim. Returns 0 on success; 1 (qty NaN,
    // close_only 0, partition -1) when the order is an EXIT, whose fill
    // quantity is decided against the live position at the fill, not by a
    // sizing partition; -1 on a bad index or a null out-pointer.
    int probe_fill_qty(int index, double fill_price, double* qty,
                       int* close_only, int* partition) const;
    // 1 when the order's entry-relative offsets (profit_ticks / loss_ticks /
    // trail_points) resolve NOW: entries, plain orders and exits with an
    // empty from_entry always; an exit bound to from_entry only once that
    // id has filled in the CURRENT position cycle (cycle_filled_entry_ids_,
    // the gate materialize_relative_exit_prices_for_live_position and the
    // eligibility pass share). 0 otherwise, -1 on a bad index.
    int pending_order_level_resolved(int index) const;
    // The price levels the order would fire at, as the fill path resolves
    // them: a set stop_price / limit_price / trail_price verbatim (they are
    // already on the price grid); an unset leg from its tick offset against
    // position_entry_price_ when pending_order_level_resolved() == 1 and a
    // position is live, with the position side's sign exactly as
    // materialize_relative_exit_prices_for_live_position (limit = entry +
    // dir * profit_ticks * mintick, stop = entry - dir * loss_ticks *
    // mintick, dir = +1 long / -1 short, level_on_price_grid) and
    // resolve_exit_path_fill (activation = snap_trail_level_to_tick_grid(
    // entry +/- ceil(trail_points - 5e-5) * mintick); trail_points wins
    // over trail_price when both are set). NaN for a leg that is unset or
    // unresolvable. Returns 0, or -1 on a bad index / null out-pointer.
    int pending_order_effective_levels(int index, double* stop, double* limit,
                                       double* trail_activation) const;
    // The live position's volume-weighted average entry price
    // (position_entry_price_; 0 when flat -- the engine keeps 0 there, the
    // C ABI reports NaN when flat), its cycle id (position_cycle_seq_; 0
    // when flat, a fresh nonzero id per open/reversal, kept across
    // same-direction adds) and the trail extreme the exit trail legs ride
    // (trail_best_price_; NaN until a position fills).
    double position_avg_price() const { return position_entry_price_; }
    int64_t position_cycle_seq() const { return position_cycle_seq_; }
    double trail_best_price() const { return trail_best_price_; }
    // ABI v4 live-runtime surface (task 9): public forwarders for the C
    // ABI, which -- being extern "C" free functions -- cannot reach the
    // protected signed_position_size() / current_equity() above.
    // signed_position_size() is strategy.position_size (KI-64 freeze-aware:
    // reads the pre-close position while a same-bar POOC close is frozen).
    // current_equity() is initial capital plus realized net profit
    // (strategy.initial_capital + strategy.netprofit). NOT Pine's
    // strategy.equity, which adds open profit on top of this (see the
    // sizing_equity formula and the equity-curve remark below, both
    // current_equity() + open_profit(...)).
    double live_position_size() const { return signed_position_size(); }
    double live_current_equity() const { return current_equity(); }
    // ABI v4 live-runtime surface (task 9): total SCRIPT bars dispatched by
    // the most recent run() (mirrors pf_report_t::script_bars_processed,
    // engine_report.cpp), including the stream warmup leg and every
    // realtime tick-driven bar after strategy_stream_begin.
    int64_t script_bars_processed() const { return diag_script_bars_processed_; }

    // ABI v4 live-runtime surface (task 6): when on, every script bar's
    // dispatch (all four script-bar dispatch sites -- the single-TF run()
    // loop, run_simple_bar_loop, run_aggregation_bar_loop, and
    // stream_dispatch_script_bar, engine_stream.cpp, the realtime-stream
    // continuation of a stream_begin warmup) appends broker_state_hash()
    // to broker_state_hashes_ immediately after that bar's
    // record_equity_point() call, so the recorded array's length matches
    // script_bars_processed and pf_report_t::broker_state_hash_len 1:1 --
    // including on strategy_stream_fill_report, whose report is the
    // cumulative warmup + realtime run. Default off: broker_state_hashes_
    // stays empty, fill_report emits a null/zero-length array, and every
    // historical run stays byte-identical to before this flag existed.
    // reset_run_state() clears the recorded array on every run() (the
    // warmup leg of stream_begin included) regardless of this flag's
    // value; the flag itself is persistent configuration, like
    // set_realtime_tail, so it must be set BEFORE stream_begin to also
    // cover the warmup bars.
    void set_broker_state_hash_recording(bool on) {
        guard_native_mutation("set_broker_state_hash_recording");
        broker_state_hash_recording_ = on;
    }

    // Toggle volume-weighted per-sub-bar sampling inside run_magnified_bar.
    // Has no effect unless bar magnifier is enabled.
    void set_magnifier_volume_weighted(bool on) {
        guard_native_mutation("set_magnifier_volume_weighted");
        magnifier_volume_weighted_ = on;
    }

    // --- Runtime trace API ---
    // Default off so existing strategies pay zero cost. The validator
    // flips this on per-strategy via ``strategy_set_trace_enabled`` (the
    // FFI shim defined in c_abi.cpp) before running a backtest whose
    // per-bar values it wants to cross-reference against TradingView.
    void set_trace_enabled(bool on) {
        guard_native_mutation("set_trace_enabled");
        trace_enabled_ = on;
    }
    bool trace_enabled() const { return trace_enabled_; }

    // --- Live-runtime status API (ABI v4) ---
    int last_run_status() const { return last_run_status_; }

    // Request cooperative abort of the run in progress on this handle (a
    // live runtime supersedes an in-flight probe run). Safe to call from any
    // thread; consumed by the running loop at its next bar. A request made
    // while idle is cleared at the next run() entry and is a no-op.
    void request_abort() { abort_requested_.store(true, std::memory_order_relaxed); }

    // Push a typed per-bar value into the trace buffer. Cheap when
    // disabled — a single bool branch and return. When enabled, name
    // interning amortises to a single hash lookup per call after the
    // first occurrence; the actual record is a 24-byte POD push_back.
    //
    // The bool / int overloads internally cast to double so the
    // transpiler pragma can emit a single call shape regardless of the
    // source variable's Pine type — keeping codegen rewrites trivial.
    void trace(const std::string& name, double value);
    void trace(const std::string& name, bool value)  { trace(name, value ? 1.0 : 0.0); }
    void trace(const std::string& name, int value)   { trace(name, static_cast<double>(value)); }
};

} // inline namespace engine_script_run_v13
} // namespace pineforge
